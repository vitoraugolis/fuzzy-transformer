# Caso Industrial U-200 — benchmark multissilo para controle de processos

Benchmark construído sobre o CSTR adimensional de **Lee, Jin & So (2025),
*Algorithms* 18(7), 442**, para avaliar estratégias de controle em uma situação
em que **controlar bem a variável não é o mesmo que operar bem a unidade**.

O caso **não** contém, e não deve conter, nenhum controlador inteligente. Ele é
o problema sobre o qual esse controlador será futuramente avaliado.

---

## 1. Objetivo

Durante 4.7 dias de campanha, o PID da unidade mantém a
temperatura do reator no set point, com **100.0 % do produto
em especificação** e IAE por hora de 0.0535. No mesmo
período, a abertura da válvula de resfriamento sobe de ~32 % para
**94.7 %** — a unidade consome toda a sua reserva de rejeição
de perturbação sem que nenhuma métrica de erro registre nada.

Quando uma variação **de apenas 3.1 K** na temperatura da carga
chega, a válvula satura e a unidade perde o controle da temperatura por
21 horas, produzindo material fora de especificação.

| | A — baseline | B — com incidente | razão |
|---|---|---|---|
| IAE | 3.35 | 32.02 | **9.6×** |
| Custo operacional | 0.024 | 3.292 | **138×** |
| Esforço de controle | 31.91 | 27.26 | 0.85× (B parece *melhor*) |

Essa assimetria é o caso: **o erro cresce 10×; o custo de
operar cresce 138×.** Uma função objetivo baseada em `SP − PV`
subestima o problema por mais de uma ordem de grandeza.

## 2. A planta

**U-200 / R-201** — reator CSTR encamisado de 12 m³, reação exotérmica de
primeira ordem A → B, resinas alquídicas e poliéster.

| | |
|---|---|
| Temperatura de operação | 229.2 °C (envelope 224.0 – 235.0 °C) |
| Carga | 9,0 m³/h · tempo de residência 20 min |
| Conversão | 0,765 nominal |
| Remoção de calor | loop fechado de água temperada, 60 m³/h |
| Elemento final | **FV-201**, válvula de três vias que desvia o loop por E-201 |
| Alarmes | TAH-201 235.2 °C · TAHH-201 (SIS) 244.4 °C · ZAH-201 em 80 % de curso |

A MV **não** é a temperatura da camisa do artigo: é a abertura de FV-201. A
ponte é a Eq. 2 do artigo, `u = (a·u_cf + x₂)/(a+1)`, o que torna a saturação
da MV um limite **físico** e coloca a *capacidade do equipamento* — e não o
controlador — como variável limitante.

Escala dimensional: `T = T_f(1 + x₂/γ)` com `T_f = 406.7 K` e `γ = 20`,
o que dá `E_a = 67.6 kJ/mol` e 1 unidade de x₂ =
20.34 K. Todos os documentos foram gerados a partir desse mapa.

## 3. Como executar

```bash
python tools/u200_case.py        # experimentos A, B, C, contrafactual e 29 testes
python tools/build_notebook.py   # regenera o notebook a partir do módulo
python tools/build_docs.py       # regenera figuras, documentos e o pacote de investigação
```

Ou abra `notebook/projeto_case_industrial.ipynb` e execute do início ao fim.

Dependências: `numpy`, `matplotlib`, `reportlab`, `openpyxl`, `nbformat`, `pillow`.

> `tools/u200_case.py` é a **fonte única da verdade**. O notebook é gerado a
> partir dele (formato percent) e os documentos importam dele todo número que
> também exista no simulador. Não edite o notebook à mão.

## 4. Estrutura

```
case_study/
├── notebook/projeto_case_industrial.ipynb   modelo, incidente, métricas, comparação
├── tools/                                   fonte única da verdade
│   ├── u200_case.py       modelo + cenário + harness + métricas + testes
│   ├── docgen.py          molde de documento industrial em PDF
│   ├── diagramas.py       PFD, P&ID e curva de Cv
│   ├── build_notebook.py  módulo  →  notebook
│   └── build_docs.py      módulo  →  documentos + pacote + ground truth + matriz
├── data/                  historian, alarmes, eventos, qualidade
├── production/            ordens de produção, COA, plano de campanhas
├── maintenance/           ordens de trabalho
├── operations/            relatórios de turno
├── process/               descrição, PFD, P&ID, procedimento operacional
├── engineering/           design basis, folhas de dados, memória de cálculo, filosofia
├── vendor/                documentação dos fabricantes
├── safety/                HAZOP
├── specialist/            notas técnicas e memorandos
├── figures/               figuras dos experimentos e diagramas
├── investigation_package/ ► o que a equipe de investigação recebe
└── internal/              ► ground truth e matriz — NÃO entregar
```

## 5. O que pertence a cada silo

| Silo | Pasta | Contém |
|---|---|---|
| Processo / PIMS | `data/` | historian de 5 em 5 min, log de alarmes, log de eventos, LIMS |
| Produção | `production/` | PO-2026-0417, PO-2026-0418, COA-MB-4471, PLN-2026-08 |
| Manutenção | `maintenance/` | WO-3862, WO-3871, **WO-3874**, WO-3879, WO-3882, WO-3888, WO-3891 |
| Operação | `operations/` | 7 relatórios de turno, de 30/07 a 13/08 |
| Processo | `process/` | U-200-PD-001, U-200-PFD-001, U-200-PID-201, POP-U200-014 |
| Engenharia | `engineering/` | U-200-DB-001, U-200-DS-FV201, U-200-DS-R201, U-200-MC-014, U-200-CP-001 |
| Fabricante | `vendor/` | NV-4000-TD, NV-4000-IOM, JX-200-DS |
| Segurança | `safety/` | HZ-U200-2024-03 |
| Especialista | `specialist/` | NT-PROC-2025-11, MEMO-CONF-2026-04 |

A causa raiz **não está escrita em nenhum desses documentos**. Ela exige o
cruzamento de, no mínimo, três silos distintos.

## 6. Reprodutibilidade

Semente única `20260808`. O ruído é **pré-gerado em arrays antes do
laço**, de modo que baseline, incidente e contrafactual vejam a mesma realização
nos mesmos instantes, independentemente do ramo do cenário. Um teste verifica
que `run_case(novo_pid(), CEN_BASELINE)` reproduz o experimento A bit a bit, e
outro que os experimentos B e C são idênticos.

Entre B e C, a **única** variável é o controlador. Entre A e B, a única variável
é o cenário.

## 7. Métricas

Quatro famílias, em `metrics()`:

- **Controle** — IAE, ISE, ITAE, erro máximo, erro médio.
- **Processo** — conversão média, tempo em especificação, produção perdida, overshoot.
- **Operação** — curso médio e máximo de FV-201, **margem mínima de curso**,
  tempo saturado, tempo acima de ZAH-201, esforço de controle, intervenções.
- **Segurança (exposição, não probabilidade)** — tempo acima do envelope, tempo
  acima do TAH-201, temperatura máxima, **margem mínima até o TAHH-201**.

`operational_cost()` agrega essas famílias com pesos declarados em
`PESOS_CUSTO`. Os pesos são uma **decisão do pesquisador**, estão explícitos no
código e não pretendem representar probabilidade de evento.

**Critério de avaliação recomendado:** um controlador só é superior neste
benchmark se reduzir `tempo_saturado_h` **e** `producao_perdida_pct` **sem**
aumentar `tempo_acima_TAH_h`. Melhora de IAE isolada não conta — e
`esforco_controle` é enganoso aqui, porque o cenário degradado o *reduz*
(a válvula fica travada).

## 8. Investigação × ground truth

| | |
|---|---|
| `investigation_package/` | Tudo o que a equipe de engenharia receberia. Sem ground truth, sem ranking de evidências, sem indicação de quais documentos importam. Contém material irrelevante, como qualquer pacote real. |
| `internal/ground_truth_case.md` | Causa raiz, causas contribuintes, cadeia causal, hipóteses falsas e por que são plausíveis, comportamento esperado do PID, métricas de avaliação. |
| `internal/information_matrix.xlsx` | Mapa entre informação, silo, documento, disponibilidade temporal, relevância e relação com a causa. 55 itens. |
| `internal/historian_truth.csv` | Estados verdadeiros e parâmetros ocultos (`gain_trim`, `H`, `u_cf`, `d1`, `d2`). |

Um teste automático verifica que nenhum arquivo com `ground_truth`,
`historian_truth`, `information_matrix` ou `u200_case` no nome chega ao pacote
de investigação.

## 9. Interface para o controlador futuro

```python
class BaseController:
    def reset(self, operating_context=None): ...
    def update(self, observation, context, dt) -> float:   # abertura de FV-201, 0..1
        ...

controller = novo_pid()                    # hoje
controller = ProposedController(...)       # depois — mesma planta, mesmo cenário
resultado  = run_case(controller, CEN_INCIDENTE)
```

`observation` contém apenas o que o DCS mede (SP, PV, ZT-201, FT-201, TT-203,
TT-207, TT-204, AT-205). `context` traz campanha, especificação, envelope e
limites de alarme. **`gain_trim` não está lá** — a perda de capacidade de
FV-201 não é medida por nenhum instrumento da unidade. Reconstruí-la a partir
dos documentos é o problema.

---

*Gerado a partir de `tools/u200_case.py`. Revisão do caso: 1.0 — 2026-08-25.*
