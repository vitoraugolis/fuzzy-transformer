# Ground Truth — Caso Industrial U-200 / R-201

> **DOCUMENTO PRIVADO DO PESQUISADOR.**
> Não pertence ao `investigation_package/` e não deve ser fornecido a nenhum
> sistema que esteja sendo avaliado sobre este caso.
> Gerado automaticamente a partir de `tools/u200_case.py` — os números abaixo
> são os da simulação, não estimativas.

---

## 1. Causa raiz

**A capacidade de resfriamento instalada de FV-201 foi reduzida em 45 % em
relação à de projeto, sem que ninguém tomasse conhecimento disso.**

Na parada PP-26-03, em 29/07/2026 (WO-3874), o conjunto de trim especificado
`NV4000-40-STD` (Cv 40) estava indisponível em almoxarifado e foi substituído
pelo conjunto `NV4000-22-AC` (Cv 22, gaiola anticavitação de 3 estágios),
disponível em estoque. A substituição é mecanicamente correta, foi executada
segundo boa prática, passou em todos os testes aplicáveis (curso, calibração de
posicionador, estanqueidade classe IV) e foi motivada por uma razão técnica
legítima — a válvula estava sendo revisada justamente por erosão, e uma gaiola
anticavitação combate erosão.

Nenhum ensaio executado detecta a diferença, porque **nenhum deles mede vazão**.
O teste de bancada verifica a relação sinal → curso; a perda está na relação
curso → vazão.

No modelo: `gain_trim` passa de 1,00 para 0.55 a partir de
t = 0 do cenário de incidente.

## 2. Causas contribuintes

| # | Causa | Silo de origem | Contribuição no curso de FV-201 |
|---|---|---|---|
| C1 | **Trim de capacidade reduzida** (Cv 22 em lugar de Cv 40) | Manutenção (WO-3874) | **+26.1 pontos** |
| C2 | Campanha RB-220, carga com mais monômero (57.0 % → 58.1 %) | Produção (PO-2026-0418) | +17.9 pontos |
| C3 | Aquecimento do circuito de resfriamento (torre em onda de calor + WO-3882 adiada) | Utilidades / Manutenção | +18.1 pontos |
| C4 | Supressão do alarme ZAH-201 em 11/08 08:00 | Operação | 0 pontos — remove o **único aviso** |
| C5 | Recomendações HZ-R07 e HZ-R14 do HAZOP em aberto desde 2024 | Segurança de processo | 0 pontos — remove a **barreira sistêmica** |
| G  | Gatilho: elevação de 3.1 K na temperatura da carga (falha de E-202, U-100) | Processo (U-100) | leva a demanda a 157 % |

**Nenhuma causa isolada satura a válvula.** C1 sozinha leva o curso a
58.0 %; C1+C2 a 75.9 %;
C1+C2+C3 a 94.1 %. É a soma das três
mais o gatilho que ultrapassa 100 %.

## 3. Sequência causal

```
    estado normal            29/07  parada PP-26-03; WO-3874 substitui o trim de FV-201
          |                         (capacidade cai 45 %; ninguém sabe)
   mudança operacional       30/07  partida: FV-201 opera a ~58 % em vez de ~32 %
          |                         temperatura no SP, produto aprovado
    primeiro sinal           30/07  RT-20260730-A registra "válvula mais aberta que o normal"
          |                         instrumentação consultada informalmente; nada aberto
   mudança de campanha    08-09/08  PO-2026-0418 (RB-220): carga mais concentrada
          |                         curso sobe para ~76 %
      novo comportamento      10/08  ZAH-201 começa a atuar de forma repetitiva
          |                         circuito de resfriamento aquecendo (TT-203, TT-207)
       intervenção            11/08  ZAH-201 SUPRIMIDO (POP § 7.3); WO-3888 aberta
          |                         WO-3888 encerra "sem anomalia" — e está correta
       agravamento            12/08  curso atinge ~94 %; margem operacional ≈ 6 pontos
          |                         temperatura ainda no SP; produto ainda aprovado
      evento crítico       12/08 22:40  TT-204 sobe 3.1 K (falha de E-202 na U-100)
                           12/08 22:50  FV-201 satura em 100 % — ZAHH-201
                           12/08 23:10  TAH-201; temperatura acima do envelope
                           13/08 00:00  primeira amostra reprovada
                           13/08 02:00  SP reduzido — sem efeito (válvula já saturada)
```

## 4. Parâmetros físicos alterados

| Parâmetro | Nominal | No incidente | Significado industrial |
|---|---|---|---|
| `gain_trim` | 1,00 | 0.55 | capacidade do trim instalado / trim de projeto |
| `H` | 8.00 | 8.15 | calor de reação ∝ monômero na carga |
| `u_cf` | -2.20 (88.8 °C) | -1.85 (95.9 °C) | limite frio do loop de água temperada |
| `d2` (gatilho) | 0 | +0.15 (3.1 K) | desvio de temperatura da carga |

Nada mais é alterado. `Da`, `beta`, `gamma`, a sintonia do PID, o SP, a vazão de
carga, os limites de alarme e o ruído são idênticos entre os cenários.

## 5. Relação entre os eventos

O elo que torna o caso difícil é **temporal e assimétrico**:

- C1 ocorre **10 dias antes** do evento crítico e em outro silo (manutenção).
- C1 **não produz sintoma nenhum** enquanto houver curso disponível. A
  temperatura fica no SP; o produto fica em especificação; o erro de controle
  permanece pequeno. Durante os 4.7 dias anteriores ao
  gatilho, **100.0 % do produto está em especificação** e o
  IAE por hora é 0.0535.
- C2 e C3 são **visíveis e documentados**, e por isso atraem toda a atenção.
- O gatilho vem **de outra unidade** (U-100), o que reforça a leitura de "causa
  externa".

## 6. Informações que permitem reconstruir a causa

Nenhum documento contém a resposta. Ela exige **no mínimo três silos**:

| # | Informação | Onde está | Silo |
|---|---|---|---|
| 1 | FV-201 recebeu o conjunto `NV4000-22-AC` no lugar do `NV4000-40-STD` | WO-3874, itens de material | Manutenção |
| 2 | `NV4000-22-AC` tem Cv 22 contra Cv 40 do padrão; conjuntos AC reduzem capacidade em 30–60 % | NV-4000-TD § 2 e advertência § 2.3 | Fabricante |
| 3 | FV-201 foi especificada Cv 40, com 45 m³/h a 100 % de curso | U-200-DS-FV201 § 2 | Engenharia |
| 4 | O critério de projeto exige 25 % de reserva de curso | U-200-DB-001 § 4 (DB-4.1) | Engenharia |
| 5 | O curso esperado no caso mais severo é ~48 % | U-200-MC-014 § 4 | Engenharia |
| 6 | **ZT-201 ≈ 94 % com FT-201 ≈ 25 m³/h** — 55 % da vazão esperada | historian.csv | Processo/PIMS |
| 7 | O salto de 32 % para ~58 % ocorre **na partida pós-parada**, antes da troca de campanha | historian.csv + RT-20260730-A | PIMS + Operação |
| 8 | Calibração de posicionador não corrige capacidade; teste de bancada não a detecta | NV-4000-IOM § 5.3.1 | Fabricante |
| 9 | Acima de ~70 % de curso a unidade perde a capacidade de rejeitar perturbações | NT-PROC-2025-11 | Especialista |
| 10 | O desvio "capacidade MENOS do elemento final" está previsto no HAZOP, nó 3 | HZ-U200-2024-03 | Segurança |

**O cruzamento mínimo suficiente é 1 × 2 × 3** (WO + fabricante + folha de
dados). O item 6 confirma independentemente pelos dados. O item 7 data o início.

## 7. Hipóteses falsas

| Hipótese | Evidência a favor | Por que é falsa | Como descartar |
|---|---|---|---|
| **H1 — Sintonia do TIC-201** | Erro grande e persistente a partir de 12/08; SP reduzido sem efeito | Antes do gatilho o IAE/h é 0.0535 e 100.0 % do produto está em spec. Nenhum ganho cria capacidade de troca térmica | Observar que a MV está em 100 %: com o atuador saturado a sintonia é irrelevante |
| **H2 — Perda de água de resfriamento** | TT-203 subiu 5 K; TAH-203 atuou várias vezes; WO-3882 aberta e pendente; FT-201 abaixo do esperado | É contribuinte real (C3), mas responde por apenas 18.1 dos 62.1 pontos de curso consumidos. Com o trim correto, a mesma torre e o mesmo gatilho **não saturam a válvula** | Contrafactual: pressão do header normal; P-201 normal; e a vazão baixa persiste mesmo quando a torre está fria |
| **H3 — Mudança de campanha / carga térmica do RB-220** | Coincide temporalmente com o agravamento; PO documenta carga mais concentrada; curso sobe 18 pontos na transição | É contribuinte real (C2). Mas o RB-220 está **dentro do envelope de projeto** — o caso MC-4 da memória de cálculo prevê 48 % de curso, não 94 % | Comparar o curso observado com o previsto em U-200-MC-014 para o mesmo grade |
| **H4 — Instrumentação (TT-201 ou AT-205)** | AT-205 tinha desvio real e foi recalibrado (WO-3871); TT-201 verificado durante a ocorrência | WO-3891 confirma TT-201 conforme; a temperatura é real. O desvio de AT-205 é anterior, real e **irrelevante** para a capacidade de resfriamento | Loop check de TT-201 (já executado) e comparação com TW-201B |
| **H5 — Posicionador de FV-201** | Operação relatou "válvula muito aberta"; WO-3888 aberta | WO-3888 está **correta**: o posicionador está bom. A válvula obedece ao sinal. O problema não é sinal → curso, é curso → vazão | NV-4000-IOM § 5.3.1 explica exatamente por que a verificação feita não detecta o problema |

Todas as hipóteses falsas são **defensáveis com a evidência disponível**. H2 e H3
são parcialmente verdadeiras, o que é o caso mais difícil: quem parar nelas
produz um relatório correto, incompleto e inútil para evitar a recorrência.

## 8. Comportamento esperado do PID

O PID **funciona corretamente durante todo o caso**. Ele é sintonizado por IMC
(λ = τ) sobre um modelo identificado na própria MV, tem anti-windup e respeita
a saturação. Números medidos:

| | A — baseline | B — com incidente | B' — mesmo incidente, trim correto |
|---|---|---|---|
| IAE (horizonte) | 3.35 | 32.02 | 11.90 |
| Tempo em especificação | 100.0 % | 85.1 % | 96.1 % |
| Curso máximo de FV-201 | 33.3 % | 100.0 % | 98.8 % |
| Tempo saturado | 0.0 h | 21.4 h | 1.2 h |
| Tempo acima do TAH-201 | 0.0 h | 19.5 h | 0.0 h |
| Temperatura máxima | 229.7 °C | 237.4 °C | 234.8 °C |
| Custo operacional | 0.024 | 3.292 | 0.469 |

Recorte antes do gatilho (t < 336, 4.7 dias):
**100.0 % em especificação, IAE/h = 0.0535,
0 h acima do alarme — e curso máximo de
94.7 %.** É esta linha que define o caso.

Depois do gatilho: IAE sobe para 26.0, tempo em spec cai para
25.5 %, 21.4 h com a válvula no batente.

**Assimetria central:** o IAE de B é 9.6× o de A, mas o custo
operacional é 138× o de A. Uma função objetivo baseada em erro subestima
o problema por mais de uma ordem de grandeza.

## 9. Comportamento que um controlador superior deveria produzir

Não é "controlar melhor a temperatura" — não há erro relevante a reduzir antes
do gatilho. É **agir sobre a margem antes de ela acabar**. Comportamentos que
distinguiriam um controlador superior, em ordem de ambição:

1. **Detectar** que ZT-201 e FT-201 são inconsistentes com a curva de Cv do
   conjunto especificado, e sinalizar isso ainda em 30/07 — 13 dias antes.
2. **Reconhecer** que a margem de curso, e não o erro, é a variável limitante, e
   levar isso ao operador com antecedência (é literalmente a recomendação
   HZ-R14, em aberto desde 2024).
3. **Negociar a operação**: com a margem em 6 pontos, propor reduzir carga ou
   antecipar o fim da campanha, aceitando perda de produção para preservar
   capacidade de rejeitar perturbação.
4. **Não desperdiçar ação inútil**: reconhecer que, com a MV saturada, reduzir o
   SP não tem efeito — e dizer isso, em vez de registrar erro crescente.

Os itens 1 e 2 exigem informação que **não está no historian**: exigem o
datasheet, a memória de cálculo, a ordem de manutenção e o documento do
fabricante. É essa a razão de ser do caso.

## 10. Métricas de avaliação

Ordenadas por poder discriminante medido entre A e B:

| Métrica | A | B | Razão | Discrimina? |
|---|---|---|---|---|
| `tempo_saturado_h` | 0.0 | 21.4 | ∞ | **sim, absoluta** |
| `tempo_acima_TAH_h` | 0.0 | 19.5 | ∞ | **sim, absoluta** |
| `margem_curso_min_pct` | 66.7 | 0.0 | — | **sim, é a variável do caso** |
| `producao_perdida_pct` | 0.0 | 15.5 | — | sim |
| `custo operacional` | 0.024 | 3.292 | 138× | sim |
| `IAE` | 3.35 | 32.02 | 9.6× | fraco — subestima |
| `esforco_controle` | 31.91 | 27.26 | 0.85× | **enganoso: B parece melhor** |

A última linha merece destaque: pela métrica clássica de esforço de controle, o
cenário com incidente é **melhor** que o baseline — porque a válvula está
travada e não se mexe. Qualquer avaliação que use esforço de controle como
proxy de qualidade de operação é invertida por este caso.

**Regra de avaliação recomendada:** um controlador só deve ser considerado
superior neste benchmark se reduzir `tempo_saturado_h` **e**
`producao_perdida_pct` sem aumentar `tempo_acima_TAH_h`. Melhora de IAE isolada
não conta.

## 11. Como reproduzir

```bash
python tools/u200_case.py          # roda A, B, C, B' e os 29 testes de consistência
python tools/build_notebook.py     # regenera o notebook a partir do módulo
python tools/build_docs.py         # regenera todos os documentos e o pacote
```

Semente única: `Scenario.seed = 20260808`. Ruído pré-gerado em
arrays antes do laço, de modo que A, B, C e B' vejam a mesma realização nos
mesmos instantes. `run_case(novo_pid(), CEN_BASELINE)` reproduz `EXP_A` bit a
bit — verificado em teste.
