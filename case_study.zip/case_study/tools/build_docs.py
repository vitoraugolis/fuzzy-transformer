"""Gera todos os documentos dos silos de informação do caso U-200.

Regra de ouro: qualquer número que também exista no simulador é IMPORTADO de
`u200_case`, nunca redigitado. É isso que mantém os silos consistentes (§16).

    python tools/build_docs.py
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, "tools"))

import matplotlib                                                    # noqa: E402
matplotlib.use("Agg")

from docgen import (P, ST, PageBreak, Spacer, assinaturas, bloco_identificacao,  # noqa: E402
                    caixa, figura, gerar, mm, tabela)
import diagramas                                                     # noqa: E402


def _carregar_caso():
    os.chdir(RAIZ)
    spec = importlib.util.spec_from_file_location("u200", os.path.join(RAIZ, "tools", "u200_case.py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules["u200"] = mod
    spec.loader.exec_module(mod)
    return mod


U = _carregar_caso()
C = lambda x2: float(U.x2_to_C(x2))            # noqa: E731  atalho: adimensional -> °C
F = lambda x2: f"{C(x2):.1f}"                  # noqa: E731

# ---- pessoas (as mesmas em todos os documentos) -----------------------------
EQUIPE = {
    "proc": "R. Nakamura — Eng. de Processo Sênior",
    "ctrl": "C. Ferreira — Eng. de Controle e Automação",
    "manut": "J. Barbosa — Supervisão de Manutenção",
    "instr": "A. Duarte — Téc. de Instrumentação",
    "mec": "M. Tavares — Téc. Mecânico",
    "plan": "L. Prado — Planejamento de Produção",
    "opA": "S. Moreira — Operação, Turno A",
    "opB": "P. Rocha — Operação, Turno B",
    "opC": "E. Lima — Operação, Turno C",
    "coord": "D. Castro — Coordenação de Operação",
    "conf": "F. Almeida — Eng. de Confiabilidade",
    "hazop": "H. Vasques — Facilitador HAZOP (consultoria externa)",
    "lab": "T. Siqueira — Laboratório / Controle de Qualidade",
}

# ---- dados de projeto derivados do simulador --------------------------------
SP_C = C(U.SP_UNIDADE)
ENV_LO_C, ENV_HI_C = C(U.X2_ENVELOPE[0]), C(U.X2_ENVELOPE[1])
TAH_C, TAHH_C, TAL_C = C(U.X2_TAH), C(U.X2_TAHH), C(U.X2_TAL)
UCF_C = C(U.UCF_PROJETO)
JAQUETA_NOM_C = C(0.0)
CV_PROJETO, CV_SUBSTITUTO = 40, 22
# ---- dados térmicos dimensionais, DERIVADOS do modelo adimensional ---------
# Referências físicas escolhidas (as únicas grandezas dimensionais arbitradas):
RHO_KGM3, CP_JKGK, F_M3H = 950.0, 2100.0, 9.0
RHO_CP_F = RHO_KGM3 * CP_JKGK * F_M3H / 3600.0          # W/K  = 4 987 W/K
UA_WK = U.CSTRParams().beta * RHO_CP_F                  # UA = beta · rho·Cp·F
AREA_CAMISA_M2 = 18.0                                   # meia-cana, ~70 % da lateral
U_GLOBAL_WM2K = UA_WK / AREA_CAMISA_M2
# Potências em regime no ponto de operação (x2 = SP, u = 0):
_ESCALA_KW = RHO_CP_F * U.DT_K / 1000.0                 # kW por unidade adimensional
Q_REACAO_KW = U.CAMPANHA_A.H * 0.76456 * _ESCALA_KW     # H·r
Q_CAMISA_KW = U.CSTRParams().beta * U.SP_UNIDADE * _ESCALA_KW
Q_PRODUTO_KW = Q_REACAO_KW - Q_CAMISA_KW
DT_CAMISA_K = (U.SP_UNIDADE - 0.0) * U.DT_K
Q_REACAO_B_KW = Q_REACAO_KW * U.CAMPANHA_B.H / U.CAMPANHA_A.H

# Hidráulica de FV-201: Q = Cv·sqrt(dP/d). dP de projeto fixado para que o
# conjunto de projeto (Cv 40) entregue exatamente a vazão de projeto do loop.
DENS_REL = 0.95
DP_PROJETO_BAR = DENS_REL * (U.FC_DESIGN_M3H / 40.0) ** 2
def _vazao(cv, dp=None):
    import math
    return cv * math.sqrt((DP_PROJETO_BAR if dp is None else dp) / DENS_REL)

GERADOS: list[str] = []


def _emitir(pasta, arquivo, cab, conteudo):
    caminho = gerar(os.path.join(RAIZ, pasta, arquivo), cab, conteudo)
    GERADOS.append(os.path.relpath(caminho, RAIZ))
    return caminho


# =============================================================================
# SILO 2 — PRODUÇÃO
# =============================================================================
def _ordem_producao(po, grade, produto, lote, inicio, fim, monomero, x_min, x_max,
                    sp_c, tonelagem, observacoes, rev="0", status="ENCERRADA"):
    cab = {"titulo": f"Ordem de Produção {po}", "numero": po, "rev": rev,
           "data": inicio.split()[0], "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({
            "Ordem": po, "Revisão": rev, "Status": status,
            "Unidade": f"{U.UNIDADE} / R-201", "Produto": produto, "Grade": grade,
            "Lote": lote, "Início previsto": inicio, "Fim previsto": fim,
            "Emitida por": "L. Prado", "Aprovada por": "D. Castro",
            "Plano": "PLN-2026-08",
        }),
        Spacer(1, 5 * mm),
        P("1. RECEITA E CONDIÇÃO DE ALIMENTAÇÃO", "h1"),
        tabela([
            ["Item", "Valor", "Unidade", "Tolerância", "Observação"],
            ["Vazão de alimentação para R-201", "9,0", "m³/h", "± 0,3", "FT-204"],
            ["Monômero na alimentação", f"{monomero:.1f}", "% m/m", "± 0,4",
             "conforme certificado do lote"],
            ["Temperatura de alimentação (E-202)", "133,5", "°C", "± 2,0", "TT-204"],
            ["Solvente / diluente", "aromático leve", "-", "-", "reciclo de TK-201"],
            ["Tempo de residência nominal", "20", "min", "-", "12 m³ úteis"],
        ], [58 * mm, 20 * mm, 18 * mm, 22 * mm, 50 * mm]),
        Spacer(1, 3 * mm),
        P("2. CONDIÇÃO DE PROCESSO", "h1"),
        tabela([
            ["Malha", "Set point", "Faixa admissível", "Modo", "Observação"],
            ["TIC-201 (temperatura R-201)", f"{sp_c:.1f} °C",
             f"{ENV_LO_C:.1f} – {ENV_HI_C:.1f} °C", "AUTO",
             "não alterar sem autorização de Processo"],
            ["FV-201 (água de resfriamento)", "cascata de TIC-201", "0 – 100 %", "AUTO",
             "abertura acompanha a carga térmica"],
        ], [46 * mm, 26 * mm, 34 * mm, 16 * mm, 46 * mm]),
        Spacer(1, 3 * mm),
        P("3. ESPECIFICAÇÃO DE PRODUTO", "h1"),
        tabela([
            ["Propriedade", "Mínimo", "Máximo", "Método", "Frequência"],
            ["Conversão (fração)", f"{x_min:.3f}", f"{x_max:.3f}", "LAB-QM-04 (NIR + titulação)",
             "4 em 4 h"],
            ["Cor Gardner", "-", "4,0", "ASTM D1544", "4 em 4 h"],
            ["Viscosidade a 25 °C (cP)", "1700", "2100", "ASTM D2196", "4 em 4 h"],
            ["Sólidos (% m/m)", "58,0", "62,0", "ASTM D2369", "por lote"],
        ], [46 * mm, 20 * mm, 20 * mm, 56 * mm, 26 * mm]),
        Spacer(1, 3 * mm),
        P("4. META DE PRODUÇÃO", "h1"),
        tabela([
            ["Item", "Valor"],
            ["Tonelagem programada", f"{tonelagem} t"],
            ["Duração programada", "conforme datas acima"],
            ["Destino", "Tancagem TK-310 / expedição a granel"],
        ], [60 * mm, 100 * mm]),
        Spacer(1, 3 * mm),
        P("5. OBSERVAÇÕES", "h1"),
    ]
    for obs in observacoes:
        corpo.append(P(f"• {obs}"))
    corpo += [Spacer(1, 6 * mm),
              assinaturas([("Elaborado", "L. Prado", inicio.split()[0]),
                           ("Verificado", "R. Nakamura", inicio.split()[0]),
                           ("Aprovado", "D. Castro", inicio.split()[0])])]
    return cab, corpo


def silo_producao():
    cab, corpo = _ordem_producao(
        "PO-2026-0417", "RA-180", "Resina Alquídica RA-180", "L-26A-0417",
        "2026-08-04 06:00", "2026-08-08 22:00", U.CAMPANHA_A.monomero_pct,
        U.CAMPANHA_A.x_min, U.CAMPANHA_A.x_max, SP_C, 385,
        ["Campanha de continuidade. Sem alteração de receita em relação à PO-2026-0411.",
         "Transição para PO-2026-0418 conforme PLN-2026-08; não parar a unidade entre campanhas.",
         "Unidade retomada em 30/07 após a parada programada PP-26-03."])
    _emitir("production", "PO-2026-0417.pdf", cab, corpo)

    cab, corpo = _ordem_producao(
        "PO-2026-0418", "RB-220", "Resina Poliéster RB-220", "L-26B-0418",
        "2026-08-08 22:00", "2026-08-16 06:00", U.CAMPANHA_B.monomero_pct,
        U.CAMPANHA_B.x_min, U.CAMPANHA_B.x_max, SP_C, 640,
        [f"Grade de maior teor de monômero ({U.CAMPANHA_B.monomero_pct:.1f}% contra "
         f"{U.CAMPANHA_A.monomero_pct:.1f}% do RA-180). Lote de matéria-prima MB-4471, "
         "certificado COA-MB-4471 anexo.",
         "Faixa de conversão mais estreita que a do RA-180 por exigência de cor do cliente "
         "(pedido PED-2026-1188). Set point térmico permanece o mesmo.",
         "Transição de grade por enriquecimento gradual da alimentação ao longo de 6 h, sem parada.",
         "Vazão de alimentação inalterada em relação à campanha anterior."],
        status="EM ANDAMENTO")
    _emitir("production", "PO-2026-0418.pdf", cab, corpo)

    # --- Certificado de análise do lote de monômero --------------------------
    cab = {"titulo": "Certificado de Análise — Lote MB-4471", "numero": "COA-MB-4471",
           "rev": "0", "data": "2026-08-05", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({
            "Certificado": "COA-MB-4471", "Lote": "MB-4471", "Material": "Anidrido/monômero MB",
            "Fornecedor": "Petroquímica Serra Azul", "Nota fiscal": "NF 220.845",
            "Recebido em": "2026-08-05", "Quantidade": "48 t", "Validade": "2027-02-05",
            "Destino": "TK-201 / PO-2026-0418",
        }),
        Spacer(1, 5 * mm),
        P("RESULTADOS", "h1"),
        tabela([
            ["Ensaio", "Método", "Especificação", "Resultado", "Situação"],
            ["Teor de monômero (assay)", "GC-FID", "min. 96,0 %", "98,6 %", "Conforme"],
            ["Índice de acidez", "ASTM D974", "máx. 0,8 mg KOH/g", "0,41", "Conforme"],
            ["Umidade", "Karl Fischer", "máx. 0,10 %", "0,04 %", "Conforme"],
            ["Cor APHA", "ASTM D1209", "máx. 60", "35", "Conforme"],
            ["Inibidor (MEHQ)", "HPLC", "180 – 220 ppm", "196 ppm", "Conforme"],
        ], [46 * mm, 26 * mm, 36 * mm, 26 * mm, 30 * mm]),
        Spacer(1, 4 * mm),
        caixa("Lote com teor de monômero na faixa alta da especificação de compra "
              "(98,6 % contra 96,4 % do lote MB-4390 anterior). Recebimento aprovado.",
              "Observação do recebimento"),
        Spacer(1, 5 * mm),
        assinaturas([("Analista", "T. Siqueira", "2026-08-05"),
                     ("Liberação", "L. Prado", "2026-08-05")]),
    ]
    _emitir("production", "COA-MB-4471.pdf", cab, corpo)

    # --- Plano mensal de campanhas (documento de baixo valor, mas real) ------
    cab = {"titulo": "Plano de Campanhas — Agosto/2026", "numero": "PLN-2026-08",
           "rev": "2", "data": "2026-07-28", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "PLN-2026-08", "Revisão": "2",
                             "Emitido": "2026-07-28", "Unidade": U.UNIDADE,
                             "Elaborado": "L. Prado", "Aprovado": "D. Castro"}),
        Spacer(1, 5 * mm),
        P("SEQUÊNCIA DE CAMPANHAS", "h1"),
        tabela([
            ["Ordem", "Grade", "Início", "Fim", "Tonelagem", "Situação"],
            ["PO-2026-0411", "RA-180", "27/07", "29/07", "160 t", "Encerrada"],
            ["—", "PARADA PP-26-03", "29/07", "30/07", "—", "Executada"],
            ["PO-2026-0414", "RA-180", "30/07", "04/08", "420 t", "Encerrada"],
            ["PO-2026-0417", "RA-180", "04/08", "08/08", "385 t", "Encerrada"],
            ["PO-2026-0418", "RB-220", "08/08", "16/08", "640 t", "Em andamento"],
            ["PO-2026-0421", "RA-180", "16/08", "23/08", "580 t", "Programada"],
        ], [26 * mm, 24 * mm, 20 * mm, 20 * mm, 24 * mm, 32 * mm]),
        Spacer(1, 4 * mm),
        P("NOTAS DE PLANEJAMENTO", "h1"),
        P("• A campanha de RB-220 foi antecipada em 5 dias em relação à Rev. 1 para atender "
          "ao pedido PED-2026-1188. A antecipação foi discutida com Operação e Processo em "
          "24/07 e não implicou alteração de condição de processo."),
        P("• Não há parada programada em agosto. A próxima janela de manutenção de "
          "equipamento estático é a PP-26-04, em outubro."),
        P("• Pendências de manutenção que não impedem operação foram remetidas para a PP-26-04."),
    ]
    _emitir("production", "PLN-2026-08.pdf", cab, corpo)


# =============================================================================
# SILO 3 — MANUTENÇÃO
# =============================================================================
def _work_order(wo, equip, tag, abertura, execucao, tipo, prioridade, solicitante,
                executante, sintoma, servico, pecas, status, observacoes,
                recomendacoes, hh, sistema="Reação / R-201"):
    cab = {"titulo": f"Ordem de Trabalho {wo} — {tag}", "numero": wo, "rev": "0",
           "data": execucao or abertura, "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({
            "OT": wo, "Status": status, "Tipo": tipo,
            "Equipamento": equip, "TAG": tag, "Sistema": sistema,
            "Abertura": abertura, "Execução": execucao or "—", "Prioridade": prioridade,
            "Solicitante": solicitante, "Executante": executante, "H·h": hh,
        }),
        Spacer(1, 5 * mm),
        P("1. SINTOMA / MOTIVO DA SOLICITAÇÃO", "h1"), P(sintoma),
        P("2. SERVIÇO EXECUTADO", "h1"),
    ]
    for item in servico:
        corpo.append(P(f"• {item}"))
    corpo += [P("3. MATERIAIS E PEÇAS", "h1")]
    if pecas:
        corpo.append(tabela([["Item", "Descrição", "P/N", "Qtd", "Origem"]] + pecas,
                            [12 * mm, 62 * mm, 34 * mm, 14 * mm, 46 * mm]))
    else:
        corpo.append(P("Nenhum material aplicado."))
    corpo += [P("4. OBSERVAÇÕES DO EXECUTANTE", "h1")]
    for obs in observacoes:
        corpo.append(P(f"• {obs}"))
    corpo += [P("5. RECOMENDAÇÕES / PENDÊNCIAS", "h1")]
    if recomendacoes:
        for rec in recomendacoes:
            corpo.append(P(f"• {rec}"))
    else:
        corpo.append(P("Nenhuma."))
    corpo += [Spacer(1, 6 * mm),
              assinaturas([("Executante", executante.split(" —")[0], execucao or abertura),
                           ("Supervisão", "J. Barbosa", execucao or abertura),
                           ("Liberação operacional", "D. Castro", execucao or abertura)])]
    return cab, corpo


def silo_manutencao():
    # --- ruído: inspeção preditiva de rotina, nada relevante -----------------
    _emitir("maintenance", "WO-3862.pdf", *_work_order(
        "WO-3862", "Bomba centrífuga de circulação de água temperada", "P-201",
        "2026-06-15", "2026-06-18", "Preditiva", "Baixa",
        "F. Almeida — Confiabilidade", EQUIPE["mec"],
        "Rota de análise de vibração trimestral do plano PM-ROT-07.",
        ["Coleta de vibração nos mancais LA e LOA em três direções.",
         "Termografia do conjunto motor-bomba.",
         "Verificação de alinhamento a laser — dentro de tolerância."],
        [],
        "ENCERRADA",
        ["Níveis globais de vibração em 1,8 mm/s RMS, faixa A da ISO 10816.",
         "Temperatura de mancais 52 °C. Sem indício de cavitação ou desbalanceamento.",
         "Vazão de circulação estável em 60 m³/h, conforme placa."],
        ["Manter na rota trimestral. Próxima coleta em 09/2026."], "4,0",
        sistema="Utilidades / circuito de água temperada"))

    # --- pista falsa REAL: o analisador estava mesmo com desvio --------------
    _emitir("maintenance", "WO-3871.pdf", *_work_order(
        "WO-3871", "Analisador em linha de conversão (NIR)", "AT-205",
        "2026-07-10", "2026-07-14", "Corretiva", "Média",
        "T. Siqueira — Laboratório", EQUIPE["instr"],
        "Laboratório reporta discrepância recorrente entre o resultado de LIMS e a leitura "
        "de AT-205, com o analisador lendo consistentemente acima do laboratório.",
        ["Verificação da célula de fluxo e limpeza da janela óptica (depósito leve de resina).",
         "Recalibração multivariada com 12 amostras de referência do laboratório.",
         "Verificação da compensação de temperatura da célula.",
         "Validação pós-serviço com 4 amostras cegas."],
        [["1", "Janela óptica de safira, célula NIR", "NIR-CF-12", "1", "Estoque"],
         ["2", "Kit de vedação da célula de fluxo", "NIR-SK-12", "1", "Estoque"]],
        "ENCERRADA",
        ["Desvio médio antes do serviço: +0,011 em fração de conversão (analisador alto).",
         "Após recalibração, desvio residual de +0,002 nas amostras cegas.",
         "Depósito na janela compatível com o tempo desde a última limpeza (7 meses)."],
        ["Reduzir o intervalo de limpeza da janela de 6 para 4 meses.",
         "AT-205 continua sendo indicação; o dado de liberação de lote é o LIMS."], "6,5",
        sistema="Reação / analisadores"))

    # --- A ORDEM CENTRAL DO CASO --------------------------------------------
    _emitir("maintenance", "WO-3874.pdf", *_work_order(
        "WO-3874", "Válvula de controle de admissão de água de resfriamento", "FV-201",
        "2026-07-16", "2026-07-29", "Corretiva programada", "Alta",
        "C. Ferreira — Controle e Automação", EQUIPE["instr"],
        "Válvula com histerese crescente observada pelo painel desde 05/2026 e ruído "
        "audível em aberturas intermediárias. Serviço agendado para a parada PP-26-03.",
        ["Bloqueio e despressurização do ramal; desmontagem do corpo.",
         "Inspeção interna: sede e obturador com erosão na região de saída, fora do "
         "critério de reaproveitamento da NORDVALVE (perda de perfil > 0,4 mm). Conjunto "
         "condenado.",
         "Trim original P/N NV4000-40-STD indisponível em almoxarifado (última "
         "saída em 03/2026, reposição não programada).",
         "Aplicado conjunto disponível em estoque P/N NV4000-22-AC — mesma classe de "
         "corpo (ANSI 300, DN 80), mesmo curso nominal, com gaiola anticavitação.",
         "Substituição de gaxeta, anel de sede e kit de vedação.",
         "Verificação de curso em bancada: 0 – 100 % completo, sem travamento.",
         "Posicionador digital recalibrado: 4 mA = 0 %, 20 mA = 100 %, linearidade "
         "dentro de ± 0,5 % do curso.",
         "Teste de estanqueidade classe IV aprovado. Válvula liberada para operação."],
        [["1", "Conjunto de trim (gaiola, obturador e sede), Cv 22, gaiola "
               "anticavitação", "NV4000-22-AC", "1", "Almoxarifado — estoque"],
         ["2", "Kit de gaxeta de grafite", "NV4000-PK", "1", "Almoxarifado"],
         ["3", "Anel de sede metálico", "NV4000-SR", "1", "Almoxarifado"],
         ["4", "Conjunto de trim Cv 40 padrão", "NV4000-40-STD", "0",
          "INDISPONÍVEL — não aplicado"]],
        "ENCERRADA",
        ["O conjunto NV4000-22-AC é o mesmo especificado para a FV-305 da unidade U-300 e "
         "estava disponível para uso imediato.",
         "A opção pela gaiola anticavitação levou em conta o histórico de erosão desta "
         "válvula, que motivou esta própria ordem.",
         "Válvula testada em bancada com ar de instrumento. Não foi feito ensaio de "
         "vazão — a bancada da oficina não dispõe de recurso para isso.",
         "Tempo de curso total medido: 58 s de 0 a 100 %."],
        ["Repor o conjunto NV4000-40-STD no almoxarifado (RC-2026-2214 emitida).",
         "Confirmar o dimensionamento do trim aplicado junto a Processo na próxima parada.",
         "Reavaliar o serviço de FV-201 quanto a erosão após 12 meses."], "22,0"))

    # --- ruído: serviço simultâneo, sem relação ------------------------------
    _emitir("maintenance", "WO-3879.pdf", *_work_order(
        "WO-3879", "Bomba centrífuga de circulação de água temperada", "P-201",
        "2026-07-20", "2026-07-29", "Corretiva programada", "Média",
        EQUIPE["coord"], EQUIPE["mec"],
        "Vazamento por gaxeta do selo, gotejamento contínuo observado pela operação.",
        ["Substituição do jogo de gaxetas e da luva de eixo.",
         "Reaperto do preme-gaxeta e verificação de gotejamento controlado.",
         "Teste de partida com a unidade em circulação."],
        [["1", "Jogo de gaxetas de grafite trançado", "P201-PK-08", "1", "Estoque"],
         ["2", "Luva de eixo em aço inox 316", "P201-SL-02", "1", "Estoque"]],
        "ENCERRADA",
        ["Vazamento eliminado. Gotejamento de referência ajustado em ~8 gotas/min.",
         "Vazão de circulação sem alteração após o serviço: 60 m³/h."],
        [], "8,0", sistema="Utilidades / circuito de água temperada"))

    # --- contribuinte parcial, DEIXADA PENDENTE ------------------------------
    _emitir("maintenance", "WO-3882.pdf", *_work_order(
        "WO-3882", "Torre de resfriamento — célula 2", "TR-901",
        "2026-08-03", "", "Corretiva", "Média",
        "F. Almeida — Confiabilidade", "—",
        "Inspeção de rotina identificou incrustação e colmatação parcial do enchimento da "
        "célula 2, com distribuição de água irregular sobre o pacote. Aproximação da torre "
        "medida em 6,8 K contra 4,0 K de projeto.",
        ["Serviço não iniciado. Requer parada da célula 2 e remanejamento de carga térmica "
         "para as células 1 e 3."],
        [["1", "Pacote de enchimento tipo filme, PVC", "TR901-FL-02", "18", "A adquirir"],
         ["2", "Bicos aspersores", "TR901-NZ", "40", "A adquirir"]],
        "PENDENTE — AGUARDANDO JANELA",
        ["Com as três células em operação a temperatura de suprimento permanece dentro da "
         "faixa aceitável na maior parte do dia, com excursões no período da tarde.",
         "Planejamento informou não haver janela de parada da célula em agosto; "
         "serviço remetido para a PP-26-04 (outubro).",
         "Material com prazo de entrega de 45 dias, requisição RC-2026-2301 emitida em 05/08."],
        ["Monitorar TT-203 durante a onda de calor prevista para a segunda quinzena.",
         "Reavaliar prioridade se a temperatura de suprimento ultrapassar 34 °C de forma "
         "sustentada."], "2,0", sistema="Utilidades / torre de resfriamento"))

    # --- pista falsa: chamado da operação sobre a própria FV-201 -------------
    _emitir("maintenance", "WO-3888.pdf", *_work_order(
        "WO-3888", "Válvula de controle de admissão de água de resfriamento", "FV-201",
        "2026-08-11", "2026-08-11", "Corretiva", "Média",
        EQUIPE["opA"], EQUIPE["instr"],
        "Operação relata que FV-201 \"opera muito mais aberta que o normal\" desde a "
        "campanha atual e solicita verificação do posicionador.",
        ["Verificação de malha 4–20 mA entre DCS e posicionador: sinal conferido em "
         "cinco pontos (0, 25, 50, 75 e 100 %), erro máximo de 0,3 % do curso.",
         "Comparação entre saída do TIC-201 e leitura de ZT-201: desvio máximo 0,4 %.",
         "Verificação de pressão do ar de instrumento: 5,8 barg, normal.",
         "Teste de curso completo com a malha em manual, autorizado pela operação: "
         "válvula percorre 0 a 100 % sem travamento nem histerese perceptível.",
         "Posicionador recalibrado por precaução (span e zero)."],
        [],
        "ENCERRADA — SEM ANOMALIA ENCONTRADA",
        ["Não foi identificada anomalia no posicionador nem na malha de comando. "
         "A válvula responde corretamente ao sinal recebido.",
         "A abertura elevada acompanha o comando do TIC-201, ou seja, é o controlador que "
         "está pedindo essa abertura.",
         "Informado à operação que o comportamento não é de instrumento e que a avaliação "
         "de carga térmica é atribuição de Processo."],
        ["Encaminhar a Processo a avaliação da carga térmica da campanha atual."], "3,5"))

    # --- pista falsa: instrumentação de temperatura --------------------------
    _emitir("maintenance", "WO-3891.pdf", *_work_order(
        "WO-3891", "Transmissor de temperatura do reator", "TT-201",
        "2026-08-13", "2026-08-13", "Corretiva", "Alta",
        EQUIPE["coord"], EQUIPE["instr"],
        "Durante condição anormal, operação solicita verificação de TT-201 por suspeita de "
        "leitura incorreta de temperatura do reator.",
        ["Loop check completo com calibrador de precisão em cinco pontos "
         "(200, 215, 230, 240 e 250 °C).",
         "Comparação com o termopar de referência TW-201B instalado no mesmo poço.",
         "Verificação de isolação e de junta fria do transmissor."],
        [],
        "ENCERRADA — INSTRUMENTO CONFORME",
        ["Erro máximo encontrado: 0,6 °C a 240 °C, dentro da tolerância de ± 1,5 °C.",
         "Diferença para TW-201B de 0,4 °C. A indicação do painel está correta.",
         "A temperatura elevada registrada é real."],
        [], "3,0"))


# =============================================================================
# SILO 4 — OPERAÇÕES (relatórios de turno)
# =============================================================================
def _relatorio_turno(data, turno, operador, coordenador, po, produto, resumo,
                     eventos, alarmes, acoes, pendencias, comentarios):
    numero = f"RT-{data.replace('-', '')}-{turno}"
    cab = {"titulo": f"Relatório de Turno — {data} — Turno {turno}", "numero": numero,
           "rev": "0", "data": data, "classificacao": "USO INTERNO"}
    horario = {"A": "06:00 – 14:00", "B": "14:00 – 22:00", "C": "22:00 – 06:00"}[turno]
    corpo = [
        bloco_identificacao({
            "Relatório": numero, "Data": data, "Turno": f"{turno}  ({horario})",
            "Unidade": U.UNIDADE, "Operador": operador.split(" —")[0],
            "Coordenação": coordenador.split(" —")[0],
            "Ordem em produção": po, "Produto": produto, "Modo TIC-201": "AUTO",
        }),
        Spacer(1, 4 * mm),
        P("SITUAÇÃO DA UNIDADE", "h1"), P(resumo),
        P("EVENTOS DO TURNO", "h1"),
        tabela([["Hora", "Registro"]] + eventos, [16 * mm, 152 * mm]),
    ]
    if alarmes:
        corpo += [P("ALARMES", "h1"),
                  tabela([["Hora", "TAG", "Descrição", "Tratamento"]] + alarmes,
                         [16 * mm, 22 * mm, 62 * mm, 68 * mm])]
    corpo += [P("AÇÕES EXECUTADAS", "h1")]
    for a in acoes:
        corpo.append(P(f"• {a}"))
    corpo += [P("PENDÊNCIAS PARA O PRÓXIMO TURNO", "h1")]
    if pendencias:
        for p_ in pendencias:
            corpo.append(P(f"• {p_}"))
    else:
        corpo.append(P("Nenhuma."))
    if comentarios:
        corpo += [P("COMENTÁRIOS DO OPERADOR", "h1"), caixa(comentarios)]
    corpo += [Spacer(1, 5 * mm),
              assinaturas([("Operador", operador.split(" —")[0], data),
                           ("Coordenação", coordenador.split(" —")[0], data)])]
    return numero, cab, corpo


def silo_operacoes():
    rels = [
        # --- partida após a parada: o primeiro sinal, e ninguém agiu --------
        ("2026-07-30", "A", EQUIPE["opA"], EQUIPE["coord"], "PO-2026-0414",
         "Resina Alquídica RA-180",
         "Partida de U-200 após a parada programada PP-26-03. Sequência de partida conforme "
         "POP-U200-002 sem intercorrências. Reator estabilizado no set point às 09:40, "
         "produção normalizada.",
         [["06:00", "Assumido o turno com a unidade em circulação a frio."],
          ["07:15", "Início de alimentação de R-201, rampa conforme procedimento."],
          ["09:40", "TIC-201 em automático, PV estável no set point de 229,2 °C."],
          ["10:30", "Primeira amostra pós-partida enviada ao laboratório."],
          ["12:05", "LIMS aprovou a amostra. Produção liberada para tancagem."]],
         [], ["Partida conforme POP-U200-002.",
              "Comunicado à instrumentação, por rádio, o comportamento de FV-201 descrito abaixo."],
         ["Acompanhar abertura de FV-201 ao longo do dia."],
         "FV-201 está trabalhando bem mais aberta do que antes da parada. Antes ficava por "
         "volta de 30 %, agora está firme perto de 57 – 58 %. A temperatura está boa, no set "
         "point, e a válvula responde normalmente quando o controlador pede. Comentei com o "
         "pessoal da instrumentação, disseram que a válvula foi revisada na parada e que o "
         "curso foi testado, está tudo certo. Fica o registro."),

        # --- transição de grade --------------------------------------------
        ("2026-08-08", "B", EQUIPE["opB"], EQUIPE["coord"], "PO-2026-0417 → PO-2026-0418",
         "RA-180 → RB-220",
         "Encerramento da PO-2026-0417 e início da transição de grade para RB-220 conforme "
         "PLN-2026-08. Transição por enriquecimento gradual, sem parada da unidade.",
         [["14:00", "Assumido o turno, unidade em RA-180, tudo normal."],
          ["19:20", "Última amostra da PO-2026-0417 aprovada."],
          ["22:00", "Iniciada a transição: alinhado TK-201 para o lote MB-4471 e "
                    "iniciado o enriquecimento da alimentação."]],
         [], ["Alinhamento de tancagem para MB-4471 conforme POP-U200-014 § 9.",
              "Set point de TIC-201 mantido em 229,2 °C, conforme a PO."],
         ["Acompanhar a conversão durante o enriquecimento; primeira amostra de RB-220 "
          "prevista para 04:00."],
         "Transição tranquila. FV-201 continua na faixa dos 60 %, já é o normal dela desde a "
         "parada."),

        ("2026-08-09", "C", EQUIPE["opC"], EQUIPE["coord"], "PO-2026-0418",
         "Resina Poliéster RB-220",
         "Transição de grade concluída às 04:00. Unidade estabilizada em RB-220. Temperatura "
         "no set point, conversão dentro da faixa da nova especificação.",
         [["22:00", "Assumido o turno com o enriquecimento em andamento."],
          ["01:20", "Alarme de conversão alta piscando durante o enriquecimento, "
                    "normalizou sozinho."],
          ["04:00", "Alimentação com o lote MB-4471 completo. PO-2026-0418 em produção."],
          ["05:30", "FV-201 subiu para a faixa de 70 %. Temperatura no set point."]],
         [["01:20", "QAH-205", "Conversão acima da especificação", "Transitório de "
                    "enriquecimento, normalizou sem intervenção"]],
         ["Acompanhamento da transição conforme POP-U200-014 § 9.",
          "Amostra de partida de campanha coletada às 04:00 e enviada ao laboratório."],
         ["Confirmar aprovação da primeira amostra de RB-220."],
         "A válvula de resfriamento subiu bastante depois que entrou o grade novo, de uns "
         "60 % para 70 %. O RB-220 esquenta mais mesmo, é esperado. A temperatura está "
         "redonda no set point."),

        # --- o alarme começa ------------------------------------------------
        ("2026-08-10", "A", EQUIPE["opA"], EQUIPE["coord"], "PO-2026-0418",
         "Resina Poliéster RB-220",
         "Unidade estável em RB-220, produção dentro da especificação. Alarme de abertura "
         "alta de FV-201 começou a atuar de forma intermitente ao longo do turno.",
         [["06:00", "Assumido o turno, unidade normal."],
          ["05:55", "ZAH-201 atuou pela primeira vez (registro do turno anterior)."],
          ["08:30", "ZAH-201 atuando e normalizando várias vezes ao longo da manhã."],
          ["11:00", "Amostra do laboratório aprovada, conversão e cor dentro da faixa."],
          ["14:15", "Alarme de água de torre quente atuou à tarde, normalizou à noite."]],
         [["05:55", "ZAH-201", "Curso alto FV-201 (> 80 %)", "Reconhecido; abertura "
                    "acompanha a carga térmica"],
          ["14:15", "TAH-203", "Água de torre quente (> 32 °C)", "Reconhecido; comunicado "
                    "às utilidades"]],
         ["Reconhecimento dos alarmes no console.",
          "Comunicado às utilidades a temperatura da torre; informado que a célula 2 está "
          "com o enchimento sujo e que o serviço está programado para outubro."],
         ["ZAH-201 deve continuar atuando durante o dia; acompanhar."],
         "O ZAH-201 está atuando e saindo o tempo todo, é chato porque toca junto com os "
         "outros e atrapalha ver o que importa. A temperatura do reator está boa, o produto "
         "está aprovado. A água da torre está mais quente que o normal, deve ser o calor "
         "desses dias."),

        # --- a supressão -----------------------------------------------------
        ("2026-08-11", "A", EQUIPE["opA"], EQUIPE["coord"], "PO-2026-0418",
         "Resina Poliéster RB-220",
         "Unidade estável, produção aprovada. Alarme ZAH-201 suprimido no console por "
         "atuação repetitiva. Solicitada verificação de FV-201 à manutenção.",
         [["06:00", "Assumido o turno. ZAH-201 atuando de forma repetitiva desde ontem."],
          ["08:00", "ZAH-201 suprimido no console, autorizado pela coordenação, "
                    "conforme POP-U200-014 § 7.3."],
          ["08:20", "Aberta a WO-3888 solicitando verificação do posicionador de FV-201."],
          ["11:25", "TAH-203 atuou novamente."],
          ["13:40", "Instrumentação concluiu a WO-3888 sem encontrar anomalia."]],
         [["08:00", "ZAH-201", "Curso alto FV-201 (> 80 %)", "SUPRIMIDO no console — "
                    "atuação repetitiva, autorizado por D. Castro"],
          ["11:25", "TAH-203", "Água de torre quente (> 32 °C)", "Reconhecido"]],
         ["Supressão de ZAH-201 registrada no livro de alarmes suprimidos, com prazo de "
          "revisão em 7 dias conforme POP-U200-014 § 7.3.",
          "Abertura da WO-3888.",
          "Teste de curso de FV-201 em manual autorizado e acompanhado por operação, com "
          "retorno a automático em seguida."],
         ["Revisar a supressão de ZAH-201 até 18/08.",
          "Aguardar posição de Processo sobre a carga térmica da campanha."],
         "A instrumentação testou a válvula toda e disse que ela está boa, que quem está "
         "pedindo essa abertura é o controlador. Ficou combinado que o pessoal de processo "
         "vai olhar a carga térmica do RB-220. Enquanto isso deixamos o alarme suprimido "
         "porque estava tocando direto sem a gente poder fazer nada."),

        # --- o upset --------------------------------------------------------
        ("2026-08-12", "C", EQUIPE["opC"], EQUIPE["coord"], "PO-2026-0418",
         "Resina Poliéster RB-220",
         "Condição anormal a partir de 22:45. Temperatura da alimentação subiu por perda de "
         "controle em E-202 (U-100), FV-201 foi para 100 % e a temperatura do reator "
         "começou a subir acima do set point.",
         [["22:00", "Assumido o turno com a unidade normal, FV-201 em torno de 93 %."],
          ["22:40", "TT-204 começou a subir. Contactado o painel da U-100."],
          ["22:50", "FV-201 chegou a 100 % e ficou lá. Alarme ZAHH-201 atuou."],
          ["23:09", "Unidade declarada em condição anormal e comunicada à coordenação."],
          ["23:10", "TAH-201 atuou. Temperatura do reator acima de 235 °C."],
          ["02:00", "Set point de TIC-201 reduzido para 227,1 °C tentando trazer a "
                    "temperatura para baixo."],
          ["03:30", "Sem efeito. A válvula continua em 100 %, a temperatura não desceu."],
          ["04:00", "Amostra reprovada pelo laboratório: cor 6,6 e viscosidade 2284."]],
         [["22:50", "ZAHH-201", "FV-201 saturada aberta (≥ 98 %)", "Reconhecido"],
          ["23:10", "TAH-201", "Temperatura alta R-201 (> 235,2 °C)", "Reconhecido; "
                    "coordenação acionada"]],
         ["U-100 acionada por telefone e por rádio às 22:45 e às 23:30.",
          "Set point de TIC-201 reduzido de 229,2 °C para 227,1 °C às 02:00, autorizado "
          "pela coordenação.",
          "Produção da madrugada segregada em TK-311 aguardando decisão da qualidade.",
          "Ronda de campo em R-201 e no circuito de resfriamento: sem vazamento, sem "
          "ruído anormal, P-201 operando normal, pressão de água de torre normal."],
         ["Manter a produção segregada.",
          "Cobrar posição da U-100 sobre E-202.",
          "Solicitar verificação de TT-201."],
         "Baixei o set point achando que ia ajudar mas não mudou nada, a válvula já estava "
         "toda aberta desde antes. Não tem mais o que abrir. A pressão da água de "
         "resfriamento está normal, a bomba está normal, olhei tudo em campo. O problema "
         "veio de fora, da temperatura da carga."),

        # --- rescaldo --------------------------------------------------------
        ("2026-08-13", "A", EQUIPE["opA"], EQUIPE["coord"], "PO-2026-0418",
         "Resina Poliéster RB-220",
         "Unidade permanece em condição anormal. Temperatura da alimentação ainda alta. "
         "Produto continua fora de especificação. Investigação acionada pela coordenação.",
         [["06:00", "Assumido o turno com a unidade anormal, FV-201 em 100 %."],
          ["08:00", "Amostra reprovada novamente: cor 6,4, viscosidade 2248."],
          ["09:15", "Aberta a WO-3891 para verificação de TT-201."],
          ["12:30", "Instrumentação confirmou que TT-201 está correto."],
          ["14:00", "Set point de TIC-201 restaurado para 229,2 °C sem efeito perceptível."]],
         [["—", "TAH-201", "Temperatura alta R-201", "Permanece ATIVO desde 12/08 23:10"],
          ["—", "ZAHH-201", "FV-201 saturada aberta", "Permanece ATIVO desde 12/08 22:50"]],
         ["Produção mantida em segregação (TK-311).",
          "Coordenação acionou Processo e Confiabilidade para investigação.",
          "Solicitado à U-100 relatório da ocorrência de E-202."],
         ["Investigação em andamento — pacote de dados solicitado ao PIMS.",
          "Decisão sobre continuidade da campanha pendente."],
         "Já tentamos tudo que está na nossa mão. A válvula está toda aberta e não abaixa a "
         "temperatura. O TT-201 foi conferido e está certo. A temperatura da carga da U-100 "
         "ainda não normalizou. O produto está saindo escuro e grosso."),
    ]
    for data, turno, op, coord, po, prod, resumo, ev, al, ac, pend, com in rels:
        numero, cab, corpo = _relatorio_turno(data, turno, op, coord, po, prod,
                                              resumo, ev, al, ac, pend, com)
        _emitir("operations", f"{numero}.pdf", cab, corpo)


# =============================================================================
# SILO 5 — PROCESSO
# =============================================================================
def silo_processo():
    figs = diagramas.gerar_todos(os.path.join(RAIZ, "figures"))

    # --- descrição de processo ----------------------------------------------
    cab = {"titulo": "Descrição de Processo — Seção de Reação", "numero": "U-200-PD-001",
           "rev": "5", "data": "2025-11-12", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "U-200-PD-001", "Revisão": "5",
                             "Data": "2025-11-12", "Unidade": U.UNIDADE,
                             "Elaborado": "R. Nakamura", "Aprovado": "D. Castro"}),
        Spacer(1, 4 * mm),
        P("1. OBJETIVO", "h1"),
        P("Descrever a seção de reação da unidade U-200, seus equipamentos principais, o "
          "circuito de resfriamento e as condições normais de operação. Aplica-se a todos "
          "os grades produzidos em R-201."),
        P("2. DESCRIÇÃO GERAL", "h1"),
        P("A U-200 produz resinas alquídicas e poliéster por reação exotérmica em fase "
          "líquida, em reator contínuo de tanque agitado. A carga é preparada em TK-201, "
          f"pré-aquecida em E-202 até {C(0.0):.1f} °C e alimentada continuamente a R-201 a "
          "9,0 m³/h. O reator opera com volume útil de 12 m³, o que corresponde a um tempo "
          f"de residência nominal de {U.TAU_MIN:.0f} minutos."),
        P("A reação é exotérmica e de primeira ordem em relação ao monômero. O calor de "
          "reação é removido pela camisa do reator, percorrida por um circuito fechado de "
          "água temperada. O produto transborda por vertedouro para TK-310."),
        P("3. CIRCUITO DE RESFRIAMENTO", "h1"),
        P("O circuito de água temperada é fechado e circula a 60 m³/h por P-201. O fluido "
          "sai da camisa aquecido, e a válvula de três vias FV-201 divide a corrente entre "
          "um desvio direto e o trocador E-201, onde é resfriada contra a água de torre "
          "de TR-901. Quanto maior a abertura de FV-201, maior a fração desviada por E-201 "
          "e menor a temperatura do fluido que retorna à camisa."),
        P("Consequência operacional importante: <b>FV-201 não regula uma vazão de "
          "refrigerante para o processo, e sim a temperatura do fluido da camisa</b>. Com a "
          f"válvula totalmente fechada a camisa tende à temperatura do próprio reator "
          f"(sem resfriamento); com a válvula totalmente aberta, a camisa tende ao limite "
          f"frio do circuito, em torno de {UCF_C:.0f} °C na condição de projeto."),
        P("4. CONDIÇÕES NORMAIS DE OPERAÇÃO", "h1"),
        tabela([
            ["Variável", "TAG", "Normal", "Faixa", "Unidade"],
            ["Temperatura do reator", "TT-201", f"{SP_C:.1f}",
             f"{ENV_LO_C:.1f} – {ENV_HI_C:.1f}", "°C"],
            ["Vazão de carga", "FT-204", "9,0", "8,5 – 9,5", "m³/h"],
            ["Temperatura da carga", "TT-204", f"{C(0.0):.1f}", "131 – 136", "°C"],
            ["Abertura de FV-201", "ZT-201", "25 – 40", "0 – 100", "% curso"],
            ["Vazão pelo trocador E-201", "FT-201", "11 – 18", "0 – 45", "m³/h"],
            ["Temperatura da camisa", "TT-202", "125 – 134", f"{UCF_C:.0f} – 229", "°C"],
            ["Loop na saída de E-201", "TT-207", f"{UCF_C:.0f}", "85 – 100", "°C"],
            ["Água de torre", "TT-203", "28", "24 – 32", "°C"],
            ["Conversão", "AT-205 / LIMS", "0,765", "conforme a PO", "fração"],
            ["Pressão do reator", "—", "3,5", "2,8 – 4,2", "barg"],
        ], [42 * mm, 26 * mm, 26 * mm, 44 * mm, 22 * mm]),
        Spacer(1, 3 * mm),
        caixa("A faixa de abertura de FV-201 depende do grade em produção e da temperatura "
              "da água de torre. Aberturas sustentadas acima de 60 % indicam carga térmica "
              "acima do previsto para o grade e devem ser comunicadas a Processo.",
              "Nota de operação"),
        P("5. EQUIPAMENTOS PRINCIPAIS", "h1"),
        tabela([
            ["TAG", "Equipamento", "Dados principais"],
            ["R-201", "Reator CSTR encamisado", "12 m³ úteis, AISI 316L, PMTA 6,0 barg, agitador 22 kW"],
            ["E-201", "Trocador loop / água de torre", "Placas gaxetadas, 620 kW, AISI 316"],
            ["E-202", "Pré-aquecedor de carga", "Casco e tubo, vapor de baixa, 180 kW"],
            ["P-201", "Bomba de circulação do loop", "Centrífuga, 60 m³/h, 32 mca, 11 kW"],
            ["FV-201", "Válvula de controle de três vias", "DN 80, ANSI 300, NORDVALVE série 4000"],
            ["TK-201", "Pulmão de alimentação", "30 m³, aço carbono revestido"],
            ["TR-901", "Torre de resfriamento (compartilhada)", "3 células, 1900 m³/h total"],
            ["PSV-201", "Válvula de segurança de R-201", "Ajuste 6,0 barg, descarga para blowdown"],
        ], [20 * mm, 54 * mm, 94 * mm]),
        P("6. DOCUMENTOS DE REFERÊNCIA", "h1"),
        tabela([
            ["Documento", "Título"],
            ["U-200-PFD-001", "Fluxograma de processo — seção de reação"],
            ["U-200-PID-201", "P&ID — R-201 e circuito de resfriamento"],
            ["U-200-DB-001", "Design basis"],
            ["U-200-CP-001", "Filosofia de controle"],
            ["POP-U200-014", "Procedimento operacional — operação normal de R-201"],
            ["HZ-U200-2024-03", "Estudo HAZOP"],
        ], [36 * mm, 132 * mm]),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "R. Nakamura", "2025-11-12"),
                     ("Verificado", "C. Ferreira", "2025-11-14"),
                     ("Aprovado", "D. Castro", "2025-11-20")]),
    ]
    _emitir("process", "U-200-PD-001_descricao_processo.pdf", cab, corpo)

    # --- PFD -----------------------------------------------------------------
    cab = {"titulo": "Fluxograma de Processo — Seção de Reação", "numero": "U-200-PFD-001",
           "rev": "4", "data": "2025-11-12", "classificacao": "USO INTERNO"}
    corpo = [bloco_identificacao({"Documento": "U-200-PFD-001", "Revisão": "4",
                                  "Data": "2025-11-12", "Unidade": U.UNIDADE,
                                  "Desenhado": "Eng. de Projetos", "Aprovado": "R. Nakamura"}),
             Spacer(1, 4 * mm)]
    corpo += figura(figs["pfd"], 168, "Correntes numeradas: ① carga pré-aquecida  "
                    "② produto do reator  ③ loop de água temperada  ④ água de torre.")
    corpo += [Spacer(1, 4 * mm),
              P("BALANÇO TÉRMICO DE PROJETO (grade de referência RA-180)", "h1"),
              tabela([
                  ["Item", "Valor", "Unidade", "Observação"],
                  ["Calor liberado pela reação", f"{Q_REACAO_KW:.0f}", "kW",
                   "grade RA-180, conversão de projeto"],
                  ["Calor removido com o produto (sensível)", f"{Q_PRODUTO_KW:.0f}", "kW",
                   f"carga entra a {C(0.0):.1f} °C e sai a {SP_C:.1f} °C"],
                  ["Calor removido pela camisa", f"{Q_CAMISA_KW:.0f}", "kW",
                   "regime permanente — é esta parcela que FV-201 regula"],
                  ["Área de troca da camisa", f"{AREA_CAMISA_M2:.1f}", "m²",
                   "meia-cana em espiral, 4 passes"],
                  ["Coeficiente global U", f"{U_GLOBAL_WM2K:.0f}", "W/m²·K",
                   "produto viscoso, com agitação nominal"],
                  ["UA da camisa", f"{UA_WK / 1000:.2f}", "kW/K", "—"],
                  ["ΔT médio camisa–reator", f"{DT_CAMISA_K:.0f}", "K",
                   "reator a {:.0f} °C, camisa a {:.0f} °C".format(SP_C, C(0.0))],
              ], [56 * mm, 22 * mm, 22 * mm, 68 * mm])]
    _emitir("process", "U-200-PFD-001_pfd.pdf", cab, corpo)

    # --- P&ID ----------------------------------------------------------------
    cab = {"titulo": "P&ID — R-201 e Circuito de Resfriamento", "numero": "U-200-PID-201",
           "rev": "6", "data": "2026-02-18", "classificacao": "USO INTERNO"}
    corpo = [bloco_identificacao({"Documento": "U-200-PID-201", "Revisão": "6",
                                  "Data": "2026-02-18", "Unidade": U.UNIDADE,
                                  "Desenhado": "Eng. de Projetos", "Aprovado": "C. Ferreira"}),
             Spacer(1, 4 * mm)]
    corpo += figura(figs["pid"], 168)
    corpo += [Spacer(1, 4 * mm), P("ÍNDICE DE INSTRUMENTOS", "h1"),
              tabela([["TAG", "Serviço", "Faixa", "Sinal", "Localização"]] + [
                  ["TT-201", "Temperatura de R-201", "150 – 300 °C", "4–20 mA", "Poço TW-201A"],
                  ["TIC-201", "Controlador de temperatura", "150 – 300 °C", "—", "DCS"],
                  ["TAH-201", "Alarme de temperatura alta", f"{TAH_C:.1f} °C", "—", "DCS"],
                  ["TAL-201", "Alarme de temperatura baixa", f"{TAL_C:.1f} °C", "—", "DCS"],
                  ["TAHH-201", "Intertravamento de temperatura", f"{TAHH_C:.1f} °C", "—", "SIS"],
                  ["FV-201", "Válvula de três vias do loop", "0 – 100 %", "4–20 mA", "Campo"],
                  ["ZT-201", "Posição de FV-201", "0 – 100 %", "4–20 mA", "Posicionador"],
                  ["ZAH-201", "Alarme de curso alto", f"{100 * U.TRAVEL_ZAH:.0f} %", "—", "DCS"],
                  ["ZAHH-201", "Alarme de válvula saturada", f"{100 * U.TRAVEL_SAT:.0f} %", "—", "DCS"],
                  ["FT-201", "Vazão pelo trocador E-201", "0 – 50 m³/h", "4–20 mA", "Campo"],
                  ["TT-202", "Loop na entrada da camisa", "50 – 250 °C", "4–20 mA", "Campo"],
                  ["TT-203", "Água de torre para E-201", "0 – 60 °C", "4–20 mA", "Campo"],
                  ["TT-204", "Carga para R-201", "50 – 200 °C", "4–20 mA", "Campo"],
                  ["TT-207", "Loop na saída de E-201", "50 – 200 °C", "4–20 mA", "Campo"],
                  ["FT-204", "Vazão de carga", "0 – 15 m³/h", "4–20 mA", "Campo"],
                  ["AT-205", "Conversão em linha (NIR)", "0 – 1 fração", "4–20 mA", "Campo"],
                  ["QAH-205", "Alarme de conversão alta", "conforme a PO", "—", "DCS"],
                  ["PSV-201", "Alívio de R-201", "6,0 barg", "—", "Campo"],
              ], [20 * mm, 54 * mm, 30 * mm, 22 * mm, 42 * mm])]
    _emitir("process", "U-200-PID-201_pid.pdf", cab, corpo)

    # --- procedimento operacional -------------------------------------------
    cab = {"titulo": "Procedimento Operacional — Operação Normal de R-201",
           "numero": "POP-U200-014", "rev": "8", "data": "2026-01-30",
           "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "POP-U200-014", "Revisão": "8",
                             "Data": "2026-01-30", "Unidade": U.UNIDADE,
                             "Elaborado": "D. Castro", "Aprovado": "R. Nakamura",
                             "Próxima revisão": "2028-01-30"}),
        Spacer(1, 4 * mm),
        P("1. APLICAÇÃO", "h1"),
        P("Operação em regime da seção de reação da U-200, para todos os grades. Não cobre "
          "partida, parada nem emergência (ver POP-U200-002 e POP-U200-009)."),
        P("2. VERIFICAÇÕES DE ROTINA (a cada turno)", "h1"),
        tabela([
            ["#", "Verificação", "Critério de aceitação", "Ação se fora"],
            ["2.1", "TT-201 dentro do envelope", f"{ENV_LO_C:.1f} – {ENV_HI_C:.1f} °C",
             "Verificar modo do TIC-201; comunicar a coordenação"],
            ["2.2", "TIC-201 em AUTO", "AUTO", "Retornar a AUTO após estabilizar"],
            ["2.3", "Abertura de FV-201", "≤ 60 % em regime",
             "Registrar no relatório de turno e comunicar a Processo"],
            ["2.4", "Vazão por E-201 (FT-201)", "coerente com a abertura",
             "Abrir OT de verificação"],
            ["2.5", "Temperatura da água de torre", "≤ 32 °C", "Comunicar às utilidades"],
            ["2.6", "Amostra de laboratório", "conforme a PO em vigor",
             "Segregar produção e comunicar a qualidade"],
            ["2.7", "Alarmes suprimidos", "nenhum sem prazo de revisão", "Ver § 7.3"],
        ], [10 * mm, 46 * mm, 44 * mm, 68 * mm]),
        P("3. AJUSTE DE SET POINT", "h1"),
        P("O set point de temperatura de R-201 é definido pela ordem de produção em vigor e "
          "<b>não deve ser alterado pela operação</b> exceto nas situações de § 3.1 e § 3.2, "
          "sempre com registro no relatório de turno."),
        P("<b>3.1</b> — Resultado de laboratório fora de especificação de conversão: ajustar "
          "o set point em passos de no máximo 2,0 °C, aguardando 2 h entre passos, dentro do "
          f"envelope de {ENV_LO_C:.1f} a {ENV_HI_C:.1f} °C, com autorização da coordenação. "
          "Comunicar a Processo se forem necessários mais de dois passos."),
        P("<b>3.2</b> — Condição anormal com temperatura acima do set point: reduzir o set "
          "point é admissível como medida imediata, <b>desde que verificado antes que a "
          "malha ainda tenha autoridade</b>, isto é, que FV-201 não esteja saturada. Com "
          "FV-201 em 100 % a redução do set point não produz efeito sobre a temperatura."),
        P("4. CONDIÇÃO ANORMAL", "h1"),
        P("Declarar condição anormal e acionar a coordenação quando ocorrer qualquer um dos "
          "seguintes: TAH-201 ativo por mais de 15 min; produto reprovado em duas amostras "
          "consecutivas; FV-201 saturada em 100 % por mais de 30 min; perda de circulação "
          "do loop de água temperada."),
        P("5. TROCA DE CAMPANHA", "h1"),
        P("A troca de grade é feita por enriquecimento gradual da alimentação, sem parada, "
          "ao longo de aproximadamente 6 h. Durante a transição é esperado que a conversão "
          "oscile e que alarmes de qualidade atuem de forma transitória. O set point térmico "
          "só é alterado se a ordem de produção do novo grade assim determinar."),
        P("6. AMOSTRAGEM", "h1"),
        P("Amostra de 4 em 4 horas, coletada na linha de produto e enviada ao laboratório. "
          "O resultado de liberação de lote é o do LIMS; a leitura de AT-205 é indicação de "
          "acompanhamento e não substitui a análise."),
        P("7. GESTÃO DE ALARMES", "h1"),
        P("<b>7.1</b> — Todo alarme deve ser reconhecido e tratado. Alarmes de prioridade "
          "ALTA exigem registro de ação no relatório de turno."),
        P("<b>7.2</b> — Alarmes repetitivos devem ser reportados ao grupo de racionalização "
          "de alarmes por meio do formulário FRM-ALM-02."),
        P("<b>7.3</b> — A supressão temporária de alarme de prioridade BAIXA é permitida "
          "mediante autorização da coordenação de operação, com registro no livro de alarmes "
          "suprimidos e <b>prazo máximo de revisão de 7 dias</b>. É vedada a supressão de "
          "alarmes de prioridade ALTA e de qualquer função do SIS."),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "D. Castro", "2026-01-30"),
                     ("Verificado", "C. Ferreira", "2026-02-02"),
                     ("Aprovado", "R. Nakamura", "2026-02-05")]),
    ]
    _emitir("process", "POP-U200-014_procedimento_operacional.pdf", cab, corpo)


# =============================================================================
# SILO 6 — ENGENHARIA
# =============================================================================
def _curso_exigido(H, u_cf, trim=1.0, sp=None, d2=0.0):
    """Curso de FV-201 em regime — a MESMA conta do simulador (§16)."""
    import numpy as np
    sp = U.SP_UNIDADE if sp is None else sp
    p = U.replace(U.CSTRParams(), H=H)
    a_r = p.Da * np.exp(sp / (1 + sp / p.gamma))
    x1 = a_r / (1 + a_r)
    u = ((1 + p.beta) * sp - H * x1 - d2) / p.beta
    v = U.CoolingValve(U.ValveParams(u_cf=u_cf, a_max=U.A_MAX_PROJETO, gain_trim=trim))
    return 100.0 * v.demanded_travel(u, sp)


def _ucf_de_torre(t_torre_C):
    """Temperatura do loop na saída de E-201 em função da água de torre.

    Aproximação de projeto do trocador: cada 1 K na água de torre desloca o
    limite frio do loop em ~1,15 K (efetividade constante).
    """
    return U.UCF_PROJETO + (t_torre_C - U.CW_TOWER_DESIGN_C) * 1.15 / U.DT_K


def silo_engenharia():
    figs = diagramas.gerar_todos(os.path.join(RAIZ, "figures"))

    # --- design basis --------------------------------------------------------
    cab = {"titulo": "Design Basis — Unidade U-200", "numero": "U-200-DB-001",
           "rev": "3", "data": "2021-06-30", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "U-200-DB-001", "Revisão": "3",
                             "Data": "2021-06-30", "Unidade": U.UNIDADE,
                             "Elaborado": "Engenharia de Projetos",
                             "Aprovado": "Gerência Técnica"}),
        Spacer(1, 4 * mm),
        P("1. BASE DE PROJETO", "h1"),
        tabela([
            ["Item", "Valor de projeto", "Observação"],
            ["Capacidade", "9,0 m³/h de carga", "único trem, operação contínua"],
            ["Grades previstos", "família RA (alquídica) e RB (poliéster)",
             "monômero na carga entre 55 e 62 % m/m"],
            ["Temperatura de reação", f"{SP_C:.1f} °C nominal",
             f"envelope {ENV_LO_C:.1f} – {ENV_HI_C:.1f} °C"],
            ["Volume útil de R-201", "12 m³", "tempo de residência 20 min"],
            ["Pressão de operação", "3,5 barg", "PMTA 6,0 barg"],
            ["Regime térmico", "ramo de alta conversão",
             "operação estável acima do ponto de ignição"],
        ], [40 * mm, 52 * mm, 76 * mm]),
        P("2. CONDIÇÕES DE UTILIDADES", "h1"),
        tabela([
            ["Utilidade", "Projeto", "Máximo de projeto", "Observação"],
            ["Água de torre (TR-901)", f"{U.CW_TOWER_DESIGN_C:.0f} °C",
             f"{U.CW_TOWER_TAH_C:.0f} °C",
             "média histórica de verão da região; alarme TAH-203 no máximo"],
            ["Loop de água temperada", f"{UCF_C:.0f} °C mín.", "—",
             "limite frio do circuito com FV-201 em 100 %"],
            ["Vazão de circulação do loop", "60 m³/h", "—", "P-201, vazão fixa"],
            ["Vapor de baixa (E-202)", "4,5 barg", "—", "pré-aquecimento de carga"],
        ], [42 * mm, 26 * mm, 30 * mm, 70 * mm]),
        P("3. ENVELOPE OPERACIONAL", "h1"),
        tabela([
            ["Limite", "TAG", "Valor", "Base"],
            ["Envelope inferior", "—", f"{ENV_LO_C:.1f} °C",
             "abaixo disso a conversão cai fora de qualquer especificação de grade"],
            ["Envelope superior", "—", f"{ENV_HI_C:.1f} °C",
             "acima disso há formação de cor e subprodutos em qualquer grade"],
            ["Alarme de temperatura alta", "TAH-201", f"{TAH_C:.1f} °C",
             "envelope superior + margem de instrumento"],
            ["Alarme de temperatura baixa", "TAL-201", f"{TAL_C:.1f} °C",
             "margem contra extinção da reação"],
            ["Intertravamento", "TAHH-201", f"{TAHH_C:.1f} °C",
             "10 K abaixo do início de decomposição (ver HAZOP nó 3)"],
            ["Alarme de curso alto de FV-201", "ZAH-201", f"{100 * U.TRAVEL_ZAH:.0f} %",
             "indicador de consumo da margem de resfriamento (ver § 4)"],
        ], [42 * mm, 22 * mm, 22 * mm, 82 * mm], destaque_linhas=(6,)),
        P("4. CRITÉRIO DE MARGEM DO CIRCUITO DE RESFRIAMENTO", "h1"),
        caixa("O circuito de resfriamento é dimensionado para atender ao <b>caso de projeto "
              "mais severo</b> — grade de maior teor de monômero, operando no limite "
              f"inferior do envelope, com água de torre na máxima de projeto "
              f"({U.CW_TOWER_TAH_C:.0f} °C) — utilizando <b>no máximo 75 % do curso de "
              "FV-201</b>. Os 25 % restantes constituem a reserva destinada à rejeição de "
              "perturbações transitórias de carga (vazão e temperatura de alimentação) sem "
              "perda de controle da temperatura do reator.",
              "Critério DB-4.1 — margem mínima de curso"),
        Spacer(1, 2 * mm),
        P("A verificação deste critério é feita na memória de cálculo U-200-MC-014. A "
          "reserva de 25 % de curso é o único mecanismo de que a unidade dispõe para "
          "absorver perturbações: não há resfriamento de emergência independente, e o "
          "intertravamento TAHH-201 atua por corte de carga, não por adição de "
          "capacidade de troca."),
        P("5. PREMISSAS QUE LIMITAM O PROJETO", "h1"),
        P("• A capacidade de resfriamento é limitada pela válvula FV-201 e pela temperatura "
          "da água de torre, nesta ordem. E-201 tem 18 % de área excedente."),
        P("• O reator opera no ramo de alta conversão, que é estável, porém sensível: "
          "variações grandes e rápidas na taxa de remoção de calor podem levar tanto à "
          "extinção da reação (excesso de resfriamento) quanto à perda de controle "
          "(falta de resfriamento). Ver HAZOP nós 2 e 3."),
        P("• Não há redundância de FV-201. A válvula é o único elemento final da malha de "
          "temperatura."),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "Eng. de Projetos", "2021-06-30"),
                     ("Verificado", "R. Nakamura", "2021-07-08"),
                     ("Aprovado", "Gerência Técnica", "2021-07-15")]),
    ]
    _emitir("engineering", "U-200-DB-001_design_basis.pdf", cab, corpo)

    # --- folha de dados de FV-201 (a especificação de projeto) ---------------
    cab = {"titulo": "Folha de Dados de Instrumento — FV-201", "numero": "U-200-DS-FV201",
           "rev": "2", "data": "2021-09-14", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "U-200-DS-FV201", "Revisão": "2",
                             "Data": "2021-09-14", "TAG": "FV-201",
                             "Serviço": "Controle de temperatura do loop da camisa de R-201",
                             "Elaborado": "Engenharia de Projetos",
                             "Aprovado": "C. Ferreira"}),
        Spacer(1, 4 * mm),
        P("1. CONDIÇÕES DE PROCESSO", "h1"),
        tabela([
            ["Item", "Mínimo", "Normal", "Máximo", "Unidade"],
            ["Vazão pelo trocador E-201", "0", "11 – 18", "45", "m³/h"],
            ["Vazão total do loop (P-201)", "60", "60", "60", "m³/h"],
            ["Temperatura do fluido", "88", "130", "235", "°C"],
            ["Pressão a montante", "5,2", "5,6", "6,0", "barg"],
            ["ΔP através da válvula (100 % curso)",
             f"{0.85 * DP_PROJETO_BAR:.2f}", f"{DP_PROJETO_BAR:.2f}",
             f"{1.20 * DP_PROJETO_BAR:.2f}", "bar"],
            ["Fluido", "água tratada + inibidor, circuito fechado", "", "", "—"],
        ], [58 * mm, 22 * mm, 26 * mm, 22 * mm, 22 * mm]),
        P("2. DIMENSIONAMENTO", "h1"),
        tabela([
            ["Item", "Valor", "Observação"],
            ["Cv exigido pelo caso de processo mais severo",
             f"{40 * _curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0)) / 100:.1f}",
             "conforme U-200-MC-014 § 5, caso MC-4 (RB-220 / torre a 32 °C)"],
            ["<b>Cv mínimo para atender ao critério DB-4.1</b>",
             f"<b>{40 * _curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0)) / 100 / 0.75:.1f}</b>",
             "<b>o caso mais severo deve caber em 75 % de curso</b>"],
            ["<b>Cv selecionado (100 % de curso)</b>", "<b>40</b>",
             f"coloca o caso MC-4 em "
             f"{_curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0)):.1f} % de curso"],
            ["Vazão correspondente a Cv 40", f"{_vazao(40):.0f} m³/h",
             f"com ΔP de {DP_PROJETO_BAR:.2f} bar e densidade relativa {DENS_REL:.2f}"],
            ["Característica inerente", "Linear",
             "escolhida por ΔP praticamente constante no circuito fechado"],
            ["Rangeabilidade requerida", "≥ 25:1", "—"],
        ], [66 * mm, 26 * mm, 76 * mm], destaque_linhas=(3,)),
        P("3. CONSTRUÇÃO", "h1"),
        tabela([
            ["Item", "Especificação"],
            ["Fabricante / modelo", "NORDVALVE série 4000, corpo de três vias misturador"],
            ["Diâmetro nominal / classe", "DN 80 / ANSI 300"],
            ["Corpo / internos", "Aço WCB / AISI 316 endurecido"],
            ["<b>Conjunto de trim especificado</b>",
             "<b>NV4000-40-STD — gaiola padrão, Cv 40, característica linear</b>"],
            ["Curso nominal", "50 mm"],
            ["Atuador", "Diafragma com mola, 4–20 mA via posicionador digital"],
            ["Ação em falha de sinal ou de ar", "ABRE (FO) — máximo desvio por E-201"],
            ["Tempo de curso total", "≤ 60 s"],
            ["Classe de vedação", "Classe IV"],
        ], [56 * mm, 112 * mm], destaque_linhas=(4,)),
        Spacer(1, 3 * mm),
        caixa("Qualquer substituição do conjunto de trim por modelo de capacidade diferente "
              "invalida o dimensionamento desta folha de dados e exige revisão de "
              "U-200-MC-014.", "Nota de especificação"),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "Eng. de Projetos", "2021-09-14"),
                     ("Verificado", "C. Ferreira", "2021-09-20"),
                     ("Aprovado", "R. Nakamura", "2021-09-28")]),
    ]
    _emitir("engineering", "U-200-DS-FV201_folha_dados_valvula.pdf", cab, corpo)

    # --- memória de cálculo: a tabela que permite refazer a conta -----------
    linhas = [["Caso", "Grade", "Monômero (%)", "Água de torre (°C)",
               "Curso exigido de FV-201 (%)", "Margem (%)"]]
    casos = [
        ("MC-1", "RA-180", U.CAMPANHA_A.monomero_pct, U.CAMPANHA_A.H, 28.0),
        ("MC-2", "RA-180", U.CAMPANHA_A.monomero_pct, U.CAMPANHA_A.H, 32.0),
        ("MC-3", "RB-220", U.CAMPANHA_B.monomero_pct, U.CAMPANHA_B.H, 28.0),
        ("MC-4", "RB-220", U.CAMPANHA_B.monomero_pct, U.CAMPANHA_B.H, 32.0),
    ]
    for nome, grade, mon, H, torre in casos:
        q = _curso_exigido(H, _ucf_de_torre(torre))
        linhas.append([nome, grade, f"{mon:.1f}", f"{torre:.0f}", f"{q:.1f}", f"{100 - q:.1f}"])
    q_severo = _curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0))
    q_upset = _curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0), d2=U.UPSET_D2)

    cab = {"titulo": "Memória de Cálculo — Circuito de Resfriamento de R-201",
           "numero": "U-200-MC-014", "rev": "3", "data": "2021-09-10",
           "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "U-200-MC-014", "Revisão": "3",
                             "Data": "2021-09-10", "Unidade": U.UNIDADE,
                             "Elaborado": "Eng. de Projetos", "Verificado": "R. Nakamura",
                             "Referência": "U-200-DB-001 § 4"}),
        Spacer(1, 4 * mm),
        P("1. OBJETIVO", "h1"),
        P("Verificar o atendimento ao critério DB-4.1 (margem mínima de 25 % de curso de "
          "FV-201 no caso de projeto mais severo) e dimensionar o conjunto de trim."),
        P("2. MODELO DE REMOÇÃO DE CALOR", "h1"),
        P("O circuito da camisa é um misturador: a temperatura do fluido que entra na camisa "
          "resulta da mistura entre a corrente desviada por E-201 e a corrente em by-pass. "
          "Definindo <i>a</i> como a razão entre a capacidade térmica desviada e o produto "
          "UA da camisa, a temperatura da camisa é"),
        P("<font face='Courier'>    T_camisa = (a · T_frio + T_reator) / (a + 1)</font>"),
        P("e o calor removido resulta em uma condutância efetiva <i>UA · a/(a+1)</i>. Duas "
          "consequências que governam o dimensionamento:"),
        P("<b>(a)</b> A capacidade máxima de remoção é limitada por <i>a</i> no curso total, "
          "isto é, pelo Cv do trim instalado — não pela bomba nem pela área de E-201."),
        P("<b>(b)</b> O ganho por ponto de curso cai à medida que <i>a</i> cresce. Perto do "
          "curso total, cada ponto adicional de abertura remove menos calor que o anterior. "
          "Por isso a margem exigida é definida <b>em curso</b>, e não em capacidade."),
        P("3. CARGA TÉRMICA POR GRADE", "h1"),
        tabela([
            ["Grade", "Monômero na carga (%)", "Calor liberado (kW)",
             "Removido pela camisa (kW)", "Relativo a RA-180"],
            ["RA-180", f"{U.CAMPANHA_A.monomero_pct:.1f}", f"{Q_REACAO_KW:.0f}",
             f"{Q_CAMISA_KW:.0f}", "100 %"],
            ["RB-220", f"{U.CAMPANHA_B.monomero_pct:.1f}", f"{Q_REACAO_B_KW:.0f}",
             f"{Q_CAMISA_KW + (Q_REACAO_B_KW - Q_REACAO_KW):.0f}",
             f"{100 * U.CAMPANHA_B.H / U.CAMPANHA_A.H:.1f} %"],
        ], [24 * mm, 36 * mm, 34 * mm, 40 * mm, 30 * mm]),
        Spacer(1, 2 * mm),
        P(f"O calor liberado pela reação sai do reator por dois caminhos: com o produto, "
          f"que deixa R-201 a {SP_C:.0f} °C contra {C(0.0):.0f} °C de entrada "
          f"(~{Q_PRODUTO_KW:.0f} kW), e pela camisa (~{Q_CAMISA_KW:.0f} kW). "
          f"<b>Só a segunda parcela é regulável por FV-201</b>, e é sobre ela que incide "
          f"todo o dimensionamento a seguir."),
        P("4. CURSO EXIGIDO POR CASO", "h1"),
        tabela(linhas, [18 * mm, 26 * mm, 30 * mm, 34 * mm, 42 * mm, 24 * mm],
               destaque_linhas=(4,)),
        Spacer(1, 3 * mm),
        P(f"O caso mais severo é o <b>MC-4</b> (RB-220 com água de torre na máxima de "
          f"projeto): curso exigido de <b>{q_severo:.1f} %</b>, margem de "
          f"<b>{100 - q_severo:.1f} %</b>. O critério DB-4.1 é atendido."),
        P("5. SELEÇÃO DO TRIM", "h1"),
        P(f"O caso MC-4 exige um Cv de {40 * q_severo / 100:.1f}. Para que ele caiba em "
          f"75 % de curso, conforme o critério DB-4.1, o conjunto instalado precisa ter "
          f"<b>Cv ≥ {40 * q_severo / 100 / 0.75:.1f}</b>."),
        P(f"Selecionado o conjunto <b>NV4000-40-STD (Cv 40)</b>, que coloca o caso MC-4 em "
          f"{q_severo:.1f} % de curso e deixa {100 - q_severo:.1f} % de reserva."),
        Spacer(1, 2 * mm),
        tabela([
            ["Conjunto (NORDVALVE DN 80)", "Cv", "Curso no caso MC-4",
             "Atende DB-4.1?"],
            ["NV4000-40-STD", "40", f"{q_severo:.1f} %", "Sim"],
            ["NV4000-30-STD", "30", f"{q_severo * 40 / 30:.1f} %", "Sim"],
            ["NV4000-28-AC", "28", f"{q_severo * 40 / 28:.1f} %", "Sim, no limite"],
            ["NV4000-22-AC", "22", f"{q_severo * 40 / 22:.1f} %", "<b>NÃO</b>"],
            ["NV4000-16-AC", "16", f"{q_severo * 40 / 16:.1f} %", "<b>NÃO</b>"],
        ], [56 * mm, 18 * mm, 44 * mm, 50 * mm], destaque_linhas=(4, 5)),
        Spacer(1, 2 * mm),
        P("Conjuntos de capacidade inferior à mínima <b>não atendem</b> ao critério DB-4.1 "
          "e não devem ser aplicados sem revisão desta memória de cálculo."),
        P("6. VERIFICAÇÃO DE REJEIÇÃO DE PERTURBAÇÃO", "h1"),
        P(f"Perturbação de referência: elevação de 3,0 K na temperatura da carga (TT-204), "
          f"que corresponde a uma falha típica de controle de E-202. Partindo do caso MC-4, "
          f"o curso exigido passa para <b>{q_upset:.1f} %</b>. A malha mantém autoridade e a "
          f"temperatura do reator permanece controlada."),
        P("7. CONCLUSÃO", "h1"),
        P("O circuito atende ao critério de margem com o trim especificado. A margem de "
          "curso é o mecanismo de rejeição de perturbação da unidade e deve ser preservada "
          "ao longo da vida do equipamento."),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "Eng. de Projetos", "2021-09-10"),
                     ("Verificado", "R. Nakamura", "2021-09-16")]),
    ]
    _emitir("engineering", "U-200-MC-014_memoria_calculo.pdf", cab, corpo)

    # --- filosofia de controle ----------------------------------------------
    cab = {"titulo": "Filosofia de Controle — Unidade U-200", "numero": "U-200-CP-001",
           "rev": "4", "data": "2024-05-22", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "U-200-CP-001", "Revisão": "4",
                             "Data": "2024-05-22", "Unidade": U.UNIDADE,
                             "Elaborado": "C. Ferreira", "Aprovado": "R. Nakamura"}),
        Spacer(1, 4 * mm),
        P("1. MALHA TIC-201 — TEMPERATURA DE R-201", "h1"),
        tabela([
            ["Item", "Definição"],
            ["Variável controlada (PV)", "TT-201 — temperatura do reator"],
            ["Variável manipulada (MV)", "FV-201 — abertura da válvula de três vias do loop"],
            ["Ação", "Direta na temperatura: PV acima do SP abre FV-201"],
            ["Estrutura", "PID paralelo com anti-windup por condicionamento da integral"],
            ["Sintonia", f"Kp = {U.KP_TIC201:+.3f} curso/adim · "
                         f"Ti = {U.TI_TIC201:.2f} · Td = {U.TD_TIC201:.3f}"],
            ["Base da sintonia", "IMC com λ = τ sobre modelo de 1ª ordem identificado em "
                                 "malha aberta na própria MV"],
            ["Modelo identificado", f"K = {U.IDENT['K']:.2f} adim/curso · "
                                    f"τ = {U.IDENT['tau']:.2f} t.r. · θ ≈ 2 min"],
            ["Saturação", "0 – 100 % de curso, imposta pelo atuador"],
            ["Modo normal", "AUTO"],
        ], [42 * mm, 126 * mm]),
        Spacer(1, 3 * mm),
        P("A sintonia é deliberadamente conservadora (λ = τ). O reator opera no ramo de alta "
          "conversão, onde uma ação de resfriamento agressiva demais pode extinguir a "
          "reação. A malha privilegia estabilidade sobre velocidade."),
        P("2. O QUE A MALHA NÃO FAZ", "h1"),
        caixa("O TIC-201 controla a <b>temperatura</b>. Ele não conhece a especificação de "
              "conversão, não conhece a margem de curso restante e não distingue entre "
              "manter o set point com 30 % de abertura e mantê-lo com 95 %. Enquanto houver "
              "curso disponível, a malha mantém a PV no SP e o erro permanece pequeno — "
              "<b>independentemente da margem consumida</b>. O acompanhamento da margem é "
              "atribuição da operação (POP-U200-014 § 2.3) e do alarme ZAH-201.",
              "Limitação de escopo da malha"),
        P("3. ALARMES E FUNÇÕES DE PROTEÇÃO", "h1"),
        tabela([
            ["TAG", "Função", "Ajuste", "Prioridade", "Ação esperada"],
            ["TAH-201", "Temperatura alta", f"{TAH_C:.1f} °C", "ALTA",
             "verificar carga térmica e autoridade da malha"],
            ["TAL-201", "Temperatura baixa", f"{TAL_C:.1f} °C", "MÉDIA",
             "verificar alimentação e risco de extinção"],
            ["ZAH-201", "Curso alto de FV-201", f"{100 * U.TRAVEL_ZAH:.0f} %", "BAIXA",
             "indicador de consumo da margem de projeto — comunicar a Processo"],
            ["ZAHH-201", "FV-201 saturada", f"{100 * U.TRAVEL_SAT:.0f} %", "ALTA",
             "a malha perdeu autoridade; ações sobre o SP não terão efeito"],
            ["TAH-203", "Água de torre quente", f"{U.CW_TOWER_TAH_C:.0f} °C", "BAIXA",
             "comunicar às utilidades"],
            ["QAH/QAL-205", "Conversão fora da faixa", "conforme a PO", "MÉDIA",
             "confirmar com o laboratório"],
            ["TAHH-201", "Intertravamento SIS", f"{TAHH_C:.1f} °C", "SIS",
             "corte de carga e abertura total de FV-201"],
        ], [22 * mm, 34 * mm, 22 * mm, 20 * mm, 70 * mm], destaque_linhas=(3, 4)),
        Spacer(1, 3 * mm),
        P("O ZAH-201 é classificado como prioridade BAIXA porque não exige ação imediata do "
          "operador. Isso não reduz o seu significado de engenharia: <b>é o único alarme da "
          "unidade que informa sobre a reserva de rejeição de perturbação</b>."),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "C. Ferreira", "2024-05-22"),
                     ("Verificado", "D. Castro", "2024-05-28"),
                     ("Aprovado", "R. Nakamura", "2024-06-04")]),
    ]
    _emitir("engineering", "U-200-CP-001_filosofia_controle.pdf", cab, corpo)

    # --- datasheet do reator (documento de baixo valor para o caso) ----------
    cab = {"titulo": "Folha de Dados de Equipamento — R-201", "numero": "U-200-DS-R201",
           "rev": "1", "data": "2021-08-02", "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Documento": "U-200-DS-R201", "Revisão": "1",
                             "Data": "2021-08-02", "TAG": "R-201",
                             "Equipamento": "Reator CSTR encamisado",
                             "Fabricante": "Metalúrgica Andrade", "Nº de série": "MA-21-0884"}),
        Spacer(1, 4 * mm),
        P("DADOS DE PROJETO", "h1"),
        tabela([
            ["Item", "Valor", "Item", "Valor"],
            ["Volume total", "14,2 m³", "Volume útil", "12,0 m³"],
            ["Diâmetro interno", "2.200 mm", "Altura T/T", "3.800 mm"],
            ["Material do casco", "AISI 316L", "Material da camisa", "Aço carbono SA-516"],
            ["PMTA casco", "6,0 barg", "PMTA camisa", "8,0 barg"],
            ["Temperatura de projeto", "280 °C", "Temp. de projeto camisa", "200 °C"],
            ["Área de troca da camisa", f"{AREA_CAMISA_M2:.1f} m²", "U de projeto",
             f"{U_GLOBAL_WM2K:.0f} W/m²·K"],
            ["Agitador", "Turbina de 4 pás, 22 kW", "Rotação", "88 rpm"],
            ["Chicanas", "4 × 180 mm", "Selo do agitador", "Mecânico duplo"],
            ["Isolamento", "Lã de rocha 75 mm", "Revestimento", "Alumínio 0,6 mm"],
            ["Código de projeto", "ASME VIII Div. 1", "Radiografia", "Parcial"],
            ["Inspeção interna", "a cada 4 anos", "Última inspeção", "2024-10 (PP-24-05)"],
        ], [40 * mm, 44 * mm, 40 * mm, 44 * mm]),
        Spacer(1, 4 * mm),
        P("A camisa é do tipo meia-cana soldada em espiral, com quatro passes. O circuito é "
          "fechado e mantido pressurizado por vaso de expansão VE-201."),
        Spacer(1, 5 * mm),
        assinaturas([("Elaborado", "Eng. de Projetos", "2021-08-02"),
                     ("Aprovado", "Gerência Técnica", "2021-08-10")]),
    ]
    _emitir("engineering", "U-200-DS-R201_folha_dados_reator.pdf", cab, corpo)


# =============================================================================
# SILO 7 — FABRICANTE
# =============================================================================
def silo_fabricante():
    figs = diagramas.gerar_todos(os.path.join(RAIZ, "figures"))

    # --- dados técnicos: a tabela de Cv por conjunto de trim -----------------
    cab = {"titulo": "NORDVALVE Série 4000 — Dados Técnicos", "numero": "NV-4000-TD-PT",
           "rev": "11", "data": "2023-03", "classificacao": "DOCUMENTO DO FABRICANTE"}
    corpo = [
        bloco_identificacao({"Publicação": "NV-4000-TD-PT", "Edição": "11",
                             "Data": "03/2023", "Fabricante": "NORDVALVE Controls",
                             "Linha": "Série 4000 — válvulas globo e três vias",
                             "Substitui": "Edição 10 (2020)"}),
        Spacer(1, 4 * mm),
        P("1. DESCRIÇÃO DA LINHA", "h1"),
        P("A série 4000 abrange válvulas globo de sede simples e válvulas de três vias "
          "(misturadoras e divisoras) em corpos DN 25 a DN 200, classes ANSI 150 a 600. "
          "O conjunto de trim é intercambiável dentro do mesmo corpo, permitindo alterar "
          "capacidade e característica sem substituir a válvula."),
        P("2. CAPACIDADE POR CONJUNTO DE TRIM — DN 80, ANSI 300", "h1"),
        tabela([
            ["Código do conjunto", "Tipo de gaiola", "Característica", "Cv (100 % curso)",
             "Rangeabilidade", "Aplicação típica"],
            ["NV4000-50-STD", "Padrão", "Linear", "50", "30:1", "Uso geral"],
            ["NV4000-40-STD", "Padrão", "Linear", "40", "30:1", "Uso geral"],
            ["NV4000-40-EQ", "Padrão", "Igual %", "40", "50:1", "ΔP variável"],
            ["NV4000-30-STD", "Padrão", "Linear", "30", "30:1", "Uso geral"],
            ["NV4000-28-AC", "Anticavitação (2 estágios)", "Linear", "28", "20:1",
             "Serviço com flashing ou cavitação"],
            ["NV4000-22-AC", "Anticavitação (3 estágios)", "Linear", "22", "20:1",
             "Serviço severo, alto ΔP"],
            ["NV4000-16-AC", "Anticavitação (4 estágios)", "Linear", "16", "15:1",
             "Serviço severo, ΔP muito alto"],
        ], [32 * mm, 40 * mm, 22 * mm, 24 * mm, 22 * mm, 28 * mm],
            destaque_linhas=(2, 6)),
        Spacer(1, 3 * mm),
        caixa("<b>Redução de capacidade dos conjuntos anticavitação.</b> Os conjuntos da "
              "família AC utilizam gaiolas de múltiplos estágios que dissipam a queda de "
              "pressão em série. A área de passagem resultante é menor que a do conjunto "
              "padrão de mesmo corpo, e a capacidade nominal é reduzida <b>entre 30 % e "
              "60 %</b> conforme o número de estágios. Um conjunto AC <b>não é substituto "
              "direto</b> de um conjunto padrão: a redução de Cv é intencional e permanente. "
              "Antes de aplicar um conjunto AC no lugar de um conjunto padrão, verifique se "
              "o Cv resultante ainda atende à condição de processo mais severa da malha.",
              "ADVERTÊNCIA TÉCNICA — NV-4000-TD § 2.3"),
        Spacer(1, 4 * mm),
    ]
    corpo += figura(figs["cv"], 150,
                    "Figura 2.1 — Cv instalado em função do curso para os conjuntos "
                    "NV4000-40-STD e NV4000-22-AC no corpo DN 80 ANSI 300.")
    corpo += [
        Spacer(1, 4 * mm),
        P("3. CONVERSÃO DE Cv EM VAZÃO (LÍQUIDOS)", "h1"),
        P("<font face='Courier'>    Q [m³/h] = Cv · √(ΔP [bar] / d)</font>, com <i>d</i> = "
          "densidade relativa do fluido."),
        tabela([
            ["Conjunto", "Cv", "ΔP = 0,8 bar", f"ΔP = {DP_PROJETO_BAR:.2f} bar",
             "ΔP = 2,0 bar"],
            ["NV4000-40-STD", "40", f"{_vazao(40, 0.8):.0f} m³/h",
             f"{_vazao(40):.0f} m³/h", f"{_vazao(40, 2.0):.0f} m³/h"],
            ["NV4000-28-AC", "28", f"{_vazao(28, 0.8):.0f} m³/h",
             f"{_vazao(28):.0f} m³/h", f"{_vazao(28, 2.0):.0f} m³/h"],
            ["NV4000-22-AC", "22", f"{_vazao(22, 0.8):.0f} m³/h",
             f"{_vazao(22):.0f} m³/h", f"{_vazao(22, 2.0):.0f} m³/h"],
        ], [36 * mm, 18 * mm, 34 * mm, 34 * mm, 34 * mm]),
        P(f"<i>Valores para densidade relativa {DENS_REL:.2f} (água pressurizada quente). "
          f"Para outras densidades aplicar o fator da tabela 3.2.</i>", "nota"),
        P("4. ATUADOR E POSICIONADOR", "h1"),
        tabela([
            ["Item", "Especificação"],
            ["Atuador", "Diafragma com mola, tamanhos 30 a 100"],
            ["Posicionador", "NVP-300 digital, HART, 4–20 mA"],
            ["Linearidade do conjunto atuador/posicionador", "± 0,5 % do curso"],
            ["Tempo de curso total", "40 a 80 s conforme tamanho do atuador"],
            ["Repetibilidade", "± 0,2 % do curso"],
        ], [72 * mm, 96 * mm]),
        Spacer(1, 5 * mm),
        P("NORDVALVE Controls · Assistência técnica: suporte.br@nordvalve.com", "nota"),
    ]
    _emitir("vendor", "NV-4000-TD_dados_tecnicos.pdf", cab, corpo)

    # --- manual de instalação e manutenção ----------------------------------
    cab = {"titulo": "NORDVALVE Série 4000 — Manual de Instalação, Operação e Manutenção",
           "numero": "NV-4000-IOM-PT", "rev": "9", "data": "2022-08",
           "classificacao": "DOCUMENTO DO FABRICANTE"}
    corpo = [
        bloco_identificacao({"Publicação": "NV-4000-IOM-PT", "Edição": "9",
                             "Data": "08/2022", "Fabricante": "NORDVALVE Controls",
                             "Aplica-se a": "Série 4000, todos os corpos",
                             "Documento relacionado": "NV-4000-TD-PT"}),
        Spacer(1, 4 * mm),
        P("5. MANUTENÇÃO DO TRIM", "h1"),
        P("5.1 — Inspecione o conjunto de trim sempre que houver alteração de "
          "característica de controle, ruído anormal ou perda de estanqueidade."),
        P("5.2 — <b>Critério de substituição.</b> Substitua o conjunto quando a perda de "
          "perfil da sede ou do obturador exceder 0,4 mm em qualquer ponto, ou quando a "
          "classe de vedação especificada não for atingida após lapidação."),
        P("5.3 — <b>Substituição por conjunto de código diferente.</b> Conjuntos de trim da "
          "série 4000 são mecanicamente intercambiáveis dentro do mesmo corpo. A "
          "intercambiabilidade é <b>mecânica</b> e não implica equivalência hidráulica: "
          "conjuntos de códigos diferentes possuem Cv e característica diferentes "
          "(ver NV-4000-TD § 2)."),
        Spacer(1, 2 * mm),
        caixa("A calibração do posicionador ajusta a relação entre <b>sinal e curso</b>. Ela "
              "não altera, e não pode compensar, a relação entre <b>curso e vazão</b>, que é "
              "determinada pelo conjunto de trim instalado. Após a substituição por um "
              "conjunto de capacidade diferente, o teste de curso e a calibração do "
              "posicionador serão aprovados normalmente, e ainda assim a válvula entregará "
              "uma vazão diferente da anterior no mesmo percentual de abertura. "
              "<b>A verificação de capacidade exige ensaio de vazão ou verificação de "
              "dimensionamento — o teste de bancada não a substitui.</b>",
              "ADVERTÊNCIA — NV-4000-IOM § 5.3.1"),
        Spacer(1, 3 * mm),
        P("5.4 — Registre o código do conjunto efetivamente instalado na etiqueta de "
          "identificação da válvula e no registro de manutenção do equipamento."),
        P("6. DIAGNÓSTICO", "h1"),
        tabela([
            ["Sintoma", "Causas prováveis", "Verificação"],
            ["Válvula não atinge o curso total",
             "Ajuste de curso; pressão de ar insuficiente; obstrução",
             "Curso em bancada; pressão de suprimento"],
            ["Histerese acima de 1 % do curso",
             "Atrito na gaxeta; folga na haste; posicionador descalibrado",
             "Ensaio de degrau; calibração do posicionador"],
            ["<b>Válvula opera em abertura maior que a histórica, com resposta normal ao "
             "sinal</b>",
             "<b>Aumento da demanda do processo; ou capacidade instalada menor que a "
             "original (ver § 5.3)</b>",
             "<b>Comparar vazão medida com a curva de Cv do conjunto instalado</b>"],
            ["Ruído acima de 85 dBA", "Cavitação ou flashing",
             "Avaliar ΔP e considerar conjunto anticavitação"],
            ["Vazamento pela sede", "Desgaste do assento; sujeira",
             "Teste de estanqueidade; lapidação ou substituição"],
        ], [46 * mm, 62 * mm, 60 * mm], destaque_linhas=(3,)),
        P("7. PEÇAS DE REPOSIÇÃO", "h1"),
        P("Ao solicitar peças, informe sempre o número de série da válvula e o <b>código do "
          "conjunto de trim atualmente instalado</b>, que pode diferir do código original de "
          "fábrica caso tenha havido substituição."),
        Spacer(1, 5 * mm),
        P("NORDVALVE Controls · Assistência técnica: suporte.br@nordvalve.com", "nota"),
    ]
    _emitir("vendor", "NV-4000-IOM_manual.pdf", cab, corpo)

    # --- datasheet do termopar (documento de pouco valor para o caso) -------
    cab = {"titulo": "Termopar Industrial JX-200 — Folha de Dados",
           "numero": "JX-200-DS-PT", "rev": "4", "data": "2021-05",
           "classificacao": "DOCUMENTO DO FABRICANTE"}
    corpo = [
        bloco_identificacao({"Publicação": "JX-200-DS-PT", "Edição": "4", "Data": "05/2021",
                             "Fabricante": "Jaeger Instrumentos",
                             "Modelo": "JX-200 com poço TW",
                             "Aplicação": "Medição de temperatura em processo"}),
        Spacer(1, 4 * mm),
        P("ESPECIFICAÇÃO", "h1"),
        tabela([
            ["Item", "Especificação"],
            ["Tipo de sensor", "Termopar tipo J (Fe/Cu-Ni), isolação mineral"],
            ["Faixa de medição", "−40 a 750 °C"],
            ["Exatidão do sensor", "Classe 1 conforme IEC 60584 (± 1,5 °C ou 0,4 %)"],
            ["Exatidão do transmissor", "± 0,1 % da faixa configurada"],
            ["Saída", "4–20 mA, HART 7"],
            ["Tempo de resposta (τ63) com poço", "18 a 45 s conforme espessura do poço"],
            ["Poço termométrico", "AISI 316L, cônico, cálculo de Wake Frequency conforme "
                                  "ASME PTC 19-3 TW"],
            ["Deriva típica", "< 0,5 °C por ano em serviço contínuo abaixo de 400 °C"],
            ["Recomendação de verificação", "Loop check anual; calibração a cada 2 anos"],
        ], [56 * mm, 112 * mm]),
        Spacer(1, 3 * mm),
        P("Para melhor tempo de resposta, especifique o poço de parede reduzida e assegure "
          "imersão mínima de 10 diâmetros. Em serviços com agitação intensa, verifique o "
          "cálculo de frequência de vórtice.", "nota"),
        Spacer(1, 5 * mm),
        P("Jaeger Instrumentos Ltda. · Suporte técnico: 0800 940 2200", "nota"),
    ]
    _emitir("vendor", "JX-200-DS_termopar.pdf", cab, corpo)


# =============================================================================
# SILO 8 — SEGURANÇA DE PROCESSO (HAZOP)
# =============================================================================
def silo_seguranca():
    L = [22 * mm, 22 * mm, 34 * mm, 36 * mm, 32 * mm, 22 * mm]
    cab = {"titulo": "Estudo HAZOP — Unidade U-200, Seção de Reação",
           "numero": "HZ-U200-2024-03", "rev": "1", "data": "2024-09-18",
           "classificacao": "USO INTERNO — SEGURANÇA DE PROCESSO"}
    corpo = [
        bloco_identificacao({
            "Estudo": "HZ-U200-2024-03", "Revisão": "1", "Data do estudo": "16 a 18/09/2024",
            "Unidade": U.UNIDADE, "Metodologia": "HAZOP por palavras-guia (IEC 61882)",
            "Facilitador": "H. Vasques",
            "Equipe": "R. Nakamura, C. Ferreira, D. Castro, J. Barbosa, F. Almeida",
            "Desenhos": "U-200-PID-201 Rev. 5", "Próxima revisão": "2029-09",
        }),
        Spacer(1, 4 * mm),
        P("NÓS DE ESTUDO", "h1"),
        tabela([
            ["Nó", "Descrição", "Desenho"],
            ["1", "Alimentação: TK-201 → E-202 → R-201", "U-200-PID-201"],
            ["2", "Reação em R-201 — inventário e temperatura", "U-200-PID-201"],
            ["3", "Circuito de água temperada: camisa → P-201 → FV-201 → E-201", "U-200-PID-201"],
            ["4", "Produto: R-201 → TK-310", "U-200-PID-201"],
        ], [14 * mm, 110 * mm, 44 * mm]),

        P("NÓ 1 — ALIMENTAÇÃO PARA R-201", "h1"),
        tabela([
            ["Parâmetro", "Desvio", "Causa", "Consequência", "Salvaguarda", "Recom."],
            ["Vazão", "MAIS", "Falha do controle de carga; erro de operação",
             "Redução do tempo de residência e da conversão; aumento da carga térmica "
             "por unidade de tempo; maior demanda de resfriamento",
             "FT-204 com indicação e alarme; POP-U200-014 § 2", "—"],
            ["Vazão", "MENOS / NÃO", "Falha de bomba de carga; TK-201 vazio; bloqueio",
             "Aumento do tempo de residência e da conversão; produto fora de "
             "especificação pelo lado alto; no limite, esvaziamento do reator",
             "FT-204 com alarme; nível de TK-201", "—"],
            ["Temperatura", "MAIS", "Falha do controle de E-202 (U-100); vapor com pressão "
             "acima do normal",
             "Aumento da carga térmica sobre a camisa; elevação da temperatura do reator "
             "se a malha não tiver autoridade suficiente",
             "TT-204 com indicação; TIC-201; TAH-201", "HZ-R09"],
            ["Temperatura", "MENOS", "Falha de vapor em E-202",
             "Queda da temperatura do reator; risco de extinção da reação e de "
             "acúmulo de monômero não reagido no inventário",
             "TT-204; TAL-201; POP-U200-009", "HZ-R11"],
            ["Composição", "OUTRA", "Lote de matéria-prima com teor de monômero acima do "
             "usual; erro de alinhamento de tancagem",
             "Alteração do calor liberado por unidade de carga; deslocamento da demanda "
             "de resfriamento em regime",
             "Certificado de análise do lote; ordem de produção", "HZ-R10"],
        ], L),

        P("NÓ 2 — REAÇÃO EM R-201", "h1"),
        tabela([
            ["Parâmetro", "Desvio", "Causa", "Consequência", "Salvaguarda", "Recom."],
            ["Temperatura", "MAIS", "Perda ou insuficiência de remoção de calor (ver nó 3); "
             "carga mais quente; carga mais concentrada",
             f"Formação de cor e subprodutos acima de {ENV_HI_C:.0f} °C; aumento da taxa de "
             f"reação; se a remoção de calor não acompanhar, evolução para condição de "
             f"descontrole térmico. Início de decomposição do meio acima de "
             f"{TAHH_C + 10:.0f} °C.",
             f"TAH-201 em {TAH_C:.1f} °C; TAHH-201 (SIS) em {TAHH_C:.1f} °C com corte de "
             f"carga e abertura total de FV-201; PSV-201 em 6,0 barg",
             "HZ-R01, HZ-R02"],
            ["Temperatura", "MENOS", "Excesso de remoção de calor; carga fria; queda de "
             "concentração de monômero",
             "Queda da taxa de reação e extinção do ramo de alta conversão. O reator "
             "migra para o ramo de baixa conversão, com acúmulo de monômero não reagido "
             "no inventário e no produto. A retomada exige aquecimento e é lenta.",
             f"TAL-201 em {TAL_C:.1f} °C; sintonia conservadora do TIC-201 (U-200-CP-001)",
             "HZ-R03"],
            ["Reação", "MAIS", "Concentração de monômero acima do especificado combinada "
             "com temperatura acima do envelope",
             "Aumento simultâneo da taxa de geração de calor e da temperatura, com "
             "realimentação positiva. Condição de descontrole térmico.",
             "TAHH-201 (SIS); PSV-201; envelope operacional de U-200-DB-001",
             "HZ-R02"],
            ["Agitação", "NÃO", "Falha do agitador; falha elétrica",
             "Perda de homogeneidade e queda brusca do coeficiente de troca da camisa; "
             "gradiente térmico interno; risco de ponto quente",
             "Intertravamento de baixa rotação do agitador com corte de carga", "—"],
        ], L),

        P("NÓ 3 — CIRCUITO DE ÁGUA TEMPERADA", "h1"),
        tabela([
            ["Parâmetro", "Desvio", "Causa", "Consequência", "Salvaguarda", "Recom."],
            ["Vazão", "NÃO", "Falha de P-201; perda de energia; bloqueio inadvertido",
             "Perda total de remoção de calor. Elevação rápida da temperatura do reator "
             "com evolução para descontrole térmico.",
             "TAHH-201 (SIS) com corte de carga; alarme de baixa corrente de P-201; "
             "PSV-201", "HZ-R04"],
            ["Vazão", "MENOS", "Cavitação em P-201; obstrução parcial; perda de carga "
             "excessiva em E-201",
             "Redução da remoção de calor; elevação da temperatura do reator até o novo "
             "equilíbrio ou até o intertravamento",
             "FT-201; TT-202; TAH-201", "HZ-R05"],
            ["Temperatura", "MAIS", "Água de torre acima do previsto (onda de calor, "
             "célula fora de serviço, enchimento incrustado); incrustação em E-201",
             "Elevação do limite frio do circuito e redução da capacidade máxima de "
             "remoção de calor. A malha compensa abrindo FV-201, consumindo margem de "
             "curso, até que não haja mais curso disponível.",
             f"TT-203 e TAH-203 em {U.CW_TOWER_TAH_C:.0f} °C; TT-207; "
             f"ZAH-201 em {100 * U.TRAVEL_ZAH:.0f} % de curso", "HZ-R06, HZ-R14"],
            ["Capacidade", "MENOS", "Elemento final da malha com capacidade inferior à de "
             "projeto (obstrução do trim, curso limitado, conjunto de trim de capacidade "
             "diferente da especificada)",
             "Redução da capacidade máxima de remoção de calor sem qualquer alteração da "
             "temperatura em regime, enquanto houver curso disponível. A perda só se "
             "manifesta na incapacidade de rejeitar perturbações.",
             f"ZAH-201; comparação entre ZT-201 e FT-201; U-200-MC-014",
             "HZ-R07, HZ-R14"],
            ["Controle", "REVERSO", "Falha de sinal ou de ar de instrumento para FV-201",
             "Válvula assume a posição de falha (ABRE), levando a resfriamento máximo e "
             "possível extinção da reação",
             "Ação em falha ABRE definida em projeto; TAL-201", "—"],
        ], L, destaque_linhas=(4,)),

        P("NÓ 4 — PRODUTO PARA TK-310", "h1"),
        tabela([
            ["Parâmetro", "Desvio", "Causa", "Consequência", "Salvaguarda", "Recom."],
            ["Composição", "OUTRA", "Operação fora do envelope de temperatura; desvio de "
             "receita",
             "Produto fora de especificação de cor, viscosidade e conversão; "
             "necessidade de segregação e reprocesso",
             "Amostragem de 4 em 4 h; AT-205; QAH/QAL-205; segregação em TK-311", "HZ-R12"],
            ["Nível", "MAIS", "Falha de transferência para TK-310",
             "Transbordo do vertedouro e retorno de produto ao reator",
             "Nível de TK-310 com alarme", "—"],
        ], L),

        PageBreak(),
        P("REGISTRO DE RECOMENDAÇÕES", "h1"),
        tabela([
            ["Nº", "Recomendação", "Responsável", "Prazo", "Situação"],
            ["HZ-R01", "Revisar o ajuste de TAH-201 após a próxima alteração de envelope "
                       "operacional.", "Processo", "2025-03", "Concluída (2025-02)"],
            ["HZ-R02", "Confirmar por teste funcional anual a função TAHH-201 e a abertura "
                       "total de FV-201 pelo SIS.", "Automação", "anual",
             "Concluída (último teste 2026-04)"],
            ["HZ-R03", "Incluir no POP orientação sobre risco de extinção da reação em caso "
                       "de resfriamento excessivo.", "Operação", "2025-06",
             "Concluída (POP-U200-014 Rev. 7)"],
            ["HZ-R04", "Avaliar fonte alternativa de energia para P-201.", "Confiabilidade",
             "2026-12", "Em estudo"],
            ["HZ-R05", "Instalar indicação de vazão do loop pelo trocador (FT-201) no "
                       "console.", "Automação", "2025-06", "Concluída (2025-05)"],
            ["HZ-R06", "Estabelecer rotina de acompanhamento da temperatura de água de "
                       "torre no período de verão.", "Utilidades", "2025-11",
             "Concluída (rotina RT-UTL-04)"],
            ["HZ-R07", "Incluir na sistemática de gestão de mudanças a verificação de "
                       "dimensionamento sempre que houver substituição de elemento final "
                       "de malha por item de código diferente do especificado.",
             "Engenharia / Manutenção", "2025-12", "<b>EM ABERTO</b>"],
            ["HZ-R09", "Solicitar à U-100 relatório de confiabilidade do controle de "
                       "temperatura de E-202.", "Processo", "2025-09",
             "Concluída (relatório recebido 2025-08)"],
            ["HZ-R10", "Incluir o teor de monômero do lote na ordem de produção.",
             "Planejamento", "2025-04", "Concluída (a partir da PO-2025-0288)"],
            ["HZ-R11", "Avaliar intertravamento de baixa temperatura de carga.", "Automação",
             "2026-06", "Em estudo"],
            ["HZ-R12", "Formalizar critério de segregação de produto em TK-311.",
             "Qualidade", "2025-08", "Concluída"],
            ["HZ-R14", "Implementar no console indicação e tendência da <b>margem de "
                       "resfriamento</b> (curso disponível de FV-201), de modo que a perda "
                       "de capacidade de rejeitar perturbações seja visível ao operador "
                       "antes de se esgotar.", "Automação / Processo", "2026-06",
             "<b>EM ABERTO</b>"],
        ], [16 * mm, 74 * mm, 32 * mm, 18 * mm, 28 * mm], destaque_linhas=(7, 12)),
        Spacer(1, 4 * mm),
        P("Recomendações em aberto são acompanhadas na reunião mensal de segurança de "
          "processo. As recomendações HZ-R07 e HZ-R14 permanecem em aberto na data desta "
          "revisão.", "nota"),
        Spacer(1, 5 * mm),
        assinaturas([("Facilitador", "H. Vasques", "2024-09-18"),
                     ("Processo", "R. Nakamura", "2024-09-18"),
                     ("Operação", "D. Castro", "2024-09-18"),
                     ("Aprovação", "Gerência Técnica", "2024-10-02")]),
    ]
    _emitir("safety", "HZ-U200-2024-03_hazop.pdf", cab, corpo)


# =============================================================================
# SILO 9 — CONHECIMENTO DE ESPECIALISTAS
# =============================================================================
def silo_especialista():
    q70 = _curso_exigido(U.CAMPANHA_A.H, U.UCF_PROJETO)
    cab = {"titulo": "Nota Técnica — Autoridade da Malha TIC-201 em Aberturas Altas",
           "numero": "NT-PROC-2025-11", "rev": "0", "data": "2025-07-22",
           "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Nota técnica": "NT-PROC-2025-11", "Data": "2025-07-22",
                             "Autor": "R. Nakamura", "Área": "Engenharia de Processo",
                             "Assunto": "Comportamento de FV-201 acima de 70 % de curso",
                             "Distribuição": "Operação, Automação, Confiabilidade"}),
        Spacer(1, 4 * mm),
        P("MOTIVAÇÃO", "h1"),
        P("Esta nota registra uma observação recorrente sobre a U-200 que não está descrita "
          "em nenhum procedimento e que costuma ser redescoberta a cada campanha de verão. "
          "Ela foi escrita a pedido da coordenação de operação após a campanha de janeiro."),
        P("OBSERVAÇÃO", "h1"),
        P("Sempre que FV-201 passa a operar de forma sustentada acima de aproximadamente "
          "70 % de curso, a unidade deixa de conseguir rejeitar perturbações de carga que "
          "em condição normal são absorvidas sem que se perceba. O comportamento é sempre o "
          "mesmo: durante dias a temperatura fica perfeitamente no set point, o produto sai "
          "aprovado, ninguém tem motivo para se preocupar — e então uma variação pequena na "
          "temperatura da carga, da ordem de 2 a 3 K, leva a válvula ao batente e a "
          "temperatura sobe."),
        P("POR QUE ISSO ACONTECE", "h1"),
        P("Não é defeito da válvula, nem sintonia. É a forma da curva de remoção de calor "
          "do circuito. A condutância efetiva da camisa varia com a fração desviada por "
          "E-201 segundo <i>a/(a+1)</i>: cresce rapidamente nas aberturas baixas e satura "
          "nas altas. Em 30 % de curso, um ponto adicional de abertura vale várias vezes "
          "mais, em calor removido, do que em 90 %."),
        P("A consequência prática é que <b>a abertura de FV-201 não é uma medida linear de "
          "quanto ainda se pode fazer</b>. Entre 30 % e 60 % há muita reserva; entre 85 % e "
          "100 % há quase nenhuma. O operador vê os dois casos como \"a válvula está "
          "abrindo\" e não tem no console nada que distinga um do outro."),
        P("O QUE ISSO NÃO É", "h1"),
        P("Vale registrar o que <b>não</b> explica o fenômeno, porque são as primeiras "
          "hipóteses levantadas todas as vezes:"),
        P("• <b>Não é sintonia.</b> Nenhum ajuste de Kp ou Ti cria capacidade de remoção de "
          "calor que o circuito não tem. Retunar a malha com a válvula no batente não muda "
          "nada."),
        P("• <b>Não é o instrumento.</b> TT-201 e o posicionador de FV-201 costumam ser "
          "verificados nessas ocasiões e costumam estar corretos."),
        P("• <b>Não é necessariamente a água de resfriamento.</b> A temperatura da torre "
          "contribui e é a explicação mais visível, porque é a única que aparece em "
          "tendência. Mas a mesma temperatura de torre convive com margens muito "
          "diferentes dependendo do grade em produção e do estado do elemento final."),
        P("RECOMENDAÇÃO PRÁTICA", "h1"),
        P(f"Tratar a abertura de FV-201 como <b>variável de acompanhamento</b>, e não apenas "
          f"como saída de controlador. Em regime, com o grade de referência e a torre na "
          f"condição de projeto, a abertura esperada é da ordem de {q70:.0f} %. Desvios "
          f"persistentes em relação a esse valor, mesmo com a temperatura no set point, "
          f"merecem explicação — a explicação existe sempre, e o momento de procurá-la é "
          f"antes de a válvula chegar ao batente, não depois."),
        P("Reforço, por fim, a recomendação HZ-R14 do HAZOP de 2024, ainda em aberto: sem "
          "indicação de margem no console, esse acompanhamento depende de alguém lembrar de "
          "olhar."),
        Spacer(1, 5 * mm),
        assinaturas([("Autor", "R. Nakamura", "2025-07-22"),
                     ("Ciente — Operação", "D. Castro", "2025-07-25"),
                     ("Ciente — Automação", "C. Ferreira", "2025-07-25")]),
    ]
    _emitir("specialist", "NT-PROC-2025-11_nota_tecnica.pdf", cab, corpo)

    # --- memorando de confiabilidade ----------------------------------------
    cab = {"titulo": "Memorando — Aplicação de Sobressalentes Equivalentes",
           "numero": "MEMO-CONF-2026-04", "rev": "0", "data": "2026-04-09",
           "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({"Memorando": "MEMO-CONF-2026-04", "Data": "2026-04-09",
                             "De": "F. Almeida — Engenharia de Confiabilidade",
                             "Para": "Supervisão de Manutenção; Planejamento de Materiais",
                             "Cópia": "Engenharia de Processo; Automação",
                             "Assunto": "Substituição de itens por equivalentes de estoque"}),
        Spacer(1, 4 * mm),
        P("1. CONTEXTO", "h1"),
        P("O levantamento de disponibilidade de sobressalentes críticos do primeiro "
          "trimestre apontou 23 itens de malha de controle com estoque zerado e sem "
          "reposição programada. Em 9 dos 14 serviços executados na última parada foi "
          "necessário aplicar item diferente do especificado, com aprovação local do "
          "executante."),
        P("2. PONTO DE ATENÇÃO", "h1"),
        P("A prática de aplicar \"item equivalente disponível em almoxarifado\" é legítima "
          "e muitas vezes é a única alternativa para não estender uma parada. O ponto de "
          "atenção é outro: <b>a equivalência costuma ser avaliada quanto à montagem, e não "
          "quanto ao desempenho</b>. Um item que monta, veda e passa no teste de bancada "
          "pode ainda assim ter característica de desempenho diferente da do item "
          "especificado."),
        P("Isso é particularmente relevante em elementos finais de malha, cuja "
          "especificação decorre de uma memória de cálculo que ninguém consulta no momento "
          "da substituição — e cujo desvio não produz alarme, apenas altera silenciosamente "
          "a faixa de operação da malha."),
        P("3. LEVANTAMENTO", "h1"),
        tabela([
            ["Parada", "Serviços", "Com item equivalente", "Com verificação de "
             "dimensionamento registrada"],
            ["PP-25-02", "11", "6", "1"],
            ["PP-25-05", "17", "9", "2"],
            ["PP-26-03", "14", "9", "0"],
        ], [24 * mm, 24 * mm, 40 * mm, 80 * mm], destaque_linhas=(3,)),
        P("4. ENCAMINHAMENTO", "h1"),
        P("• Reativar a recomendação HZ-R07 do HAZOP HZ-U200-2024-03, em aberto desde 2024, "
          "que trata exatamente deste tema."),
        P("• Incluir campo obrigatório de \"verificação de dimensionamento\" no formulário "
          "de encerramento de OT quando houver aplicação de item de código diferente do "
          "especificado."),
        P("• Priorizar a reposição dos 23 itens críticos identificados (lista anexa ao "
          "relatório RCF-2026-01)."),
        Spacer(1, 5 * mm),
        assinaturas([("Emitente", "F. Almeida", "2026-04-09"),
                     ("Ciente", "J. Barbosa", "2026-04-14")]),
    ]
    _emitir("specialist", "MEMO-CONF-2026-04_memorando.pdf", cab, corpo)


# =============================================================================
# PACOTE DE INVESTIGAÇÃO (§24) — sem ground truth, sem ranking de evidências
# =============================================================================
def investigation_brief():
    cab = {"titulo": "Solicitação de Investigação — Ocorrência U-200 / R-201",
           "numero": "INV-2026-017", "rev": "0", "data": "2026-08-14",
           "classificacao": "USO INTERNO"}
    corpo = [
        bloco_identificacao({
            "Solicitação": "INV-2026-017", "Data": "2026-08-14", "Unidade": U.UNIDADE,
            "Equipamento": "R-201 e circuito de resfriamento",
            "Solicitante": "D. Castro — Coordenação de Operação",
            "Prioridade": "Alta", "Prazo": "2026-08-21",
            "Ordem em produção": "PO-2026-0418 (RB-220)",
            "Situação da unidade": "Anormal desde 12/08 23:09",
        }),
        Spacer(1, 4 * mm),
        P("1. O QUE FOI OBSERVADO", "h1"),
        P("A partir de 12/08/2026, por volta das 22:50, a válvula FV-201 foi a 100 % de "
          "abertura e assim permaneceu. A temperatura de R-201 subiu acima do set point e o "
          "alarme TAH-201 atuou às 23:10, permanecendo ativo por aproximadamente 20 horas. "
          "As amostras de laboratório a partir de 13/08 00:00 foram reprovadas por cor e "
          "viscosidade acima da especificação do grade RB-220."),
        P("A redução do set point pela operação, às 02:00 de 13/08, não produziu efeito "
          "perceptível sobre a temperatura."),
        P("2. O QUE JÁ FOI VERIFICADO", "h1"),
        tabela([
            ["Verificação", "Registro", "Resultado"],
            ["Posicionador e malha de comando de FV-201", "WO-3888",
             "Sem anomalia. Válvula responde ao sinal recebido."],
            ["Transmissor de temperatura TT-201", "WO-3891",
             "Instrumento conforme. A temperatura registrada é real."],
            ["Bomba de circulação P-201, pressão e ronda de campo",
             "RT-20260812-C", "Sem anormalidade observada em campo."],
            ["Temperatura da carga (origem U-100)", "RT-20260812-C",
             "Elevada desde 12/08 22:40. Relatório da U-100 solicitado."],
        ], [56 * mm, 30 * mm, 82 * mm]),
        P("3. O QUE SE PEDE", "h1"),
        P("• Estabelecer a sequência de eventos que levou à condição observada."),
        P("• Determinar por que a unidade não foi capaz de rejeitar a variação de "
          "temperatura da carga."),
        P("• Indicar se a condição era previsível a partir da informação disponível e, em "
          "caso afirmativo, a partir de quando."),
        P("• Propor medidas para evitar recorrência."),
        P("4. MATERIAL DISPONIBILIZADO", "h1"),
        tabela([
            ["Pasta", "Conteúdo"],
            ["data/", "Exportação do PIMS (historian de 08 a 14/08, 5 em 5 min), log de "
                      "alarmes, log de eventos e resultados de laboratório"],
            ["production/", "Ordens de produção, certificado de análise de matéria-prima e "
                            "plano mensal de campanhas"],
            ["maintenance/", "Ordens de trabalho do período e antecedentes"],
            ["operations/", "Relatórios de turno"],
            ["process/", "Descrição de processo, PFD, P&ID e procedimento operacional"],
            ["engineering/", "Design basis, folhas de dados, memória de cálculo e "
                             "filosofia de controle"],
            ["vendor/", "Documentação técnica de fabricantes dos equipamentos da malha"],
            ["safety/", "Estudo HAZOP da unidade"],
            ["specialist/", "Notas técnicas e memorandos internos"],
        ], [30 * mm, 138 * mm]),
        Spacer(1, 3 * mm),
        P("O material foi reunido pela coordenação sem triagem prévia quanto à relevância. "
          "Nem tudo o que está no pacote diz respeito à ocorrência.", "nota"),
        Spacer(1, 5 * mm),
        assinaturas([("Solicitante", "D. Castro", "2026-08-14"),
                     ("Ciente — Processo", "R. Nakamura", "2026-08-14")]),
    ]
    _emitir("investigation_package", "INV-2026-017_solicitacao.pdf", cab, corpo)


def montar_investigation_package():
    destino = os.path.join(RAIZ, "investigation_package")
    for silo in ("production", "maintenance", "operations", "process",
                 "engineering", "vendor", "safety", "specialist"):
        alvo = os.path.join(destino, silo)
        if os.path.isdir(alvo):
            shutil.rmtree(alvo)
        shutil.copytree(os.path.join(RAIZ, silo), alvo)
    alvo_dados = os.path.join(destino, "data")
    os.makedirs(alvo_dados, exist_ok=True)
    # Só os dados que existem no PIMS da planta. `historian_truth.csv` fica em
    # internal/ e NUNCA é copiado: ele contém gain_trim, H e u_cf.
    for arq in ("historian.csv", "alarms.csv", "event_log.csv", "quality.csv"):
        shutil.copy2(os.path.join(RAIZ, "data", arq), os.path.join(alvo_dados, arq))
    investigation_brief()

    proibido = ("ground_truth", "historian_truth", "information_matrix", "u200_case")
    for raiz_dir, _, arquivos in os.walk(destino):
        for a in arquivos:
            assert not any(p in a for p in proibido), \
                f"VAZAMENTO: {a} não pode estar no pacote de investigação"
    return destino


# =============================================================================
# GROUND TRUTH PRIVADO (§23) — NÃO faz parte do pacote de investigação
# =============================================================================
def ground_truth():
    mA, mB, mBC = U.metrics(U.EXP_A), U.metrics(U.EXP_B), U.metrics(U.EXP_BC)
    pre = U.metrics(U.EXP_B, 0.0, U.T_UPSET_INI)
    pos = U.metrics(U.EXP_B, U.T_UPSET_INI, None)
    cA, cB = U.operational_cost(mA)["TOTAL"], U.operational_cost(mB)["TOTAL"]
    dec = dict((n.replace("\n", " "), v) for n, v in U.DECOMPOSICAO)
    q_proj = _curso_exigido(U.CAMPANHA_A.H, U.UCF_PROJETO)

    txt = f"""# Ground Truth — Caso Industrial U-200 / R-201

> **DOCUMENTO PRIVADO DO PESQUISADOR.**
> Não pertence ao `investigation_package/` e não deve ser fornecido a nenhum
> sistema que esteja sendo avaliado sobre este caso.
> Gerado automaticamente a partir de `tools/u200_case.py` — os números abaixo
> são os da simulação, não estimativas.

---

## 1. Causa raiz

**A capacidade de resfriamento instalada de FV-201 foi reduzida em 45 % em
relação à de projeto, sem que ninguém tomasse conhecimento disso.**

Na parada PP-26-03, em 29/07/2026 (WO-3874), o conjunto de trim especificado
`NV4000-40-STD` (Cv 40) estava indisponível em almoxarifado e foi substituído
pelo conjunto `NV4000-22-AC` (Cv 22, gaiola anticavitação de 3 estágios),
disponível em estoque. A substituição é mecanicamente correta, foi executada
segundo boa prática, passou em todos os testes aplicáveis (curso, calibração de
posicionador, estanqueidade classe IV) e foi motivada por uma razão técnica
legítima — a válvula estava sendo revisada justamente por erosão, e uma gaiola
anticavitação combate erosão.

Nenhum ensaio executado detecta a diferença, porque **nenhum deles mede vazão**.
O teste de bancada verifica a relação sinal → curso; a perda está na relação
curso → vazão.

No modelo: `gain_trim` passa de 1,00 para {U.TRIM_SUBSTITUTO:.2f} a partir de
t = 0 do cenário de incidente.

## 2. Causas contribuintes

| # | Causa | Silo de origem | Contribuição no curso de FV-201 |
|---|---|---|---|
| C1 | **Trim de capacidade reduzida** (Cv 22 em lugar de Cv 40) | Manutenção (WO-3874) | **+{dec['+ trim substituto (WO-3874)'] - dec['Projeto (RA-180, trim Cv 40)']:.1f} pontos** |
| C2 | Campanha RB-220, carga com mais monômero ({U.CAMPANHA_A.monomero_pct:.1f} % → {U.CAMPANHA_B.monomero_pct:.1f} %) | Produção (PO-2026-0418) | +{dec['+ campanha RB-220 (PO-2026-0418)'] - dec['+ trim substituto (WO-3874)']:.1f} pontos |
| C3 | Aquecimento do circuito de resfriamento (torre em onda de calor + WO-3882 adiada) | Utilidades / Manutenção | +{dec['+ circuito aquecido (TT-207 +7 K)'] - dec['+ campanha RB-220 (PO-2026-0418)']:.1f} pontos |
| C4 | Supressão do alarme ZAH-201 em 11/08 08:00 | Operação | 0 pontos — remove o **único aviso** |
| C5 | Recomendações HZ-R07 e HZ-R14 do HAZOP em aberto desde 2024 | Segurança de processo | 0 pontos — remove a **barreira sistêmica** |
| G  | Gatilho: elevação de {U.UPSET_D2 * U.DT_K:.1f} K na temperatura da carga (falha de E-202, U-100) | Processo (U-100) | leva a demanda a {dec['+ upset alimentação (+3,0 K)']:.0f} % |

**Nenhuma causa isolada satura a válvula.** C1 sozinha leva o curso a
{dec['+ trim substituto (WO-3874)']:.1f} %; C1+C2 a {dec['+ campanha RB-220 (PO-2026-0418)']:.1f} %;
C1+C2+C3 a {dec['+ circuito aquecido (TT-207 +7 K)']:.1f} %. É a soma das três
mais o gatilho que ultrapassa 100 %.

## 3. Sequência causal

```
    estado normal            29/07  parada PP-26-03; WO-3874 substitui o trim de FV-201
          |                         (capacidade cai 45 %; ninguém sabe)
   mudança operacional       30/07  partida: FV-201 opera a ~58 % em vez de ~{q_proj:.0f} %
          |                         temperatura no SP, produto aprovado
    primeiro sinal           30/07  RT-20260730-A registra "válvula mais aberta que o normal"
          |                         instrumentação consultada informalmente; nada aberto
   mudança de campanha    08-09/08  PO-2026-0418 (RB-220): carga mais concentrada
          |                         curso sobe para ~76 %
      novo comportamento      10/08  ZAH-201 começa a atuar de forma repetitiva
          |                         circuito de resfriamento aquecendo (TT-203, TT-207)
       intervenção            11/08  ZAH-201 SUPRIMIDO (POP § 7.3); WO-3888 aberta
          |                         WO-3888 encerra "sem anomalia" — e está correta
       agravamento            12/08  curso atinge ~94 %; margem operacional ≈ 6 pontos
          |                         temperatura ainda no SP; produto ainda aprovado
      evento crítico       12/08 22:40  TT-204 sobe {U.UPSET_D2 * U.DT_K:.1f} K (falha de E-202 na U-100)
                           12/08 22:50  FV-201 satura em 100 % — ZAHH-201
                           12/08 23:10  TAH-201; temperatura acima do envelope
                           13/08 00:00  primeira amostra reprovada
                           13/08 02:00  SP reduzido — sem efeito (válvula já saturada)
```

## 4. Parâmetros físicos alterados

| Parâmetro | Nominal | No incidente | Significado industrial |
|---|---|---|---|
| `gain_trim` | 1,00 | {U.TRIM_SUBSTITUTO:.2f} | capacidade do trim instalado / trim de projeto |
| `H` | {U.CAMPANHA_A.H:.2f} | {U.CAMPANHA_B.H:.2f} | calor de reação ∝ monômero na carga |
| `u_cf` | {U.UCF_PROJETO:.2f} ({UCF_C:.1f} °C) | {U.UCF_FIM:.2f} ({C(U.UCF_FIM):.1f} °C) | limite frio do loop de água temperada |
| `d2` (gatilho) | 0 | +{U.UPSET_D2:.2f} ({U.UPSET_D2 * U.DT_K:.1f} K) | desvio de temperatura da carga |

Nada mais é alterado. `Da`, `beta`, `gamma`, a sintonia do PID, o SP, a vazão de
carga, os limites de alarme e o ruído são idênticos entre os cenários.

## 5. Relação entre os eventos

O elo que torna o caso difícil é **temporal e assimétrico**:

- C1 ocorre **10 dias antes** do evento crítico e em outro silo (manutenção).
- C1 **não produz sintoma nenhum** enquanto houver curso disponível. A
  temperatura fica no SP; o produto fica em especificação; o erro de controle
  permanece pequeno. Durante os {pre['duracao_h'] / 24:.1f} dias anteriores ao
  gatilho, **{pre['tempo_em_spec_pct']:.1f} % do produto está em especificação** e o
  IAE por hora é {pre['IAE'] / pre['duracao_h']:.4f}.
- C2 e C3 são **visíveis e documentados**, e por isso atraem toda a atenção.
- O gatilho vem **de outra unidade** (U-100), o que reforça a leitura de "causa
  externa".

## 6. Informações que permitem reconstruir a causa

Nenhum documento contém a resposta. Ela exige **no mínimo três silos**:

| # | Informação | Onde está | Silo |
|---|---|---|---|
| 1 | FV-201 recebeu o conjunto `NV4000-22-AC` no lugar do `NV4000-40-STD` | WO-3874, itens de material | Manutenção |
| 2 | `NV4000-22-AC` tem Cv 22 contra Cv 40 do padrão; conjuntos AC reduzem capacidade em 30–60 % | NV-4000-TD § 2 e advertência § 2.3 | Fabricante |
| 3 | FV-201 foi especificada Cv 40, com 45 m³/h a 100 % de curso | U-200-DS-FV201 § 2 | Engenharia |
| 4 | O critério de projeto exige 25 % de reserva de curso | U-200-DB-001 § 4 (DB-4.1) | Engenharia |
| 5 | O curso esperado no caso mais severo é ~{_curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0)):.0f} % | U-200-MC-014 § 4 | Engenharia |
| 6 | **ZT-201 ≈ 94 % com FT-201 ≈ {U.EXP_B['ft201'][U.EXP_B['q'].argmax()]:.0f} m³/h** — 55 % da vazão esperada | historian.csv | Processo/PIMS |
| 7 | O salto de {q_proj:.0f} % para ~58 % ocorre **na partida pós-parada**, antes da troca de campanha | historian.csv + RT-20260730-A | PIMS + Operação |
| 8 | Calibração de posicionador não corrige capacidade; teste de bancada não a detecta | NV-4000-IOM § 5.3.1 | Fabricante |
| 9 | Acima de ~70 % de curso a unidade perde a capacidade de rejeitar perturbações | NT-PROC-2025-11 | Especialista |
| 10 | O desvio "capacidade MENOS do elemento final" está previsto no HAZOP, nó 3 | HZ-U200-2024-03 | Segurança |

**O cruzamento mínimo suficiente é 1 × 2 × 3** (WO + fabricante + folha de
dados). O item 6 confirma independentemente pelos dados. O item 7 data o início.

## 7. Hipóteses falsas

| Hipótese | Evidência a favor | Por que é falsa | Como descartar |
|---|---|---|---|
| **H1 — Sintonia do TIC-201** | Erro grande e persistente a partir de 12/08; SP reduzido sem efeito | Antes do gatilho o IAE/h é {pre['IAE'] / pre['duracao_h']:.4f} e {pre['tempo_em_spec_pct']:.1f} % do produto está em spec. Nenhum ganho cria capacidade de troca térmica | Observar que a MV está em 100 %: com o atuador saturado a sintonia é irrelevante |
| **H2 — Perda de água de resfriamento** | TT-203 subiu {5.0:.0f} K; TAH-203 atuou várias vezes; WO-3882 aberta e pendente; FT-201 abaixo do esperado | É contribuinte real (C3), mas responde por apenas {dec['+ circuito aquecido (TT-207 +7 K)'] - dec['+ campanha RB-220 (PO-2026-0418)']:.1f} dos {dec['+ circuito aquecido (TT-207 +7 K)'] - dec['Projeto (RA-180, trim Cv 40)']:.1f} pontos de curso consumidos. Com o trim correto, a mesma torre e o mesmo gatilho **não saturam a válvula** | Contrafactual: pressão do header normal; P-201 normal; e a vazão baixa persiste mesmo quando a torre está fria |
| **H3 — Mudança de campanha / carga térmica do RB-220** | Coincide temporalmente com o agravamento; PO documenta carga mais concentrada; curso sobe 18 pontos na transição | É contribuinte real (C2). Mas o RB-220 está **dentro do envelope de projeto** — o caso MC-4 da memória de cálculo prevê {_curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0)):.0f} % de curso, não 94 % | Comparar o curso observado com o previsto em U-200-MC-014 para o mesmo grade |
| **H4 — Instrumentação (TT-201 ou AT-205)** | AT-205 tinha desvio real e foi recalibrado (WO-3871); TT-201 verificado durante a ocorrência | WO-3891 confirma TT-201 conforme; a temperatura é real. O desvio de AT-205 é anterior, real e **irrelevante** para a capacidade de resfriamento | Loop check de TT-201 (já executado) e comparação com TW-201B |
| **H5 — Posicionador de FV-201** | Operação relatou "válvula muito aberta"; WO-3888 aberta | WO-3888 está **correta**: o posicionador está bom. A válvula obedece ao sinal. O problema não é sinal → curso, é curso → vazão | NV-4000-IOM § 5.3.1 explica exatamente por que a verificação feita não detecta o problema |

Todas as hipóteses falsas são **defensáveis com a evidência disponível**. H2 e H3
são parcialmente verdadeiras, o que é o caso mais difícil: quem parar nelas
produz um relatório correto, incompleto e inútil para evitar a recorrência.

## 8. Comportamento esperado do PID

O PID **funciona corretamente durante todo o caso**. Ele é sintonizado por IMC
(λ = τ) sobre um modelo identificado na própria MV, tem anti-windup e respeita
a saturação. Números medidos:

| | A — baseline | B — com incidente | B' — mesmo incidente, trim correto |
|---|---|---|---|
| IAE (horizonte) | {mA['IAE']:.2f} | {mB['IAE']:.2f} | {mBC['IAE']:.2f} |
| Tempo em especificação | {mA['tempo_em_spec_pct']:.1f} % | {mB['tempo_em_spec_pct']:.1f} % | {mBC['tempo_em_spec_pct']:.1f} % |
| Curso máximo de FV-201 | {mA['curso_max_pct']:.1f} % | {mB['curso_max_pct']:.1f} % | {mBC['curso_max_pct']:.1f} % |
| Tempo saturado | {mA['tempo_saturado_h']:.1f} h | {mB['tempo_saturado_h']:.1f} h | {mBC['tempo_saturado_h']:.1f} h |
| Tempo acima do TAH-201 | {mA['tempo_acima_TAH_h']:.1f} h | {mB['tempo_acima_TAH_h']:.1f} h | {mBC['tempo_acima_TAH_h']:.1f} h |
| Temperatura máxima | {mA['temperatura_max_C']:.1f} °C | {mB['temperatura_max_C']:.1f} °C | {mBC['temperatura_max_C']:.1f} °C |
| Custo operacional | {cA:.3f} | {cB:.3f} | {U.operational_cost(mBC)['TOTAL']:.3f} |

Recorte antes do gatilho (t < {U.T_UPSET_INI:.0f}, {pre['duracao_h'] / 24:.1f} dias):
**{pre['tempo_em_spec_pct']:.1f} % em especificação, IAE/h = {pre['IAE'] / pre['duracao_h']:.4f},
{pre['tempo_acima_TAH_h']:.0f} h acima do alarme — e curso máximo de
{pre['curso_max_pct']:.1f} %.** É esta linha que define o caso.

Depois do gatilho: IAE sobe para {pos['IAE']:.1f}, tempo em spec cai para
{pos['tempo_em_spec_pct']:.1f} %, {pos['tempo_saturado_h']:.1f} h com a válvula no batente.

**Assimetria central:** o IAE de B é {mB['IAE'] / mA['IAE']:.1f}× o de A, mas o custo
operacional é {cB / cA:.0f}× o de A. Uma função objetivo baseada em erro subestima
o problema por mais de uma ordem de grandeza.

## 9. Comportamento que um controlador superior deveria produzir

Não é "controlar melhor a temperatura" — não há erro relevante a reduzir antes
do gatilho. É **agir sobre a margem antes de ela acabar**. Comportamentos que
distinguiriam um controlador superior, em ordem de ambição:

1. **Detectar** que ZT-201 e FT-201 são inconsistentes com a curva de Cv do
   conjunto especificado, e sinalizar isso ainda em 30/07 — 13 dias antes.
2. **Reconhecer** que a margem de curso, e não o erro, é a variável limitante, e
   levar isso ao operador com antecedência (é literalmente a recomendação
   HZ-R14, em aberto desde 2024).
3. **Negociar a operação**: com a margem em 6 pontos, propor reduzir carga ou
   antecipar o fim da campanha, aceitando perda de produção para preservar
   capacidade de rejeitar perturbação.
4. **Não desperdiçar ação inútil**: reconhecer que, com a MV saturada, reduzir o
   SP não tem efeito — e dizer isso, em vez de registrar erro crescente.

Os itens 1 e 2 exigem informação que **não está no historian**: exigem o
datasheet, a memória de cálculo, a ordem de manutenção e o documento do
fabricante. É essa a razão de ser do caso.

## 10. Métricas de avaliação

Ordenadas por poder discriminante medido entre A e B:

| Métrica | A | B | Razão | Discrimina? |
|---|---|---|---|---|
| `tempo_saturado_h` | {mA['tempo_saturado_h']:.1f} | {mB['tempo_saturado_h']:.1f} | ∞ | **sim, absoluta** |
| `tempo_acima_TAH_h` | {mA['tempo_acima_TAH_h']:.1f} | {mB['tempo_acima_TAH_h']:.1f} | ∞ | **sim, absoluta** |
| `margem_curso_min_pct` | {mA['margem_curso_min_pct']:.1f} | {mB['margem_curso_min_pct']:.1f} | — | **sim, é a variável do caso** |
| `producao_perdida_pct` | {mA['producao_perdida_pct']:.1f} | {mB['producao_perdida_pct']:.1f} | — | sim |
| `custo operacional` | {cA:.3f} | {cB:.3f} | {cB / cA:.0f}× | sim |
| `IAE` | {mA['IAE']:.2f} | {mB['IAE']:.2f} | {mB['IAE'] / mA['IAE']:.1f}× | fraco — subestima |
| `esforco_controle` | {mA['esforco_controle']:.2f} | {mB['esforco_controle']:.2f} | {mB['esforco_controle'] / mA['esforco_controle']:.2f}× | **enganoso: B parece melhor** |

A última linha merece destaque: pela métrica clássica de esforço de controle, o
cenário com incidente é **melhor** que o baseline — porque a válvula está
travada e não se mexe. Qualquer avaliação que use esforço de controle como
proxy de qualidade de operação é invertida por este caso.

**Regra de avaliação recomendada:** um controlador só deve ser considerado
superior neste benchmark se reduzir `tempo_saturado_h` **e**
`producao_perdida_pct` sem aumentar `tempo_acima_TAH_h`. Melhora de IAE isolada
não conta.

## 11. Como reproduzir

```bash
python tools/u200_case.py          # roda A, B, C, B' e os 29 testes de consistência
python tools/build_notebook.py     # regenera o notebook a partir do módulo
python tools/build_docs.py         # regenera todos os documentos e o pacote
```

Semente única: `Scenario.seed = {U.CEN_BASELINE.seed}`. Ruído pré-gerado em
arrays antes do laço, de modo que A, B, C e B' vejam a mesma realização nos
mesmos instantes. `run_case(novo_pid(), CEN_BASELINE)` reproduz `EXP_A` bit a
bit — verificado em teste.
"""
    destino = os.path.join(RAIZ, "internal", "ground_truth_case.md")
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    open(destino, "w", encoding="utf-8").write(txt)
    GERADOS.append(os.path.relpath(destino, RAIZ))
    return destino


# =============================================================================
# MATRIZ DE RASTREABILIDADE (§22) — uso interno do pesquisador
# =============================================================================
MATRIZ = [
    # (informação, silo, documento, disponível antes do evento?, relevância, relação com o GT)
    ("Conjunto de trim NV4000-22-AC aplicado em FV-201 no lugar do NV4000-40-STD",
     "Manutenção", "WO-3874", "Sim — 29/07", "DECISIVA", "C1 · causa raiz, evidência 1 de 3"),
    ("Trim original NV4000-40-STD indisponível em almoxarifado",
     "Manutenção", "WO-3874", "Sim — 29/07", "Alta", "C1 · explica a decisão"),
    ("Recomendação de confirmar dimensionamento na próxima parada",
     "Manutenção", "WO-3874", "Sim — 29/07", "Alta", "C1 · fio solto deixado pelo executante"),
    ("Não foi feito ensaio de vazão após a substituição do trim",
     "Manutenção", "WO-3874", "Sim — 29/07", "Alta", "C1 · explica por que não foi detectado"),
    ("Cv 22 do conjunto AC contra Cv 40 do conjunto padrão (mesmo corpo)",
     "Fabricante", "NV-4000-TD § 2", "Sim — sempre", "DECISIVA", "C1 · evidência 2 de 3"),
    ("Conjuntos anticavitação reduzem a capacidade em 30 a 60 %",
     "Fabricante", "NV-4000-TD § 2.3", "Sim — sempre", "DECISIVA", "C1 · quantifica a perda"),
    ("Calibração de posicionador não compensa diferença de capacidade",
     "Fabricante", "NV-4000-IOM § 5.3.1", "Sim — sempre", "Alta",
     "C1 · invalida a conclusão da WO-3888"),
    ("Sintoma 'válvula opera mais aberta com resposta normal ao sinal' remete a § 5.3",
     "Fabricante", "NV-4000-IOM § 6", "Sim — sempre", "Alta", "C1 · tabela de diagnóstico"),
    ("FV-201 especificada com Cv 40 e 45 m³/h a 100 % de curso",
     "Engenharia", "U-200-DS-FV201 § 2 e § 3", "Sim — sempre", "DECISIVA", "C1 · evidência 3 de 3"),
    ("Substituição de trim por capacidade diferente invalida o dimensionamento",
     "Engenharia", "U-200-DS-FV201, nota", "Sim — sempre", "Alta", "C1 · regra violada"),
    ("Critério DB-4.1: reserva mínima de 25 % de curso de FV-201",
     "Engenharia", "U-200-DB-001 § 4", "Sim — sempre", "DECISIVA",
     "Define o que foi perdido; base do critério de avaliação"),
    ("Curso previsto no caso mais severo (RB-220, torre a 32 °C)",
     "Engenharia", "U-200-MC-014 § 4", "Sim — sempre", "DECISIVA",
     "Referência quantitativa contra a qual comparar o observado; descarta H3"),
    ("Ganho por ponto de curso decresce conforme a/(a+1)",
     "Engenharia", "U-200-MC-014 § 2(b)", "Sim — sempre", "Alta",
     "Explica por que 94 % de curso não é 'quase 100 % de capacidade'"),
    ("Não há redundância de FV-201 nem resfriamento de emergência",
     "Engenharia", "U-200-DB-001 § 5", "Sim — sempre", "Média", "Contexto de severidade"),
    ("Rejeição de perturbação de 3,0 K verificada em projeto",
     "Engenharia", "U-200-MC-014 § 6", "Sim — sempre", "Alta",
     "Prova que o gatilho é uma perturbação de projeto, não excepcional"),
    ("ZT-201 ≈ 94 % com FT-201 muito abaixo da vazão esperada para esse curso",
     "Processo / PIMS", "data/historian.csv", "Sim — contínuo", "DECISIVA",
     "C1 · confirmação independente pelos dados"),
    ("Salto do curso de ~32 % para ~58 % ocorre na partida de 30/07, antes da campanha",
     "Processo / PIMS", "data/historian.csv", "Sim — 30/07", "DECISIVA",
     "C1 · data o início; separa C1 de C2 e C3"),
    ("TT-207 sobe ~7 K ao longo da campanha",
     "Processo / PIMS", "data/historian.csv", "Sim — contínuo", "Média",
     "C3 · contribuinte real; sustenta H2"),
    ("TT-203 (água de torre) sobe ~5 K, com ciclo diurno",
     "Processo / PIMS", "data/historian.csv", "Sim — contínuo", "Média", "C3 · sustenta H2"),
    ("ZAH-201 ativo desde 10/08 05:55",
     "Processo / PIMS", "data/alarms.csv", "Sim — 10/08", "Alta", "C4 · o aviso existiu"),
    ("ZAH-201 suprimido em 11/08 08:00",
     "Processo / PIMS", "data/alarms.csv", "Sim — 11/08", "Alta", "C4 · o aviso foi removido"),
    ("ZAHH-201 (saturação) atua 20 min ANTES de TAH-201",
     "Processo / PIMS", "data/alarms.csv", "Sim — 12/08", "Alta",
     "A válvula avisa antes da temperatura; ordem dos eventos"),
    ("Amostras reprovadas por cor e viscosidade a partir de 13/08 00:00",
     "Processo / LIMS", "data/quality.csv", "Sim — 13/08", "Média", "Consequência"),
    ("Produto 100 % aprovado durante toda a campanha até o gatilho",
     "Processo / LIMS", "data/quality.csv", "Sim — contínuo", "Alta",
     "Prova que a degradação não era visível pela qualidade"),
    ("RB-220 com 58,1 % de monômero contra 57,0 % do RA-180",
     "Produção", "PO-2026-0418 § 1", "Sim — 08/08", "Alta", "C2 · contribuinte real"),
    ("Lote MB-4471 com assay 98,6 %, faixa alta da especificação de compra",
     "Produção", "COA-MB-4471", "Sim — 05/08", "Média", "C2 · reforça a carga térmica"),
    ("Set point térmico é o MESMO nas duas campanhas",
     "Produção", "PO-2026-0417 e PO-2026-0418 § 2", "Sim — 08/08", "Alta",
     "Descarta a hipótese de mudança de SP como causa"),
    ("Campanha RB-220 antecipada em 5 dias",
     "Produção", "PLN-2026-08", "Sim — 28/07", "Baixa",
     "Ruído — parece relevante, não é"),
    ("FV-201 abrindo ~58 % contra ~32 % antes da parada, com temperatura no SP",
     "Operação", "RT-20260730-A, comentário do operador", "Sim — 30/07", "DECISIVA",
     "C1 · primeiro sinal humano, 13 dias antes"),
    ("Curso sobe para ~70 % com a entrada do RB-220",
     "Operação", "RT-20260809-C", "Sim — 09/08", "Média", "C2"),
    ("Alarme ZAH-201 repetitivo atrapalha a leitura do console",
     "Operação", "RT-20260810-A", "Sim — 10/08", "Alta", "C4 · motivação da supressão"),
    ("Instrumentação informa que 'quem pede a abertura é o controlador'",
     "Operação", "RT-20260811-A", "Sim — 11/08", "Alta",
     "Verdadeiro e enganoso: encerra a linha de investigação certa"),
    ("Redução do SP sem efeito sobre a temperatura",
     "Operação", "RT-20260812-C", "Sim — 13/08", "Alta",
     "Sintoma de MV saturada; descarta H1"),
    ("Pressão do header e P-201 normais, verificados em campo",
     "Operação", "RT-20260812-C", "Sim — 12/08", "Alta", "Descarta parte de H2"),
    ("POP § 3.2: reduzir SP só tem efeito se FV-201 não estiver saturada",
     "Processo", "POP-U200-014 § 3.2", "Sim — sempre", "Alta",
     "A regra existia e não foi aplicada"),
    ("POP § 2.3: abertura acima de 60 % deve ser comunicada a Processo",
     "Processo", "POP-U200-014 § 2.3", "Sim — sempre", "Alta",
     "Barreira procedural existente; não acionada"),
    ("POP § 7.3: supressão de alarme com prazo de revisão de 7 dias",
     "Processo", "POP-U200-014 § 7.3", "Sim — sempre", "Média", "C4 · a supressão foi regular"),
    ("FV-201 regula temperatura da camisa, não vazão de refrigerante",
     "Processo", "U-200-PD-001 § 3", "Sim — sempre", "Alta", "Necessário para ler o P&ID"),
    ("A malha não conhece margem nem especificação de conversão",
     "Engenharia", "U-200-CP-001 § 2", "Sim — sempre", "Alta",
     "Enuncia o limite de escopo do PID — núcleo do benchmark"),
    ("ZAH-201 é o único alarme que informa sobre reserva de rejeição",
     "Engenharia", "U-200-CP-001 § 3", "Sim — sempre", "Alta", "C4 · o que a supressão removeu"),
    ("HAZOP nó 3: desvio 'capacidade MENOS' do elemento final",
     "Segurança", "HZ-U200-2024-03, nó 3", "Sim — sempre", "DECISIVA",
     "O modo de falha estava previsto e descrito"),
    ("HZ-R07 (verificar dimensionamento em substituição) EM ABERTO desde 2024",
     "Segurança", "HZ-U200-2024-03, recomendações", "Sim — sempre", "Alta",
     "C5 · barreira sistêmica ausente"),
    ("HZ-R14 (indicação de margem no console) EM ABERTO desde 2024",
     "Segurança", "HZ-U200-2024-03, recomendações", "Sim — sempre", "Alta",
     "C5 · barreira sistêmica ausente"),
    ("Acima de ~70 % de curso a unidade perde capacidade de rejeitar perturbação",
     "Especialista", "NT-PROC-2025-11", "Sim — 2025", "Alta",
     "Descreve o fenômeno com um ano de antecedência"),
    ("Lista do que NÃO explica: sintonia, instrumento, apenas a água de torre",
     "Especialista", "NT-PROC-2025-11", "Sim — 2025", "Alta", "Descarta H1, H4 e H2 puro"),
    ("Em 9 de 14 serviços da PP-26-03 foi aplicado item equivalente, com 0 verificações",
     "Especialista", "MEMO-CONF-2026-04 § 3", "Sim — 04/2026", "Alta",
     "C1 · contexto organizacional; PP-26-03 é a parada da WO-3874"),
    ("Equivalência costuma ser avaliada quanto à montagem, não ao desempenho",
     "Especialista", "MEMO-CONF-2026-04 § 2", "Sim — 04/2026", "Alta", "C1 · nomeia o mecanismo"),
    ("WO-3882 (torre TR-901) aberta e pendente desde 03/08",
     "Manutenção", "WO-3882", "Sim — 03/08", "Média", "C3 · contribuinte; sustenta H2"),
    ("WO-3888 encerrada 'sem anomalia encontrada' em FV-201",
     "Manutenção", "WO-3888", "Sim — 11/08", "Alta",
     "Falsa negativa correta: encerra a linha certa pelo motivo errado"),
    ("WO-3891: TT-201 conforme, temperatura registrada é real",
     "Manutenção", "WO-3891", "Sim — 13/08", "Média", "Descarta H4"),
    ("WO-3871: AT-205 tinha desvio real de +0,011 e foi recalibrado",
     "Manutenção", "WO-3871", "Sim — 14/07", "Baixa",
     "Ruído — falha real e irrelevante; alimenta H4"),
    ("WO-3862: P-201 sem anomalia em análise de vibração",
     "Manutenção", "WO-3862", "Sim — 18/06", "Nenhuma", "Ruído"),
    ("WO-3879: troca de gaxeta de P-201 na mesma parada",
     "Manutenção", "WO-3879", "Sim — 29/07", "Baixa",
     "Ruído — mesma data da WO-3874, atrai atenção"),
    ("JX-200-DS: datasheet do termopar",
     "Fabricante", "JX-200-DS", "Sim — sempre", "Nenhuma", "Ruído"),
    ("U-200-DS-R201: folha de dados do reator",
     "Engenharia", "U-200-DS-R201", "Sim — sempre", "Baixa", "Contexto"),
]


def matriz_rastreabilidade():
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Matriz de informação"
    cabs = ["Informação", "Silo", "Documento", "Disponível antes do evento?",
            "Relevância", "Relação com o ground truth"]
    ws.append(cabs)
    cor = {"DECISIVA": "FFD9C9", "Alta": "FFF0DC", "Média": "F0F0F0",
           "Baixa": "FAFAFA", "Nenhuma": "FFFFFF"}
    for linha in MATRIZ:
        ws.append(list(linha))
        for c in ws[ws.max_row]:
            c.fill = PatternFill("solid", fgColor=cor.get(linha[4], "FFFFFF"))
            c.alignment = Alignment(wrap_text=True, vertical="top")
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="4A4A4A")
        c.alignment = Alignment(wrap_text=True, vertical="center")
    for i, larg in enumerate([62, 16, 30, 20, 13, 52], start=1):
        ws.column_dimensions[get_column_letter(i)].width = larg
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    # aba de resumo
    ws2 = wb.create_sheet("Resumo por silo")
    ws2.append(["Silo", "Itens", "DECISIVA", "Alta", "Média", "Baixa/Nenhuma"])
    silos = sorted({m[1] for m in MATRIZ})
    for s in silos:
        it = [m for m in MATRIZ if m[1] == s]
        ws2.append([s, len(it),
                    sum(1 for m in it if m[4] == "DECISIVA"),
                    sum(1 for m in it if m[4] == "Alta"),
                    sum(1 for m in it if m[4] == "Média"),
                    sum(1 for m in it if m[4] in ("Baixa", "Nenhuma"))])
    ws2.append([])
    ws2.append(["TOTAL", len(MATRIZ),
                sum(1 for m in MATRIZ if m[4] == "DECISIVA"),
                sum(1 for m in MATRIZ if m[4] == "Alta"),
                sum(1 for m in MATRIZ if m[4] == "Média"),
                sum(1 for m in MATRIZ if m[4] in ("Baixa", "Nenhuma"))])
    for c in ws2[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="4A4A4A")
    ws2.column_dimensions["A"].width = 22
    for col in "BCDEF":
        ws2.column_dimensions[col].width = 13

    destino = os.path.join(RAIZ, "internal", "information_matrix.xlsx")
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    wb.save(destino)
    # espelho em CSV, para quem não abrir o xlsx
    csv_destino = os.path.join(RAIZ, "internal", "information_matrix.csv")
    import csv as _csv
    with open(csv_destino, "w", newline="", encoding="utf-8") as fh:
        w = _csv.writer(fh)
        w.writerow(cabs)
        w.writerows(MATRIZ)
    GERADOS.extend([os.path.relpath(destino, RAIZ), os.path.relpath(csv_destino, RAIZ)])
    return destino


# =============================================================================
# README
# =============================================================================
def readme():
    mA, mB = U.metrics(U.EXP_A), U.metrics(U.EXP_B)
    pre = U.metrics(U.EXP_B, 0.0, U.T_UPSET_INI)
    cA, cB = U.operational_cost(mA)["TOTAL"], U.operational_cost(mB)["TOTAL"]
    txt = f"""# Caso Industrial U-200 — benchmark multissilo para controle de processos

Benchmark construído sobre o CSTR adimensional de **Lee, Jin & So (2025),
*Algorithms* 18(7), 442**, para avaliar estratégias de controle em uma situação
em que **controlar bem a variável não é o mesmo que operar bem a unidade**.

O caso **não** contém, e não deve conter, nenhum controlador inteligente. Ele é
o problema sobre o qual esse controlador será futuramente avaliado.

---

## 1. Objetivo

Durante {pre['duracao_h'] / 24:.1f} dias de campanha, o PID da unidade mantém a
temperatura do reator no set point, com **{pre['tempo_em_spec_pct']:.1f} % do produto
em especificação** e IAE por hora de {pre['IAE'] / pre['duracao_h']:.4f}. No mesmo
período, a abertura da válvula de resfriamento sobe de ~32 % para
**{pre['curso_max_pct']:.1f} %** — a unidade consome toda a sua reserva de rejeição
de perturbação sem que nenhuma métrica de erro registre nada.

Quando uma variação **de apenas {U.UPSET_D2 * U.DT_K:.1f} K** na temperatura da carga
chega, a válvula satura e a unidade perde o controle da temperatura por
{mB['tempo_saturado_h']:.0f} horas, produzindo material fora de especificação.

| | A — baseline | B — com incidente | razão |
|---|---|---|---|
| IAE | {mA['IAE']:.2f} | {mB['IAE']:.2f} | **{mB['IAE'] / mA['IAE']:.1f}×** |
| Custo operacional | {cA:.3f} | {cB:.3f} | **{cB / cA:.0f}×** |
| Esforço de controle | {mA['esforco_controle']:.2f} | {mB['esforco_controle']:.2f} | {mB['esforco_controle'] / mA['esforco_controle']:.2f}× (B parece *melhor*) |

Essa assimetria é o caso: **o erro cresce {mB['IAE'] / mA['IAE']:.0f}×; o custo de
operar cresce {cB / cA:.0f}×.** Uma função objetivo baseada em `SP − PV`
subestima o problema por mais de uma ordem de grandeza.

## 2. A planta

**U-200 / R-201** — reator CSTR encamisado de 12 m³, reação exotérmica de
primeira ordem A → B, resinas alquídicas e poliéster.

| | |
|---|---|
| Temperatura de operação | {SP_C:.1f} °C (envelope {ENV_LO_C:.1f} – {ENV_HI_C:.1f} °C) |
| Carga | 9,0 m³/h · tempo de residência {U.TAU_MIN:.0f} min |
| Conversão | 0,765 nominal |
| Remoção de calor | loop fechado de água temperada, 60 m³/h |
| Elemento final | **FV-201**, válvula de três vias que desvia o loop por E-201 |
| Alarmes | TAH-201 {TAH_C:.1f} °C · TAHH-201 (SIS) {TAHH_C:.1f} °C · ZAH-201 em {100 * U.TRAVEL_ZAH:.0f} % de curso |

A MV **não** é a temperatura da camisa do artigo: é a abertura de FV-201. A
ponte é a Eq. 2 do artigo, `u = (a·u_cf + x₂)/(a+1)`, o que torna a saturação
da MV um limite **físico** e coloca a *capacidade do equipamento* — e não o
controlador — como variável limitante.

Escala dimensional: `T = T_f(1 + x₂/γ)` com `T_f = {U.TF_K:.1f} K` e `γ = {U.GAMMA:.0f}`,
o que dá `E_a = {U.GAMMA * U.R_GAS * U.TF_K / 1000:.1f} kJ/mol` e 1 unidade de x₂ =
{U.DT_K:.2f} K. Todos os documentos foram gerados a partir desse mapa.

## 3. Como executar

```bash
python tools/u200_case.py        # experimentos A, B, C, contrafactual e 29 testes
python tools/build_notebook.py   # regenera o notebook a partir do módulo
python tools/build_docs.py       # regenera figuras, documentos e o pacote de investigação
```

Ou abra `notebook/projeto_case_industrial.ipynb` e execute do início ao fim.

Dependências: `numpy`, `matplotlib`, `reportlab`, `openpyxl`, `nbformat`, `pillow`.

> `tools/u200_case.py` é a **fonte única da verdade**. O notebook é gerado a
> partir dele (formato percent) e os documentos importam dele todo número que
> também exista no simulador. Não edite o notebook à mão.

## 4. Estrutura

```
case_study/
├── notebook/projeto_case_industrial.ipynb   modelo, incidente, métricas, comparação
├── tools/                                   fonte única da verdade
│   ├── u200_case.py       modelo + cenário + harness + métricas + testes
│   ├── docgen.py          molde de documento industrial em PDF
│   ├── diagramas.py       PFD, P&ID e curva de Cv
│   ├── build_notebook.py  módulo  →  notebook
│   └── build_docs.py      módulo  →  documentos + pacote + ground truth + matriz
├── data/                  historian, alarmes, eventos, qualidade
├── production/            ordens de produção, COA, plano de campanhas
├── maintenance/           ordens de trabalho
├── operations/            relatórios de turno
├── process/               descrição, PFD, P&ID, procedimento operacional
├── engineering/           design basis, folhas de dados, memória de cálculo, filosofia
├── vendor/                documentação dos fabricantes
├── safety/                HAZOP
├── specialist/            notas técnicas e memorandos
├── figures/               figuras dos experimentos e diagramas
├── investigation_package/ ► o que a equipe de investigação recebe
└── internal/              ► ground truth e matriz — NÃO entregar
```

## 5. O que pertence a cada silo

| Silo | Pasta | Contém |
|---|---|---|
| Processo / PIMS | `data/` | historian de 5 em 5 min, log de alarmes, log de eventos, LIMS |
| Produção | `production/` | PO-2026-0417, PO-2026-0418, COA-MB-4471, PLN-2026-08 |
| Manutenção | `maintenance/` | WO-3862, WO-3871, **WO-3874**, WO-3879, WO-3882, WO-3888, WO-3891 |
| Operação | `operations/` | 7 relatórios de turno, de 30/07 a 13/08 |
| Processo | `process/` | U-200-PD-001, U-200-PFD-001, U-200-PID-201, POP-U200-014 |
| Engenharia | `engineering/` | U-200-DB-001, U-200-DS-FV201, U-200-DS-R201, U-200-MC-014, U-200-CP-001 |
| Fabricante | `vendor/` | NV-4000-TD, NV-4000-IOM, JX-200-DS |
| Segurança | `safety/` | HZ-U200-2024-03 |
| Especialista | `specialist/` | NT-PROC-2025-11, MEMO-CONF-2026-04 |

A causa raiz **não está escrita em nenhum desses documentos**. Ela exige o
cruzamento de, no mínimo, três silos distintos.

## 6. Reprodutibilidade

Semente única `{U.CEN_BASELINE.seed}`. O ruído é **pré-gerado em arrays antes do
laço**, de modo que baseline, incidente e contrafactual vejam a mesma realização
nos mesmos instantes, independentemente do ramo do cenário. Um teste verifica
que `run_case(novo_pid(), CEN_BASELINE)` reproduz o experimento A bit a bit, e
outro que os experimentos B e C são idênticos.

Entre B e C, a **única** variável é o controlador. Entre A e B, a única variável
é o cenário.

## 7. Métricas

Quatro famílias, em `metrics()`:

- **Controle** — IAE, ISE, ITAE, erro máximo, erro médio.
- **Processo** — conversão média, tempo em especificação, produção perdida, overshoot.
- **Operação** — curso médio e máximo de FV-201, **margem mínima de curso**,
  tempo saturado, tempo acima de ZAH-201, esforço de controle, intervenções.
- **Segurança (exposição, não probabilidade)** — tempo acima do envelope, tempo
  acima do TAH-201, temperatura máxima, **margem mínima até o TAHH-201**.

`operational_cost()` agrega essas famílias com pesos declarados em
`PESOS_CUSTO`. Os pesos são uma **decisão do pesquisador**, estão explícitos no
código e não pretendem representar probabilidade de evento.

**Critério de avaliação recomendado:** um controlador só é superior neste
benchmark se reduzir `tempo_saturado_h` **e** `producao_perdida_pct` **sem**
aumentar `tempo_acima_TAH_h`. Melhora de IAE isolada não conta — e
`esforco_controle` é enganoso aqui, porque o cenário degradado o *reduz*
(a válvula fica travada).

## 8. Investigação × ground truth

| | |
|---|---|
| `investigation_package/` | Tudo o que a equipe de engenharia receberia. Sem ground truth, sem ranking de evidências, sem indicação de quais documentos importam. Contém material irrelevante, como qualquer pacote real. |
| `internal/ground_truth_case.md` | Causa raiz, causas contribuintes, cadeia causal, hipóteses falsas e por que são plausíveis, comportamento esperado do PID, métricas de avaliação. |
| `internal/information_matrix.xlsx` | Mapa entre informação, silo, documento, disponibilidade temporal, relevância e relação com a causa. {len(MATRIZ)} itens. |
| `internal/historian_truth.csv` | Estados verdadeiros e parâmetros ocultos (`gain_trim`, `H`, `u_cf`, `d1`, `d2`). |

Um teste automático verifica que nenhum arquivo com `ground_truth`,
`historian_truth`, `information_matrix` ou `u200_case` no nome chega ao pacote
de investigação.

## 9. Interface para o controlador futuro

```python
class BaseController:
    def reset(self, operating_context=None): ...
    def update(self, observation, context, dt) -> float:   # abertura de FV-201, 0..1
        ...

controller = novo_pid()                    # hoje
controller = ProposedController(...)       # depois — mesma planta, mesmo cenário
resultado  = run_case(controller, CEN_INCIDENTE)
```

`observation` contém apenas o que o DCS mede (SP, PV, ZT-201, FT-201, TT-203,
TT-207, TT-204, AT-205). `context` traz campanha, especificação, envelope e
limites de alarme. **`gain_trim` não está lá** — a perda de capacidade de
FV-201 não é medida por nenhum instrumento da unidade. Reconstruí-la a partir
dos documentos é o problema.

---

*Gerado a partir de `tools/u200_case.py`. Revisão do caso: 1.0 — 2026-08-25.*
"""
    destino = os.path.join(RAIZ, "README.md")
    open(destino, "w", encoding="utf-8").write(txt)
    GERADOS.append("README.md")
    return destino


# =============================================================================
# VERIFICAÇÃO DE CONSISTÊNCIA DOCUMENTAL (§28)
# =============================================================================
def verificar_documentacao():
    ok = []
    docs = {os.path.basename(g) for g in GERADOS}

    # (a) todo documento citado na matriz existe como arquivo gerado
    citados = {m[2].split()[0].split(",")[0] for m in MATRIZ}
    ignorar = {"data/historian.csv", "data/alarms.csv", "data/quality.csv",
               "data/event_log.csv", "PO-2026-0417"}
    faltando = []
    for c in sorted(citados - ignorar):
        raiz_c = c.split("§")[0].strip().rstrip(",")
        if not any(raiz_c in d for d in docs):
            faltando.append(c)
    assert not faltando, f"documentos citados na matriz e não gerados: {faltando}"
    ok.append(f"{len(citados)} documentos citados na matriz existem")

    # (b) toda tag citada nos diagramas e no índice de instrumentos existe
    tags_doc = {"R-201", "TT-201", "TIC-201", "FV-201", "ZT-201", "FT-201", "TT-202",
                "TT-203", "TT-204", "TT-207", "FT-204", "AT-205", "P-201", "E-201",
                "E-202", "TK-201", "PSV-201"}
    desconhecidas = tags_doc - set(U.TAGS)
    assert not desconhecidas, f"tags nos documentos sem correspondência no simulador: {desconhecidas}"
    ok.append(f"{len(tags_doc)} tags dos documentos existem no simulador")

    # (c) o event_log está em ordem cronológica
    import csv as _csv
    with open(os.path.join(RAIZ, "data", "event_log.csv"), encoding="utf-8") as fh:
        ts = [linha["timestamp"] for linha in _csv.DictReader(fh)]
    assert ts == sorted(ts), "event_log.csv fora de ordem cronológica"
    ok.append(f"event_log.csv com {len(ts)} eventos em ordem cronológica")

    # (d) as WO e PO citadas no event log foram geradas
    for ident in ("WO-3871", "WO-3874", "WO-3882", "PO-2026-0417", "PO-2026-0418"):
        assert any(ident in d for d in docs), f"{ident} citado no event log e não gerado"
    ok.append("WO e PO citadas no event log existem como documento")

    # (e) datas coerentes: WO-3874 antes do início do registro do historian
    assert "2026-07-29" < f"{U.T_ZERO:%Y-%m-%d}", "WO-3874 deveria preceder o historian"
    ok.append("WO-3874 (29/07) precede o início do historian (08/08)")

    # (f) os limites dos documentos batem com os do simulador
    assert abs(C(U.X2_TAH) - TAH_C) < 1e-9 and abs(C(U.X2_TAHH) - TAHH_C) < 1e-9
    ok.append("limites de alarme dos documentos derivam do simulador")

    # (g) a memória de cálculo prevê margem, e o observado a viola
    q_mc4 = _curso_exigido(U.CAMPANHA_B.H, _ucf_de_torre(32.0))
    assert q_mc4 <= 75.0, f"caso MC-4 deveria atender ao critério DB-4.1 ({q_mc4:.1f} %)"
    assert U.metrics(U.EXP_B)["curso_max_pct"] > 90.0
    ok.append(f"MC-4 previsto em {q_mc4:.1f} % de curso; observado > 90 %")

    # (h) a hidráulica dos três silos fecha entre si
    assert abs(_vazao(40) - U.FC_DESIGN_M3H) < 0.5, \
        "Cv 40 do fabricante não reproduz a vazão de projeto da engenharia"
    ft_sat = float(U.EXP_B["ft201"][U.EXP_B["q"].argmax()])
    assert abs(_vazao(22) - ft_sat) < 1.5, \
        f"Cv 22 do fabricante ({_vazao(22):.1f}) não reproduz FT-201 saturado ({ft_sat:.1f})"
    ok.append(f"hidráulica coerente: Cv 40 → {_vazao(40):.1f} m³/h (projeto), "
              f"Cv 22 → {_vazao(22):.1f} m³/h (= FT-201 observado {ft_sat:.1f})")

    # (i) o balanço térmico fecha
    assert abs((Q_CAMISA_KW + Q_PRODUTO_KW) - Q_REACAO_KW) < 1.0
    assert abs(UA_WK * DT_CAMISA_K / 1000 - Q_CAMISA_KW) < 1.0, \
        "UA·ΔT não reproduz o calor removido pela camisa"
    ok.append(f"balanço térmico fecha: {Q_REACAO_KW:.0f} kW gerados = "
              f"{Q_PRODUTO_KW:.0f} (produto) + {Q_CAMISA_KW:.0f} (camisa) = UA·ΔT")
    return ok


# =============================================================================
# MAIN
# =============================================================================
def main():
    silo_producao()
    silo_manutencao()
    silo_operacoes()
    silo_processo()
    silo_engenharia()
    silo_fabricante()
    silo_seguranca()
    silo_especialista()
    ground_truth()
    matriz_rastreabilidade()
    readme()
    montar_investigation_package()

    print(f"\n{len(GERADOS)} artefatos gerados:")
    por_pasta: dict[str, list[str]] = {}
    for g in GERADOS:
        por_pasta.setdefault(os.path.dirname(g) or ".", []).append(os.path.basename(g))
    for pasta in sorted(por_pasta):
        print(f"  {pasta + '/':22s} {', '.join(sorted(por_pasta[pasta]))}")

    print("\nVerificação de consistência documental:")
    for linha in verificar_documentacao():
        print(f"  ✓ {linha}")

    n_pdf = sum(len(fs) for _, _, fs in os.walk(os.path.join(RAIZ, "investigation_package")))
    print(f"\nPacote de investigação: {n_pdf} arquivos, sem ground truth.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
