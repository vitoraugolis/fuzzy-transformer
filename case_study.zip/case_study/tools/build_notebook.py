"""Gera o notebook a partir de u200_case.py (formato percent, estilo jupytext).

Fonte única da verdade: o módulo. O notebook é derivado, nunca editado à mão —
assim o notebook, os CSV e os documentos nunca divergem entre si (§16).

    python tools/build_notebook.py
"""
from __future__ import annotations

import os
import sys

import nbformat as nbf

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONTE = os.path.join(RAIZ, "tools", "u200_case.py")
DESTINO = os.path.join(RAIZ, "notebook", "projeto_case_industrial.ipynb")


def parse_percent(texto: str):
    """Quebra o arquivo em células nos marcadores `# %%` / `# %% [markdown]`."""
    celulas, tipo, buffer = [], None, []

    def fechar():
        if tipo is None:
            return
        corpo = "\n".join(buffer).strip("\n")
        if not corpo.strip():
            return
        if tipo == "markdown":
            corpo = "\n".join(l[2:] if l.startswith("# ") else l.lstrip("#")
                              for l in corpo.splitlines())
        celulas.append((tipo, corpo))

    for linha in texto.splitlines():
        if linha.startswith("# %%"):
            fechar()
            tipo = "markdown" if "[markdown]" in linha else "code"
            buffer = []
            continue
        buffer.append(linha)
    fechar()
    return celulas


def main() -> int:
    celulas = parse_percent(open(FONTE, encoding="utf-8").read())
    nb = nbf.v4.new_notebook()
    nb.cells = [nbf.v4.new_markdown_cell(c) if t == "markdown" else nbf.v4.new_code_cell(c)
                for t, c in celulas]
    nb.metadata = {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": sys.version.split()[0]},
    }
    os.makedirs(os.path.dirname(DESTINO), exist_ok=True)
    nbf.write(nb, DESTINO)
    md = sum(1 for t, _ in celulas if t == "markdown")
    print(f"{DESTINO}  —  {len(celulas)} células ({md} markdown, {len(celulas) - md} código)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
