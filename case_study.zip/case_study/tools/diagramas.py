"""PFD e P&ID da unidade U-200, desenhados a partir das tags do simulador.

O P&ID não é ilustração: cada instrumento desenhado aqui corresponde a uma
coluna do historian e cada equipamento a um termo do modelo. Se a tag não
existe no simulador, ela não entra no desenho (§11, §27).
"""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                        # noqa: E402
from matplotlib.patches import Circle, FancyArrowPatch, Rectangle      # noqa: E402

LINHA = dict(color="0.15", lw=1.3, solid_capstyle="round", zorder=2)
SINAL = dict(color="0.35", lw=0.9, ls=(0, (4, 3)), zorder=2)


def _eq(ax, x, y, w, h, tag, desc, cor="#eef2f6"):
    ax.add_patch(Rectangle((x, y), w, h, facecolor=cor, edgecolor="0.15",
                           lw=1.3, zorder=3))
    ax.text(x + w / 2, y + h + .10, tag, ha="center", va="bottom",
            fontsize=9, fontweight="bold", zorder=4)
    ax.text(x + w / 2, y + h / 2, desc, ha="center", va="center",
            fontsize=6.6, zorder=4, linespacing=1.35)


def _balao(ax, x, y, cima, baixo, r=.26, campo=False):
    ax.add_patch(Circle((x, y), r, facecolor="white", edgecolor="0.15", lw=1.1, zorder=5))
    if campo:
        ax.plot([x - r, x + r], [y, y], color="0.15", lw=.9, zorder=6)
    ax.text(x, y + (.09 if baixo else 0), cima, ha="center",
            va="center" if not baixo else "bottom", fontsize=6.2,
            fontweight="bold", zorder=6)
    if baixo:
        ax.text(x, y - .09, baixo, ha="center", va="top", fontsize=6.2, zorder=6)


def _linha(ax, pts, **kw):
    est = dict(LINHA); est.update(kw)
    xs, ys = zip(*pts)
    ax.plot(xs, ys, **est)


def _seta(ax, p0, p1, **kw):
    est = dict(LINHA); est.update(kw)
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=11,
                                 color=est["color"], lw=est["lw"], zorder=est.get("zorder", 2)))


def _valvula(ax, x, y, tag, tres_vias=False, s=.17):
    ax.plot([x - s, x + s], [y - s, y + s], color="0.15", lw=1.2, zorder=4)
    ax.plot([x - s, x + s], [y + s, y - s], color="0.15", lw=1.2, zorder=4)
    ax.plot([x - s, x - s], [y - s, y + s], color="0.15", lw=1.2, zorder=4)
    ax.plot([x + s, x + s], [y - s, y + s], color="0.15", lw=1.2, zorder=4)
    if tres_vias:
        ax.plot([x, x], [y - s, y - s - .18], color="0.15", lw=1.2, zorder=4)
    ax.plot([x, x], [y + s, y + s + .30], color="0.15", lw=1.0, zorder=4)
    ax.plot([x - .13, x + .13], [y + s + .30, y + s + .30], color="0.15", lw=2.2, zorder=4)
    if tag:
        ax.text(x + .30, y + .20, tag, fontsize=6.6, fontweight="bold", va="center", zorder=6)


def _base(titulo, numero, rev, w=15.2, h=8.4):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, 20); ax.set_ylim(0, 11)
    ax.axis("off")
    ax.add_patch(Rectangle((.25, .25), 19.5, 10.5, fill=False, ec="0.2", lw=1.4))
    ax.add_patch(Rectangle((13.4, .35), 6.25, 1.15, fill=False, ec="0.2", lw=1.0))
    ax.text(13.6, 1.28, "QUIMIVALE S.A. — Complexo Químico Vale do Aço",
            fontsize=6.6, va="top")
    ax.text(13.6, 1.00, titulo, fontsize=7.6, fontweight="bold", va="top")
    ax.text(13.6, .62, f"{numero}     Rev. {rev}     Escala: s/e     Unidade U-200",
            fontsize=6.2, va="top")
    return fig, ax


def pfd(destino):
    fig, ax = _base("FLUXOGRAMA DE PROCESSO — SEÇÃO DE REAÇÃO", "U-200-PFD-001", "4")
    ax.text(.6, 10.2, "SEÇÃO DE REAÇÃO — R-201", fontsize=11, fontweight="bold")

    _eq(ax, 1.0, 7.2, 1.7, 1.8, "TK-201", "Pulmão de\nalimentação")
    _eq(ax, 3.9, 7.4, 1.5, 1.4, "E-202", "Pré-aquecedor\nde carga")
    _eq(ax, 7.4, 5.6, 3.0, 3.4, "R-201", "REATOR CSTR ENCAMISADO\n12 m³ úteis · AISI 316L\n"
        "A → B exotérmica\n229 °C · 3,5 barg", cor="#e6eef7")
    _eq(ax, 12.6, 6.4, 1.9, 1.6, "TK-310", "Tancagem\nde produto")
    _eq(ax, 7.6, 2.2, 2.6, 1.5, "E-201", "Trocador\nloop temperado /\nágua de torre")
    _eq(ax, 12.4, 2.2, 2.2, 1.5, "TR-901", "Torre de\nresfriamento\n(3 células)")
    _eq(ax, 4.2, 2.4, 1.5, 1.1, "P-201", "Bomba de\ncirculação")

    _seta(ax, (2.7, 8.1), (3.9, 8.1)); _seta(ax, (5.4, 8.1), (7.4, 7.9))
    ax.text(6.0, 8.1, "carga\n9,0 m³/h", fontsize=6.2, ha="center", va="bottom")
    _seta(ax, (10.4, 7.6), (12.6, 7.6))
    ax.text(11.4, 7.75, "produto", fontsize=6.2, ha="center", va="bottom")

    # loop de água temperada
    _linha(ax, [(7.4, 6.2), (6.4, 6.2), (6.4, 2.95), (5.7, 2.95)], color="#1f6fb4")
    _linha(ax, [(4.2, 2.95), (3.4, 2.95), (3.4, 4.6), (11.2, 4.6), (11.2, 6.2), (10.4, 6.2)],
           color="#1f6fb4")
    _linha(ax, [(6.4, 4.15), (7.6, 4.15), (7.6, 3.7)], color="#1f6fb4")
    _linha(ax, [(10.2, 2.95), (11.0, 2.95), (11.0, 4.6)], color="#1f6fb4")
    _valvula(ax, 6.4, 4.15, "FV-201", tres_vias=True)
    ax.text(3.5, 4.75, "LOOP DE ÁGUA TEMPERADA — 60 m³/h", fontsize=6.4,
            color="#1f6fb4", fontweight="bold")

    # água de torre
    _linha(ax, [(10.2, 2.55), (12.4, 2.55)], color="#3a9a55")
    _linha(ax, [(12.4, 3.35), (11.6, 3.35), (11.6, 3.35)], color="#3a9a55")
    _linha(ax, [(11.6, 3.35), (11.6, 3.1), (10.2, 3.1)], color="#3a9a55")
    ax.text(10.9, 2.30, "água de torre", fontsize=6.2, ha="center", color="#3a9a55")

    for x, y, txt in [(1.85, 6.9, "① 133,5 °C"), (8.9, 5.35, "② 229,2 °C"),
                      (6.4, 3.6, "③ 88,8 – 133,5 °C"), (13.5, 1.95, "④ 28 – 33 °C")]:
        ax.text(x, y, txt, fontsize=6.2, ha="center", style="italic", color="0.3")

    fig.tight_layout(); fig.savefig(destino, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return destino


def pid(destino):
    fig, ax = _base("FLUXOGRAMA DE ENGENHARIA — R-201 E CIRCUITO DE RESFRIAMENTO",
                    "U-200-PID-201", "6")
    ax.text(.6, 10.2, "P&ID — REATOR R-201 E CIRCUITO DE ÁGUA TEMPERADA",
            fontsize=11, fontweight="bold")

    _eq(ax, 6.9, 5.3, 3.2, 3.5, "R-201", "REATOR CSTR ENCAMISADO\n12 m³ úteis\n"
        "PMTA 6,0 barg\nAISI 316L", cor="#e6eef7")
    ax.add_patch(Rectangle((6.62, 5.55), .28, 3.0, facecolor="#cfe0f0", ec="0.15",
                           lw=1.0, zorder=3))
    ax.add_patch(Rectangle((10.1, 5.55), .28, 3.0, facecolor="#cfe0f0", ec="0.15",
                           lw=1.0, zorder=3))
    ax.text(6.76, 5.35, "camisa", fontsize=5.6, ha="center", rotation=90, va="top")
    _eq(ax, 3.3, 7.6, 1.4, 1.2, "E-202", "Pré-aquecedor")
    _eq(ax, 7.2, 1.9, 2.5, 1.4, "E-201", "Trocador\nloop / torre")
    _eq(ax, 3.9, 2.1, 1.4, 1.0, "P-201", "P-201")

    # --- carga -------------------------------------------------------------
    _seta(ax, (1.0, 8.2), (3.3, 8.2)); _seta(ax, (4.7, 8.2), (6.9, 8.2))
    _balao(ax, 2.3, 9.1, "FT", "204", campo=True); _linha(ax, [(2.3, 8.84), (2.3, 8.2)], **SINAL)
    _balao(ax, 5.7, 9.1, "TT", "204", campo=True); _linha(ax, [(5.7, 8.84), (5.7, 8.2)], **SINAL)
    ax.text(1.1, 8.35, "carga de TK-201", fontsize=6.2)

    # --- produto e analisador ----------------------------------------------
    _seta(ax, (10.38, 6.1), (12.6, 6.1))
    ax.text(11.5, 6.25, "para TK-310", fontsize=6.2, ha="center")
    _balao(ax, 12.2, 5.5, "AT", "205", campo=True); _linha(ax, [(12.2, 5.76), (12.2, 6.1)], **SINAL)
    _balao(ax, 13.5, 5.5, "QAH", "205"); _linha(ax, [(12.46, 5.5), (13.24, 5.5)], **SINAL)

    # --- malha de temperatura ----------------------------------------------
    _balao(ax, 8.5, 9.6, "TT", "201", campo=True)
    _linha(ax, [(8.5, 8.8), (8.5, 9.34)], **SINAL)
    _balao(ax, 10.0, 9.6, "TIC", "201")
    _linha(ax, [(8.76, 9.6), (9.74, 9.6)], **SINAL)
    _balao(ax, 11.4, 9.6, "TAH", "201"); _balao(ax, 12.7, 9.6, "TAL", "201")
    _linha(ax, [(10.26, 9.6), (11.14, 9.6)], **SINAL)
    _linha(ax, [(11.66, 9.6), (12.44, 9.6)], **SINAL)
    _balao(ax, 14.2, 9.6, "TAHH", "201")
    _balao(ax, 15.5, 9.6, "SIS", "201")
    _linha(ax, [(12.96, 9.6), (13.94, 9.6)], **SINAL)
    _linha(ax, [(14.46, 9.6), (15.24, 9.6)], **SINAL)
    ax.text(15.5, 8.9, "corta carga\ne abre FV-201", fontsize=5.8, ha="center", va="top")
    _linha(ax, [(15.5, 9.34), (15.5, 8.95)], **SINAL)

    # --- loop de água temperada --------------------------------------------
    az = dict(color="#1f6fb4", lw=1.4, zorder=2)
    _linha(ax, [(6.62, 5.55), (5.6, 5.55), (5.6, 2.6), (5.3, 2.6)], **az)   # retorno da camisa
    _linha(ax, [(3.9, 2.6), (3.0, 2.6), (3.0, 4.35), (5.05, 4.35)], **az)   # descarga da bomba
    _linha(ax, [(5.55, 4.35), (10.38, 4.35), (10.38, 5.55)], **az)          # para a camisa
    _linha(ax, [(5.3, 4.18), (5.3, 3.6), (7.2, 3.6), (7.2, 3.3)], **az)     # desvio p/ E-201
    _linha(ax, [(9.7, 2.6), (10.5, 2.6), (10.5, 4.35)], **az)               # retorno de E-201
    _valvula(ax, 5.3, 4.35, "FV-201", tres_vias=True)
    ax.text(3.05, 4.55, "LOOP DE ÁGUA TEMPERADA", fontsize=6.2, color="#1f6fb4",
            fontweight="bold")

    _balao(ax, 5.3, 6.0, "ZT", "201", campo=True)
    _linha(ax, [(5.3, 5.74), (5.3, 4.85)], **SINAL)
    _balao(ax, 4.1, 6.0, "ZAH", "201"); _balao(ax, 2.9, 6.0, "ZAHH", "201")
    _linha(ax, [(5.04, 6.0), (4.36, 6.0)], **SINAL)
    _linha(ax, [(3.84, 6.0), (3.16, 6.0)], **SINAL)
    _linha(ax, [(9.86, 9.34), (9.86, 7.0), (2.2, 7.0), (2.2, 4.35), (5.05, 4.35)], **SINAL)
    ax.text(2.35, 7.15, "saída TIC-201  4–20 mA", fontsize=5.8, color="0.35")

    _balao(ax, 6.5, 3.05, "FT", "201", campo=True)
    _linha(ax, [(6.5, 3.31), (6.5, 3.6)], **SINAL)
    _balao(ax, 11.3, 4.9, "TT", "202", campo=True)
    _linha(ax, [(11.04, 4.9), (10.38, 4.9)], **SINAL)
    _balao(ax, 10.9, 3.4, "TT", "207", campo=True)
    _linha(ax, [(10.9, 3.14), (10.9, 2.6)], **SINAL)

    # --- água de torre ------------------------------------------------------
    vd = dict(color="#3a9a55", lw=1.4, zorder=2)
    _linha(ax, [(7.2, 2.25), (5.9, 2.25), (5.9, 1.05), (13.1, 1.05)], **vd)
    _linha(ax, [(9.7, 2.25), (11.2, 2.25), (11.2, 1.75), (13.1, 1.75)], **vd)
    ax.text(11.9, 0.78, "para / de TR-901", fontsize=6.2, color="#3a9a55", va="center")
    _balao(ax, 6.6, 0.62, "TT", "203", campo=True)
    _linha(ax, [(6.6, 0.88), (6.6, 1.05)], **SINAL)

    # --- segurança ----------------------------------------------------------
    _linha(ax, [(9.0, 8.8), (9.0, 9.6)], color="0.15", lw=1.2)
    _valvula(ax, 9.0, 9.2, "")
    ax.text(9.25, 9.3, "PSV-201\n6,0 barg", fontsize=6.0, va="center")

    ax.text(.55, 3.4, "LEGENDA", fontsize=7, fontweight="bold")  # canto inferior esquerdo
    for i, (txt, cor) in enumerate([("processo", "0.15"), ("água temperada", "#1f6fb4"),
                                    ("água de torre", "#3a9a55")]):
        ax.plot([.55, 1.35], [3.05 - .3 * i, 3.05 - .3 * i], color=cor, lw=1.4)
        ax.text(1.45, 3.05 - .3 * i, txt, fontsize=6.2, va="center")
    ax.plot([.55, 1.35], [2.15, 2.15], **SINAL)
    ax.text(1.45, 2.15, "sinal elétrico", fontsize=6.2, va="center")

    fig.tight_layout(); fig.savefig(destino, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return destino


def curva_valvula(destino, cv_projeto=40, cv_substituto=22, rangeability=30):
    """Curva instalada dos dois trims — figura do datasheet do fabricante."""
    import numpy as np
    q = np.linspace(0, 100, 201)
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    for cv, rot, cor, ls in [(cv_projeto, "Trim NV4000-40-STD (padrão, Cv 40)", "#1f6fb4", "-"),
                             (cv_substituto, "Trim NV4000-22-AC (anticavitação, Cv 22)",
                              "#b4451f", "--")]:
        ax.plot(q, cv * q / 100.0, ls, color=cor, lw=1.8, label=rot)
    ax.axhline(cv_projeto, color="#1f6fb4", lw=.7, ls=":")
    ax.axhline(cv_substituto, color="#b4451f", lw=.7, ls=":")
    ax.annotate("", xy=(100, cv_projeto), xytext=(100, cv_substituto),
                arrowprops=dict(arrowstyle="<->", color="0.3", lw=1.0))
    ax.text(96, (cv_projeto + cv_substituto) / 2,
            f"−{100 * (1 - cv_substituto / cv_projeto):.0f} % de\ncapacidade",
            fontsize=8, ha="right", va="center", color="0.25")
    ax.set_xlabel("Curso da haste [%]"); ax.set_ylabel("Cv")
    ax.set_title("NORDVALVE série 4000 DN 80 ANSI 300 — Cv instalado por conjunto de trim",
                 fontsize=9)
    ax.set_xlim(0, 100); ax.set_ylim(0, 46)
    ax.grid(alpha=.3); ax.legend(fontsize=8, loc="upper left")
    fig.tight_layout(); fig.savefig(destino, dpi=150)
    plt.close(fig)
    return destino


def gerar_todos(pasta):
    os.makedirs(pasta, exist_ok=True)
    return {
        "pfd": pfd(os.path.join(pasta, "pfd_u200.png")),
        "pid": pid(os.path.join(pasta, "pid_u200.png")),
        "cv": curva_valvula(os.path.join(pasta, "curva_cv_fv201.png")),
    }


if __name__ == "__main__":
    raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for k, v in gerar_todos(os.path.join(raiz, "figures")).items():
        print(f"  {k}: {v}")
