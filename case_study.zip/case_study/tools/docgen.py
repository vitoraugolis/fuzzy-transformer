"""Composição de documentos industriais em PDF.

Não é um gerador de relatórios bonitos: é um molde de documento controlado —
bloco de identificação, revisão, responsáveis, status, tabelas com grade e
rodapé com número de documento. Todo silo usa o mesmo molde, com o cabeçalho
mudando apenas de tipo (PO, WO, HAZOP, datasheet...).
"""
from __future__ import annotations

import os
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether, PageBreak,
                                PageTemplate, Paragraph, Spacer, Table, TableStyle)

EMPRESA = "QUIMIVALE S.A."
COMPLEXO = "Complexo Químico Vale do Aço — Planta de Resinas"

CINZA = colors.HexColor("#4a4a4a")
CINZA_CLARO = colors.HexColor("#e8e8e8")
CINZA_LINHA = colors.HexColor("#9a9a9a")
DESTAQUE = colors.HexColor("#f4f1e8")

_ss = getSampleStyleSheet()
ST = {
    "corpo": ParagraphStyle("corpo", parent=_ss["BodyText"], fontName="Helvetica",
                            fontSize=8.6, leading=11.6, alignment=TA_JUSTIFY,
                            spaceAfter=4),
    "corpo_c": ParagraphStyle("corpo_c", parent=_ss["BodyText"], fontName="Helvetica",
                              fontSize=8.6, leading=11.6, alignment=TA_CENTER),
    "h1": ParagraphStyle("h1", parent=_ss["Heading1"], fontName="Helvetica-Bold",
                         fontSize=10.5, leading=13, textColor=CINZA,
                         spaceBefore=9, spaceAfter=4),
    "h2": ParagraphStyle("h2", parent=_ss["Heading2"], fontName="Helvetica-Bold",
                         fontSize=9.2, leading=12, textColor=CINZA,
                         spaceBefore=6, spaceAfter=3),
    "cel": ParagraphStyle("cel", fontName="Helvetica", fontSize=7.4, leading=9.2),
    "cel_b": ParagraphStyle("cel_b", fontName="Helvetica-Bold", fontSize=7.4, leading=9.2),
    "mono": ParagraphStyle("mono", fontName="Courier", fontSize=7.4, leading=9.4),
    "nota": ParagraphStyle("nota", parent=_ss["BodyText"], fontName="Helvetica-Oblique",
                           fontSize=7.8, leading=10, textColor=CINZA),
}


class _Doc(BaseDocTemplate):
    def __init__(self, caminho, cab, **kw):
        super().__init__(caminho, pagesize=A4,
                         leftMargin=17 * mm, rightMargin=15 * mm,
                         topMargin=32 * mm, bottomMargin=17 * mm, **kw)
        self.cab = cab
        frame = Frame(self.leftMargin, self.bottomMargin,
                      self.width, self.height, id="corpo")
        self.addPageTemplates([PageTemplate(id="pad", frames=[frame],
                                            onPage=self._decorar)])

    def _decorar(self, canvas, doc):
        c, L = canvas, doc.leftMargin
        W = doc.width
        topo = A4[1] - 12 * mm
        c.saveState()
        c.setFont("Helvetica-Bold", 11)
        c.drawString(L, topo - 3, EMPRESA)
        c.setFont("Helvetica", 6.8)
        c.drawString(L, topo - 11, COMPLEXO)
        c.setFont("Helvetica-Bold", 9.4)
        c.drawRightString(L + W, topo - 3, self.cab["titulo"][:74])
        c.setFont("Helvetica", 7)
        c.drawRightString(L + W, topo - 11,
                          f"{self.cab['numero']}   Rev. {self.cab['rev']}   {self.cab['data']}")
        c.setStrokeColor(CINZA_LINHA)
        c.setLineWidth(0.8)
        c.line(L, topo - 15, L + W, topo - 15)
        c.setLineWidth(0.4)
        c.line(L, doc.bottomMargin - 5, L + W, doc.bottomMargin - 5)
        c.setFont("Helvetica", 6.4)
        c.setFillColor(CINZA)
        c.drawString(L, doc.bottomMargin - 12,
                     f"{self.cab['numero']} · Rev. {self.cab['rev']} · "
                     f"{self.cab.get('classificacao', 'USO INTERNO')}")
        c.drawRightString(L + W, doc.bottomMargin - 12, f"Página {doc.page}")
        c.restoreState()


# Ponto decimal -> vírgula, como manda a norma em português. Preserva números
# de seção (§ 5.3), identificadores (DB-4.1, NV4000-22-AC) e datas.
_DECIMAL = re.compile(r"(?<![\w.\-])(?<!§ )(\d+)\.(\d+)(?![\w\-])")


def pt(texto):
    """Normaliza o separador decimal de um texto de documento."""
    return _DECIMAL.sub(r"\1,\2", str(texto))


def P(texto, estilo="corpo"):
    return Paragraph(pt(texto), ST[estilo])


def tabela(dados, larguras=None, cabecalho=True, alinhamentos=None,
           destaque_linhas=(), tamanho=7.4):
    """Tabela com grade. `dados` é lista de listas de str (ou Flowable)."""
    corpo = [[c if hasattr(c, "wrap") else Paragraph(
        pt(c), ST["cel_b"] if (cabecalho and i == 0) else ST["cel"])
        for c in linha] for i, linha in enumerate(dados)]
    t = Table(corpo, colWidths=larguras, repeatRows=1 if cabecalho else 0, hAlign="LEFT")
    estilo = [
        ("GRID", (0, 0), (-1, -1), 0.35, CINZA_LINHA),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 2.2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2),
        ("FONTSIZE", (0, 0), (-1, -1), tamanho),
    ]
    if cabecalho:
        estilo += [("BACKGROUND", (0, 0), (-1, 0), CINZA_CLARO)]
    for i in destaque_linhas:
        estilo.append(("BACKGROUND", (0, i), (-1, i), DESTAQUE))
    if alinhamentos:
        for col, al in alinhamentos.items():
            estilo.append(("ALIGN", (col, 0), (col, -1), al))
    t.setStyle(TableStyle(estilo))
    return t


def bloco_identificacao(campos, colunas=3):
    """Bloco de campos do documento (Nº / Rev / Data / Autor / Status ...)."""
    itens = list(campos.items())
    linhas = []
    for i in range(0, len(itens), colunas):
        fatia = itens[i:i + colunas]
        linha = []
        for chave, valor in fatia:
            linha += [Paragraph(f"<b>{chave}</b>", ST["cel"]), Paragraph(pt(valor), ST["cel"])]
        while len(linha) < colunas * 2:
            linha += ["", ""]
        linhas.append(linha)
    larg = []
    for _ in range(colunas):
        larg += [26 * mm, 33 * mm]
    t = Table(linhas, colWidths=larg[:colunas * 2], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.35, CINZA_LINHA),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, 0), (-1, -1), colors.white),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))
    return t


def caixa(texto, titulo=None):
    """Caixa de observação / advertência."""
    conteudo = []
    if titulo:
        conteudo.append([Paragraph(f"<b>{titulo}</b>", ST["cel_b"])])
    conteudo.append([Paragraph(pt(texto), ST["cel"])])
    t = Table(conteudo, colWidths=[168 * mm], hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.6, CINZA_LINHA),
        ("BACKGROUND", (0, 0), (-1, -1), DESTAQUE),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def assinaturas(papeis):
    """Bloco de elaboração / verificação / aprovação."""
    cab = [p for p, _, _ in papeis]
    nomes = [n for _, n, _ in papeis]
    datas = [d for _, _, d in papeis]
    larg = [168 * mm / len(papeis)] * len(papeis)
    t = Table([cab, nomes, datas], colWidths=larg, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.35, CINZA_LINHA),
        ("BACKGROUND", (0, 0), (-1, 0), CINZA_CLARO),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.2),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 1), (-1, 1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return t


def gerar(caminho, cabecalho, conteudo):
    """Escreve o PDF. `cabecalho` = {titulo, numero, rev, data, classificacao}."""
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    _Doc(caminho, cabecalho).build(list(conteudo))
    return caminho


def figura(caminho, largura_mm=168.0, legenda=None):
    """Insere uma figura preservando a proporcao, com legenda opcional."""
    from PIL import Image as _PILImage
    with _PILImage.open(caminho) as im:
        prop = im.height / im.width
    itens = [Image(caminho, width=largura_mm * mm, height=largura_mm * prop * mm)]
    if legenda:
        itens += [Spacer(1, 1.5 * mm), Paragraph(legenda, ST["nota"])]
    return itens


__all__ = ["P", "pt", "ST", "tabela", "bloco_identificacao", "caixa", "assinaturas",
           "figura", "gerar", "Spacer", "PageBreak", "KeepTogether", "mm",
           "EMPRESA", "COMPLEXO"]
