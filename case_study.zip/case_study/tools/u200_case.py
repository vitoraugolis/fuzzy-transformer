# %% [markdown]
# # Caso Industrial U-200 — CSTR de Resinas Poliéster
#
# **Documento:** benchmark de avaliação de estratégias de controle
# **Unidade:** U-200 — Seção de Reação, Reator R-201
# **Revisão:** 1.0 · 2026-08-25
#
# Este notebook contém (i) o modelo de processo do benchmark de Lee, Jin & So
# (2025), *Algorithms* 18(7), 442, em malha aberta e em malha fechada, e (ii)
# um **caso industrial multissilo** construído sobre esse mesmo modelo.
#
# O caso não foi construído para "fazer o PID falhar". O PID é tecnicamente
# razoável e continua cumprindo sua função local. O que o caso constrói é a
# diferença entre **controlar a variável** e **operar corretamente a unidade**:
# ao longo da campanha a temperatura permanece próxima do SP enquanto a unidade
# consome silenciosamente toda a sua margem de resfriamento.
#
# > **A causa raiz não está escrita em nenhum documento do pacote de
# > investigação.** Ela é reconstruível cruzando produção, manutenção,
# > fabricante, historian, turno e projeto. O `internal/ground_truth_case.md`
# > é de uso exclusivo do pesquisador.

# %%
"""

Reacao exotermica de 1a ordem A -> B em reator encamisado. O artigo despreza a
dinamica da camisa (Sec. 2.1) e usa a temperatura da camisa como entrada de
controle. Forma adimensional (Eq. 3-4 do artigo):

    x1' = -x1 + Da (1 - x1) exp[x2 / (1 + x2/gamma)] + d1
    x2' = -(1 + beta) x2 + H Da (1 - x1) exp[x2 / (1 + x2/gamma)] + beta u + d2
    y   = x2

x1  conversao adimensional            (CAf - CA) / CAf
x2  temperatura do reator (PV)        gamma (T - Tf) / Tf
u   temperatura da camisa (entrada)   gamma (Tc - Tf) / Tf
t   tempo adimensional                tau F / V
d1  disturbio de concentracao de alimentacao
d2  disturbio de temperatura de alimentacao

A planta nao conhece o controlador: `step` recebe u ja aplicado. O mapa
valvula -> u vive na classe `CoolingValve` (derivado da Eq. 2 do artigo).
"""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta

import numpy as np

# Equilibrios publicados no artigo (Sec. 2.2) para u = 0 e parametros nominais.
# xB e instavel; xA e xC sao estaveis. Usados como teste de aceitacao do modelo.
PUBLISHED_EQUILIBRIA = {
    "xA": (0.144, 0.886),
    "xB": (0.447, 2.752),
    "xC": (0.765, 4.705),
}


@dataclass(frozen=True)
class CSTRParams:
    """Parametros adimensionais. Valores nominais da Sec. 4.1 do artigo."""

    Da: float = 0.072  # numero de Damkohler
    gamma: float = 20.0  # energia de ativacao adimensional
    H: float = 8.0  # calor de reacao adimensional
    beta: float = 0.3  # taxa de resfriamento adimensional

    def perturbed(self, factor: float) -> "CSTRParams":
        """Variacao percentual de Da, H, beta (robustez, Sec. 4.4: +/-20%).

        gamma nao e perturbado: o artigo perturba apenas Da, H e beta.
        """
        return replace(self, Da=self.Da * factor, H=self.H * factor, beta=self.beta * factor)


def reaction_rate(x1: float, x2: float, p: CSTRParams) -> float:
    """Termo de Arrhenius adimensional: Da (1 - x1) exp[x2 / (1 + x2/gamma)]."""
    return p.Da * (1.0 - x1) * np.exp(x2 / (1.0 + x2 / p.gamma))


def derivatives(x: np.ndarray, u: float, d: np.ndarray, p: CSTRParams) -> np.ndarray:
    """Lado direito das Eq. 4a-4b. x = [x1, x2], d = [d1, d2]."""
    x1, x2 = x
    r = reaction_rate(x1, x2, p)
    return np.array(
        [
            -x1 + r + d[0],
            -(1.0 + p.beta) * x2 + p.H * r + p.beta * u + d[1],
        ]
    )


class Process_CSTR:
    """Planta. Integracao RK4 com passo fixo (o loop de controle e discreto)."""

    def __init__(self, params: CSTRParams | None = None, x0: tuple[float, float] = PUBLISHED_EQUILIBRIA["xA"]):
        self.params = params or CSTRParams()
        self.x0 = np.array(x0, dtype=float)
        self.reset()

    def reset(self, x0: tuple[float, float] | None = None) -> np.ndarray:
        self.x = np.array(x0 if x0 is not None else self.x0, dtype=float)
        self.t = 0.0
        return self.x.copy()

    def step(self, u: float, dt: float, d: np.ndarray | tuple[float, float] = (0.0, 0.0)) -> np.ndarray:
        """Avanca dt no tempo adimensional com u e d segurados (zero-order hold)."""
        d = np.asarray(d, dtype=float)
        f = lambda x: derivatives(x, u, d, self.params)  # noqa: E731
        k1 = f(self.x)
        k2 = f(self.x + 0.5 * dt * k1)
        k3 = f(self.x + 0.5 * dt * k2)
        k4 = f(self.x + dt * k3)
        self.x = self.x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        self.t += dt
        return self.x.copy()

    @property
    def y(self) -> float:
        """Saida medida na planta (temperatura do reator), Eq. 4c. Sem sensor."""
        return float(self.x[1])


def steady_state_input(x2_target: float, p: CSTRParams | None = None) -> tuple[float, float]:
    """u e x1 de regime permanente para uma temperatura x2 desejada.

    Em regime, x1' = 0 => x1 = r / (1 + ...) resolvido em forma fechada porque
    r e linear em (1 - x1). Depois u sai de x2' = 0. Usado para inicializacao
    de episodios e para calibrar a faixa da valvula.
    """
    p = p or CSTRParams()
    a = p.Da * np.exp(x2_target / (1.0 + x2_target / p.gamma))
    x1 = a / (1.0 + a)  # de -x1 + a(1 - x1) = 0
    r = a * (1.0 - x1)
    u = ((1.0 + p.beta) * x2_target - p.H * r) / p.beta
    return float(u), float(x1)


# %% [markdown]
# ## Verificação do modelo contra os equilíbrios publicados
#
# Antes de qualquer coisa: se o modelo não reproduz os três equilíbrios da
# Sec. 2.2 do artigo, nada construído em cima dele vale. Este é o primeiro
# teste de aceitação (§28 — Modelo).

# %%
def refine_equilibrium(x_seed, p: CSTRParams | None = None, iters: int = 60):
    """Newton com jacobiano numerico sobre x' = 0, partindo do valor publicado."""
    p = p or CSTRParams()
    x = np.array(x_seed, dtype=float)
    f = lambda v: derivatives(v, 0.0, np.array([0.0, 0.0]), p)  # noqa: E731
    for _ in range(iters):
        fx = f(x)
        J = np.zeros((2, 2))
        for j in range(2):
            dx = np.zeros(2)
            dx[j] = 1e-7
            J[:, j] = (f(x + dx) - f(x - dx)) / 2e-7
        passo = np.linalg.solve(J, fx)
        x = x - passo
        if np.max(np.abs(passo)) < 1e-14:
            break
    return x


def check_published_equilibria(tol_arredondamento: float = 1e-3) -> dict[str, dict]:
    """Teste de aceitacao do modelo (§28).

    Os valores publicados vem arredondados a 3 casas decimais, entao o residuo
    bruto de x' calculado NELES nao e zero -- em xC o arredondamento de x1 e
    amplificado por H = 8. O teste correto nao e "o residuo e pequeno", e sim:
    refinar cada equilibrio por Newton e verificar que ele cai dentro do
    arredondamento do valor publicado.
    """
    p = CSTRParams()
    out = {}
    for nome, x_eq in PUBLISHED_EQUILIBRIA.items():
        bruto = float(np.max(np.abs(derivatives(np.array(x_eq, dtype=float), 0.0,
                                                np.array([0.0, 0.0]), p))))
        x_ref = refine_equilibrium(x_eq, p)
        desvio = float(np.max(np.abs(x_ref - np.array(x_eq, dtype=float))))
        assert desvio <= tol_arredondamento + 1e-9, (
            f"{nome}: equilibrio refinado {x_ref} afasta-se {desvio:.2e} "
            f"do publicado {x_eq}")
        out[nome] = {"residuo_bruto": bruto, "refinado": x_ref, "desvio": desvio}
    return out


print("Equilibrios publicados x refinados por Newton (u=0, d=0):")
for nome, r in check_published_equilibria().items():
    x1e, x2e = PUBLISHED_EQUILIBRIA[nome]
    print(f"  {nome}: publicado ({x1e:.3f}, {x2e:.3f})  refinado "
          f"({r['refinado'][0]:.5f}, {r['refinado'][1]:.5f})  "
          f"residuo_no_publicado={r['residuo_bruto']:.2e}  desvio={r['desvio']:.2e}")


# %% [markdown]
# ## Rodando o processo em malha aberta

# %%
# Malha aberta: degrau unitario em u, simulando a resposta do sistema.

import matplotlib.pyplot as plt

FIGDIR = os.path.join(os.path.dirname(os.path.abspath("__file__")), "figures")


def _figpath(nome: str) -> str:
    """Resolve a pasta de figuras funcionando tanto no notebook quanto no script."""
    for base in ("figures", "../figures", "case_study/figures"):
        if os.path.isdir(base):
            return os.path.join(base, nome)
    os.makedirs("figures", exist_ok=True)
    return os.path.join("figures", nome)


def simulate_step_response():
    params = CSTRParams()
    cstr = Process_CSTR(params=params, x0=PUBLISHED_EQUILIBRIA["xA"])

    dt = 0.01
    t_final = 100.0
    n_steps = int(t_final / dt)

    time = np.zeros(n_steps + 1)
    x1_hist = np.zeros(n_steps + 1)
    x2_hist = np.zeros(n_steps + 1)
    u_hist = np.zeros(n_steps + 1)

    time[0] = 0.0
    x1_hist[0] = cstr.x[0]
    x2_hist[0] = cstr.x[1]
    u_hist[0] = 0.0

    u_step = 1.0

    for i in range(1, n_steps + 1):
        u = u_step if cstr.t >= 0 else 0.0
        cstr.step(u, dt)
        time[i] = cstr.t
        x1_hist[i] = cstr.x[0]
        x2_hist[i] = cstr.x[1]
        u_hist[i] = u

    return time, x1_hist, x2_hist, u_hist


def plot_results_ma(time, x1, x2, u):
    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)

    axes[0].plot(time, u, "k-", linewidth=1.5)
    axes[0].set_ylabel("u (entrada)")
    axes[0].set_title("CSTR — Resposta ao Degrau Unitário (Malha Aberta)")
    axes[0].grid(True, alpha=0.3)
    axes[0].axvline(x=0, color="r", linestyle="--", alpha=0.5, label="Instante do degrau")
    axes[0].legend()

    axes[1].plot(time, x1, "b-", linewidth=1.5)
    axes[1].set_ylabel("x1 (conversão)")
    axes[1].grid(True, alpha=0.3)

    axes[2].plot(time, x2, "r-", linewidth=1.5)
    axes[2].set_ylabel("x2 (temperatura)")
    axes[2].set_xlabel("Tempo adimensional (t)")
    axes[2].grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig(_figpath("00_malha_aberta_degrau.png"), dpi=130)


_t, _x1, _x2, _u = simulate_step_response()
plot_results_ma(_t, _x1, _x2, _u)
print(f"Estado inicial (xA): x1={_x1[0]:.4f}, x2={_x2[0]:.4f}")
print(f"Estado final:        x1={_x1[-1]:.4f}, x2={_x2[-1]:.4f}")


# %% [markdown]
# ## Sensor, Atuador e Controlador PID
#
# Blocos preservados do modelo-base. A interface pública do controlador
# (`reset` / `update`) é o que permite trocar o PID por qualquer outra
# estratégia sem tocar em nenhum outro bloco da malha.

# %%
class Sensor:
    """Bloco MEDIÇÃO. Primeira ordem + ruído de medição.

    Entrada : valor verdadeiro da variável de processo
    Saída   : PV — o que o controlador enxerga
    """
    def __init__(self, PV0, tau=1.0, noise_std=0.0):
        self.PV, self.tau, self.noise_std = PV0, tau, noise_std

    def update(self, C_B, dt, rng):
        self.PV += dt * (C_B - self.PV) / self.tau      # atraso do sensor
        return self.PV + rng.normal(0.0, self.noise_std)  # ruído sobreposto à leitura


class Atuador:
    """Bloco ATUADOR (válvula). Primeira ordem + saturação.

    Entrada : q_cmd — o que o controlador PEDE
    Saída   : q     — o que a válvula ENTREGA
    """
    def __init__(self, q0, q_min, q_max, tau=0.5):
        self.q, self.q_min, self.q_max, self.tau = q0, q_min, q_max, tau

    def update(self, q_cmd, dt):
        q_alvo = np.clip(q_cmd, self.q_min, self.q_max)   # saturação física
        self.q += dt * (q_alvo - self.q) / self.tau        # dinâmica da válvula
        return np.clip(self.q, self.q_min, self.q_max)


class ControladorPID:
    """Bloco CONTROLADOR. Forma paralela, parametrizada por Kp, Ti, Td.

        q_cmd = q_bias + Kp·e + Ki·∫e·dt + Kd·de/dt ,   e = SP − PV
        Ki = Kp/Ti        Kd = Kp·Td

    Interface pública: reset(q_bias) e update(SP, PV, dt).
    Qualquer outro controlador (Fuzzy, MPC, ...) que respeite esta interface
    entra na malha sem alterar nenhum outro bloco.

    O anti-windup é agnóstico ao sinal de Kp: as duas condições de `recupera`
    testam saturação e sentido do erro, não o sinal do ganho. Isso importa
    aqui porque a MV do caso industrial é a abertura da válvula de
    resfriamento, e nessa MV o ganho é negativo (mais quente → abre mais).
    """
    def __init__(self, Kp, Ti, Td, q_min, q_max, antiwindup=True, nome='PID'):
        self.nome = nome
        self.Kp, self.Ti, self.Td = Kp, Ti, Td
        self.Ki = Kp / Ti if Ti not in (0, None, np.inf) else 0.0
        self.Kd = Kp * Td
        self.q_min, self.q_max = q_min, q_max
        self.antiwindup = antiwindup
        self.reset(q_bias=0.0)

    def reset(self, q_bias):
        """Reinicia o controlador no ponto de operação do experimento."""
        self.q_bias = q_bias
        self.integral = 0.0
        self.erro_anterior = 0.0

    def update(self, SP, PV, dt):
        erro     = SP - PV
        derivada = (erro - self.erro_anterior) / dt
        integral_teste = self.integral + erro * dt

        q_bruto = self.q_bias + self.Kp*erro + self.Ki*integral_teste + self.Kd*derivada
        q_cmd   = np.clip(q_bruto, self.q_min, self.q_max)

        # Anti-windup: só acumula a integral se ela não empurrar uma válvula já saturada.
        recupera = ((q_bruto < self.q_min and erro < 0) or
                    (q_bruto > self.q_max and erro > 0))
        if (not self.antiwindup) or np.isclose(q_bruto, q_cmd) or recupera:
            self.integral = integral_teste
            q_bruto = self.q_bias + self.Kp*erro + self.Ki*self.integral + self.Kd*derivada
            q_cmd   = np.clip(q_bruto, self.q_min, self.q_max)

        self.erro_anterior = erro
        return erro, q_cmd, q_bruto

    def __repr__(self):
        return (f'{self.nome}(Kp={self.Kp:+.3f}, Ti={self.Ti:g}, Td={self.Td:g} '
                f'→ Ki={self.Ki:+.4f}, Kd={self.Kd:+.3f})')


# %% [markdown]
# ## Rodando a Simulação em Malha Fechada (benchmark do artigo)
#
# Esta seção reproduz o benchmark original, em que a MV é a própria
# temperatura da camisa `u`. É a referência de que o modelo e a malha estão
# corretos. O caso industrial, mais adiante, troca a MV pela **abertura da
# válvula de resfriamento**, que é o que existe fisicamente na unidade.

# %%
# ============================================================
# SIMULAÇÃO EM MALHA FECHADA — benchmark (MV = u)
# ============================================================
#   PV = x2 = temperatura adimensional do reator
#   SP = referência de x2
#   q  = variável manipulada aplicada à planta, identificada aqui com u
#
# SP -> PID -> Atuador -> CSTR -> Sensor -> PV -> PID
#
# O modelo do CSTR permanece "cego" ao controlador: ele só recebe u e d.

def simulate_closed_loop(
    sp_function,
    disturbance_function=lambda t: (0.0, 0.0),
    x0=PUBLISHED_EQUILIBRIA["xA"],
    q_bias=None,
    Kp=1.0,
    Ti=5.0,
    Td=0.10,
    q_min=-2.0,
    q_max=2.0,
    tau_sensor=0.5,
    tau_valve=0.5,
    noise_std=0.0,
    dt=0.02,
    t_final=100.0,
    seed=1234,
):
    """Simula a planta completa em malha fechada."""

    params = CSTRParams()
    plant = Process_CSTR(params=params, x0=x0)

    if q_bias is None:
        q_bias, _ = steady_state_input(float(x0[1]), params)

    sensor = Sensor(PV0=plant.y, tau=tau_sensor, noise_std=noise_std)
    actuator = Atuador(q0=q_bias, q_min=q_min, q_max=q_max, tau=tau_valve)
    controller = ControladorPID(Kp=Kp, Ti=Ti, Td=Td, q_min=q_min, q_max=q_max,
                                antiwindup=True, nome="PID")
    controller.reset(q_bias=q_bias)

    rng = np.random.default_rng(seed)

    n_steps = int(round(t_final / dt))
    time = np.zeros(n_steps + 1)
    x_hist = np.zeros((n_steps + 1, 2))
    sp_hist = np.zeros(n_steps + 1)
    pv_hist = np.zeros(n_steps + 1)
    e_hist = np.zeros(n_steps + 1)
    q_cmd_hist = np.zeros(n_steps + 1)
    q_hist = np.zeros(n_steps + 1)
    d_hist = np.zeros((n_steps + 1, 2))

    time[0] = 0.0
    x_hist[0] = plant.x
    pv_hist[0] = plant.y
    sp_hist[0] = sp_function(0.0)
    q_cmd_hist[0] = q_bias
    q_hist[0] = q_bias
    d_hist[0] = np.asarray(disturbance_function(0.0), dtype=float)

    for k in range(1, n_steps + 1):
        t = time[k - 1]
        sp = float(sp_function(t))
        d = np.asarray(disturbance_function(t), dtype=float)

        pv = sensor.update(plant.y, dt, rng)             # 1) Sensor
        erro, q_cmd, _ = controller.update(sp, pv, dt)   # 2) Controlador
        q = actuator.update(q_cmd, dt)                   # 3) Atuador
        x = plant.step(q, dt, d)                         # 4) Planta

        time[k] = plant.t
        x_hist[k] = x
        sp_hist[k] = sp
        pv_hist[k] = pv
        e_hist[k] = erro
        q_cmd_hist[k] = q_cmd
        q_hist[k] = q
        d_hist[k] = d

    return {
        "time": time, "x1": x_hist[:, 0], "x2": x_hist[:, 1],
        "SP": sp_hist, "PV": pv_hist, "erro": e_hist,
        "q_cmd": q_cmd_hist, "u": q_hist,
        "d1": d_hist[:, 0], "d2": d_hist[:, 1],
        "controller": controller,
    }


def calculate_performance(time, sp, pv, u):
    """Índices simples para avaliar a malha."""
    erro = sp - pv
    iae = np.trapezoid(np.abs(erro), time)
    ise = np.trapezoid(erro**2, time)
    itae = np.trapezoid(time * np.abs(erro), time)

    sp_max, sp_min = np.max(sp), np.min(sp)
    if sp_max != sp_min:
        if sp[-1] >= sp[0]:
            overshoot = max(0.0, (np.max(pv) - sp_max) / abs(sp_max - sp[0])) * 100.0
        else:
            overshoot = max(0.0, (sp_min - np.min(pv)) / abs(sp_min - sp[0])) * 100.0
    else:
        overshoot = 0.0

    return {"IAE": iae, "ISE": ise, "ITAE": itae,
            "overshoot_percent": overshoot, "erro_final": erro[-1],
            "PV_final": pv[-1], "u_min": np.min(u), "u_max": np.max(u)}


# %%
# ---- Benchmark: problema servo e problema regulatório -----------------------
Kp_bench, Ti_bench, Td_bench = 1.0, 5.0, 0.10

def sp_servo(t):
    if t < 10.0:
        return 0.886
    return 1.20 if t < 55.0 else 1.00


def sp_regulatorio(t):
    return PUBLISHED_EQUILIBRIA["xA"][1]


def disturbance_regulatorio(t):
    return (0.0, 0.0) if t < 40.0 else (0.0, 0.10)


_bench = {}
for _nome, _sp, _d in [("servo", sp_servo, lambda t: (0.0, 0.0)),
                       ("regulatorio", sp_regulatorio, disturbance_regulatorio)]:
    _r = simulate_closed_loop(sp_function=_sp, disturbance_function=_d,
                              x0=PUBLISHED_EQUILIBRIA["xA"],
                              Kp=Kp_bench, Ti=Ti_bench, Td=Td_bench,
                              q_min=-2.0, q_max=2.0, dt=0.02, t_final=100.0)
    _bench[_nome] = (_r, calculate_performance(_r["time"], _r["SP"], _r["PV"], _r["u"]))

_fig, _ax = plt.subplots(2, 2, figsize=(12, 6), sharex=True)
for _j, _nome in enumerate(["servo", "regulatorio"]):
    _r = _bench[_nome][0]
    _ax[0, _j].plot(_r["time"], _r["SP"], "--", lw=1.2, label="SP")
    _ax[0, _j].plot(_r["time"], _r["PV"], lw=1.4, label="PV = x₂")
    _ax[0, _j].set_title(f"Benchmark — {_nome}")
    _ax[0, _j].legend(); _ax[0, _j].grid(alpha=.3)
    _ax[1, _j].plot(_r["time"], _r["u"], lw=1.4)
    _ax[1, _j].set_ylabel("u aplicado"); _ax[1, _j].set_xlabel("t adimensional")
    _ax[1, _j].grid(alpha=.3)
_fig.tight_layout(); _fig.savefig(_figpath("01_benchmark_servo_regulatorio.png"), dpi=130)

print("Benchmark (MV = u, ponto xA):")
for _nome, (_r, _m) in _bench.items():
    print(f"  {_nome:12s} IAE={_m['IAE']:7.4f}  ISE={_m['ISE']:7.4f}  "
          f"erro_final={_m['erro_final']:+.5f}  u∈[{_m['u_min']:+.3f}, {_m['u_max']:+.3f}]")


# %% [markdown]
# ---
# # Caso Industrial — Incidente Multissilo
#
# ## A válvula: a MV que existe na planta
#
# O artigo usa `u` (temperatura da camisa) como entrada de controle. Na unidade
# real não existe um atuador que "escreve" a temperatura da camisa: existe a
# **FV-201**, uma válvula de admissão de água de resfriamento no circuito de
# água temperada da camisa. O artigo fornece a relação estática (Eq. 2):
#
# $$T_c = \frac{\rho_j C_{p,j} F_c T_{cf} + UA\,T}{\rho_j C_{p,j} F_c + UA}$$
#
# Adimensionalizando e definindo $a = \rho_j C_{p,j} F_c / UA$ (proporcional à
# vazão de refrigerante) obtém-se
#
# $$u = \frac{a\,u_{cf} + x_2}{a + 1}$$
#
# Dois casos-limite, ambos fisicamente corretos:
#
# | | | |
# |---|---|---|
# | $a = 0$ | válvula fechada | $u = x_2$ → sem resfriamento, reator adiabático |
# | $a \to \infty$ | válvula 100% aberta | $u = u_{cf}$ → resfriamento máximo |
#
# Consequências que estruturam todo o caso:
#
# 1. A MV é **limitada em ambos os extremos por física**, não por um clip
#    arbitrário: a válvula não pode resfriar abaixo de $u_{cf}$.
# 2. A **capacidade** de resfriamento é $a_{max}$ — uma propriedade do
#    *equipamento* (trim da válvula), não do controlador.
# 3. O termo de resfriamento efetivo é
#    $-\beta\frac{a}{a+1}(x_2 - u_{cf})$: perder capacidade ($a_{max}$) e
#    aquecer o refrigerante ($u_{cf}$) atacam a mesma margem, por caminhos
#    diferentes e registrados em silos diferentes.

# %%
@dataclass(frozen=True)
class ValveParams:
    """Parametros da valvula de admissao de agua de resfriamento FV-201.

    `u_cf`      temperatura adimensional da agua de resfriamento na entrada
                (condicao de utilidade -- muda com o clima e com o estado da
                torre de resfriamento, NAO e propriedade da valvula)
    `a_max`     razao de capacidade termica com a valvula 100% aberta, com o
                trim de projeto instalado
    `gain_trim` fator de capacidade do trim REALMENTE instalado em relacao ao
                trim de projeto (1.00 = trim de projeto)
    """

    u_cf: float = -2.20
    a_max: float = 6.70
    characteristic: str = "linear"      # "linear" | "equal_percentage"
    rangeability: float = 30.0          # so usado em equal_percentage
    gain_trim: float = 1.00


class CoolingValve:
    """Mapa estatico q (0..1) -> u, dado o estado termico atual do reator."""

    def __init__(self, params: ValveParams | None = None):
        self.p = params or ValveParams()

    def capacity(self, q: float) -> float:
        """Razao de capacidade `a` para uma abertura fracional q."""
        q = float(np.clip(q, 0.0, 1.0))
        if self.p.characteristic == "equal_percentage":
            frac = 0.0 if q <= 0.0 else self.p.rangeability ** (q - 1.0)
        else:
            frac = q
        return self.p.a_max * self.p.gain_trim * frac

    def to_plant_input(self, q: float, x2: float) -> float:
        """u = (a u_cf + x2) / (a + 1)."""
        a = self.capacity(q)
        return (a * self.p.u_cf + x2) / (a + 1.0)

    def reachable_input_range(self, x2: float) -> tuple[float, float]:
        """Faixa de `u` fisicamente alcancavel no estado x2.

        A valvula so pode resfriar: `u` fica entre a temperatura do proprio
        reator (valvula fechada) e o limite frio em a = a_max*gain_trim.
        """
        u_closed = x2
        u_open = self.to_plant_input(1.0, x2)
        return (min(u_open, u_closed), max(u_open, u_closed))

    def opening_for_input(self, u: float, x2: float) -> float:
        """Inverso: abertura que produz `u` no estado x2.

        Usado para inicializar a malha no ponto de operacao e para calcular a
        *demanda* de curso (que pode passar de 1.0 -- caso em que a valvula
        satura e a unidade perde o controle da PV).
        """
        u_lo, u_hi = self.reachable_input_range(x2)
        if u <= u_lo:
            return 1.0
        if u >= u_hi:
            return 0.0
        denom = u - self.p.u_cf
        if abs(denom) < 1e-9:
            return 1.0
        a = (x2 - u) / denom
        if a <= 0.0:
            return 0.0
        cap = self.p.a_max * self.p.gain_trim
        if self.p.characteristic == "equal_percentage":
            frac = min(a / cap, 1.0)
            return 1.0 if frac >= 1.0 else float(
                np.clip(1.0 + np.log(max(frac, 1e-12)) / np.log(self.p.rangeability), 0.0, 1.0))
        return float(np.clip(a / cap, 0.0, 1.0))

    def demanded_travel(self, u: float, x2: float) -> float:
        """Curso EXIGIDO, sem saturar em 1.0. > 1.0 significa valvula insuficiente."""
        denom = u - self.p.u_cf
        if denom <= 0:
            return np.inf
        a = (x2 - u) / denom
        return max(a, 0.0) / (self.p.a_max * self.p.gain_trim)


# %% [markdown]
# ## Escala dimensional da unidade
#
# O modelo é adimensional; os documentos industriais não são. O mapa abaixo é
# o único ponto onde as duas descrições se encontram, e todos os documentos do
# caso (datasheets, HAZOP, procedimento, relatórios de turno) foram gerados a
# partir dele.
#
# $$x_2 = \frac{\gamma (T - T_f)}{T_f} \Rightarrow T = T_f\left(1 + \frac{x_2}{\gamma}\right)$$
#
# Com $\gamma = 20$ e $T_f = 406{,}7\ \mathrm{K}$ (alimentação pré-aquecida a
# 133,5 °C) resulta $E_a = \gamma R T_f = 67{,}6\ \mathrm{kJ/mol}$ e
# 1 unidade de $x_2$ = 20,3 K.

# %%
TF_K = 406.7                 # temperatura de alimentacao de referencia [K]
GAMMA = 20.0
DT_K = TF_K / GAMMA          # K por unidade adimensional de x2 = 20.335 K
R_GAS = 8.314                # J/(mol K)

TAU_MIN = 20.0               # 1 unidade de tempo adimensional = 1 tempo de residencia = 20 min
T_ZERO = datetime(2026, 8, 8, 6, 0, 0)   # t = 0 do caso


def x2_to_C(x2):
    """Temperatura adimensional -> graus Celsius."""
    return TF_K * (1.0 + np.asarray(x2, dtype=float) / GAMMA) - 273.15


def C_to_x2(T_C):
    """Graus Celsius -> temperatura adimensional."""
    return GAMMA * ((np.asarray(T_C, dtype=float) + 273.15) / TF_K - 1.0)


def t_to_stamp(t):
    """Tempo adimensional -> timestamp de planta."""
    return T_ZERO + timedelta(minutes=float(t) * TAU_MIN)


print(f"E_a = γ·R·Tf = {GAMMA * R_GAS * TF_K / 1000:.1f} kJ/mol")
print(f"1 unidade de x2 = {DT_K:.3f} K   |   1 unidade de t = {TAU_MIN:.0f} min")
for _n, _x in [("SP da unidade (xC)", 4.705), ("envelope inferior", 4.45),
               ("envelope superior", 4.99), ("TAH-201", 5.00), ("TAHH-201 (SIS)", 5.45)]:
    print(f"  {_n:22s} x2={_x:5.3f} → {x2_to_C(_x):7.2f} °C")
print(f"  {'loop temperado (proj.)':22s} u_cf={-2.20:5.2f} → {x2_to_C(-2.20):7.2f} °C")


# %% [markdown]
# ## Unidade U-200 — tags, limites e envelope operacional
#
# Fonte única da verdade para o simulador **e** para todos os documentos
# gerados. Se um número muda aqui, muda em todos os silos (§16).

# %%
UNIDADE = "U-200"
PLANTA = "Complexo Químico Vale do Aço — Planta de Resinas"

TAGS = {
    "R-201":   ("Reator CSTR encamisado, 12 m³ úteis, aço inox 316L", "-"),
    "TT-201":  ("Transmissor de temperatura do reator (termopar tipo J, poço)", "°C"),
    "TIC-201": ("Controlador de temperatura do reator (PID, DCS)", "%"),
    "FV-201":  ("Válvula de controle de admissão de água de resfriamento", "% curso"),
    "ZT-201":  ("Transmissor de posição de FV-201 (feedback do posicionador)", "%"),
    "FT-201":  ("Medidor de vazão de água de resfriamento para a camisa", "m³/h"),
    "TT-202":  ("Temperatura do loop de água temperada na entrada da camisa", "°C"),
    "TT-203":  ("Temperatura da água de torre na entrada de E-201", "°C"),
    "TT-207":  ("Temperatura do loop de água temperada na saída de E-201", "°C"),
    "TT-204":  ("Temperatura da alimentação para R-201 (saída de E-202)", "°C"),
    "FT-204":  ("Vazão de alimentação para R-201", "m³/h"),
    "AT-205":  ("Analisador em linha de conversão (NIR)", "fração"),
    "P-201":   ("Bomba de circulação do loop de água temperada da camisa", "-"),
    "E-201":   ("Trocador de calor loop temperado / água de torre", "-"),
    "E-202":   ("Pré-aquecedor de alimentação", "-"),
    "TK-201":  ("Tanque pulmão de alimentação", "-"),
    "PSV-201": ("Válvula de segurança do reator, 6,0 barg", "-"),
    "SIS-201": ("Intertravamento de temperatura muito alta (TAHH-201)", "-"),
}

# --- Envelope operacional (Design Basis U-200-DB-001, Rev. 3) ----------------
X2_ENVELOPE = (4.45, 4.99)      # faixa normal de operação da unidade (adimensional)
X2_TAH = 5.00                   # TAH-201, alarme de temperatura alta
X2_TAHH = 5.45                  # TAHH-201, intertravamento SIS (corte de alimentação)
X2_TAL = 4.40                   # TAL-201, alarme de temperatura baixa
TRAVEL_ZAH = 0.80               # ZAH-201, alarme de curso alto de FV-201
TRAVEL_SAT = 0.98               # curso considerado saturado
FC_DESIGN_M3H = 45.0            # vazão do loop por E-201 com FV-201 100% e trim de projeto
FLOW_LOOP_M3H = 60.0            # vazão total de circulação de P-201 (constante)
CW_TOWER_DESIGN_C = 28.0        # água de torre no projeto
CW_TOWER_TAH_C = 32.0           # TAH-203, alarme de água de torre quente
A_MAX_PROJETO = 6.70            # razão de capacidade com FV-201 100% e trim Cv 40
TRIM_SUBSTITUTO = 0.55          # trim realmente montado: Cv 22 (gaiola anticavitação)
SP_UNIDADE = 4.705              # SP térmico da unidade — o MESMO nas duas campanhas


# --- Campanhas ---------------------------------------------------------------
@dataclass(frozen=True)
class Campaign:
    """Condição de campanha: o que produção definiu, não o que o controle faz."""
    po: str
    grade: str
    produto: str
    H: float                    # calor de reação adimensional (∝ concentração de monômero)
    monomero_pct: float         # % de monômero na alimentação (documento de produção)
    sp: float                   # SP de temperatura em x2
    x_min: float                # conversão mínima de especificação
    x_max: float                # conversão máxima de especificação
    lote: str


CAMPANHA_A = Campaign(po="PO-2026-0417", grade="RA-180", produto="Resina Alquídica RA-180",
                      H=8.00, monomero_pct=57.0, sp=SP_UNIDADE,
                      x_min=0.740, x_max=0.795, lote="L-26A-0417")
CAMPANHA_B = Campaign(po="PO-2026-0418", grade="RB-220", produto="Resina Poliéster RB-220",
                      H=8.15, monomero_pct=58.1, sp=SP_UNIDADE,
                      x_min=0.752, x_max=0.778, lote="L-26B-0418")

# --- Cronograma do incidente (tempo adimensional) ----------------------------
T_FINAL = 420.0
T_TRANS_INI, T_TRANS_FIM = 48.0, 66.0     # transição de grade RA-180 -> RB-220
T_UCF_INI, T_UCF_FIM = 66.0, 360.0        # aquecimento do circuito de resfriamento
UCF_PROJETO, UCF_FIM = -2.20, -1.85       # 88,8 °C -> 95,9 °C no loop temperado
UCF_AMPL_DIURNA = 0.030                   # ciclo dia/noite (período 72 t.u. = 24 h)
T_ZAH_SUPRIMIDO = 222.0                   # operação suprime o alarme de curso alto
T_UPSET_INI, T_UPSET_FIM = 336.0, 396.0   # falha do controle de temperatura em E-202
UPSET_D2 = 0.15                           # +3,05 K na alimentação
UPSET_RAMPA = 3.0
T_SP_TENTATIVA, T_SP_RETORNO = 348.0, 384.0
SP_TENTATIVA = 4.60


@dataclass(frozen=True)
class Scenario:
    """Define QUAL realidade física está sendo simulada.

    `incidente=False` → unidade íntegra, campanha A do início ao fim (BASELINE).
    `incidente=True`  → unidade real de agosto/2026 (trim substituído, troca de
                        campanha, aquecimento do circuito, upset de alimentação).
    `trim` permite o contrafactual "e se o trim correto tivesse sido instalado".
    """
    nome: str
    incidente: bool
    trim: float = 1.00
    t_final: float = T_FINAL
    dt: float = 0.025      # 30 s de scan/integração
    dt_log: float = 0.25   # historian amostrado a cada 5 min
    seed: int = 20260808
    noise_x2: float = 0.006
    noise_at205: float = 0.004
    tau_sensor: float = 0.05      # 1 min
    tau_valve: float = 0.05       # 1 min de curso total


CEN_BASELINE = Scenario(nome="BASELINE", incidente=False, trim=1.00)
CEN_INCIDENTE = Scenario(nome="INCIDENTE", incidente=True, trim=TRIM_SUBSTITUTO)
CEN_CONTRAFACTUAL = Scenario(nome="CONTRAFACTUAL", incidente=True, trim=1.00)


# %% [markdown]
# ## As cinco funções de cenário (§18)
#
# O incidente **não** é uma sequência arbitrária de números injetada na
# simulação. Cada efeito físico entra por uma função com significado
# industrial próprio, e cada uma delas corresponde a um silo de informação
# diferente:
#
# | Função | O que representa | Silo onde é registrada |
# |---|---|---|
# | `production_campaign` | grade, receita, especificação | Produção (PO) |
# | `operating_condition` | SP, modo, estado da unidade | Operação (turno) / DCS |
# | `equipment_condition` | estado físico de FV-201 e da utilidade | Manutenção (WO) / Historian |
# | `process_disturbance` | perturbações externas ao processo | Historian / Turno |
# | `operator_action` | intervenções humanas | Turno / Event log |

# %%
def production_campaign(t: float, scn: Scenario) -> Campaign:
    """Campanha em produção no instante t.

    Durante a transição de grade a receita é interpolada: a alimentação vai
    sendo enriquecida de 57% para 62% de monômero ao longo de ~6 h, o que
    aparece no modelo como uma rampa de H.
    """
    if not scn.incidente:
        return CAMPANHA_A
    if t < T_TRANS_INI:
        return CAMPANHA_A
    if t >= T_TRANS_FIM:
        return CAMPANHA_B
    f = (t - T_TRANS_INI) / (T_TRANS_FIM - T_TRANS_INI)
    return replace(
        CAMPANHA_B,
        H=CAMPANHA_A.H + f * (CAMPANHA_B.H - CAMPANHA_A.H),
        monomero_pct=CAMPANHA_A.monomero_pct + f * (CAMPANHA_B.monomero_pct - CAMPANHA_A.monomero_pct),
    )


@dataclass(frozen=True)
class OperatingCondition:
    sp: float
    modo: str          # AUTO | MANUAL
    estado: str        # NORMAL | TRANSICAO_GRADE | ANORMAL
    zah_suprimido: bool


def operating_condition(t: float, scn: Scenario, memoria: dict) -> OperatingCondition:
    """Condição operacional: SP em vigor, modo do TIC-201 e estado da unidade.

    O SP de campanha vem da PO; um SP lançado pela operação (registrado em
    `memoria`) tem precedência, porque é isso que acontece no painel.
    """
    camp = production_campaign(t, scn)
    sp = memoria.get("sp_operador", camp.sp)
    if T_TRANS_INI <= t < T_TRANS_FIM and scn.incidente:
        estado = "TRANSICAO_GRADE"
    elif memoria.get("estado_anormal", False):
        estado = "ANORMAL"
    else:
        estado = "NORMAL"
    return OperatingCondition(sp=sp, modo=memoria.get("modo", "AUTO"),
                              estado=estado, zah_suprimido=memoria.get("zah_suprimido", False))


@dataclass(frozen=True)
class EquipmentCondition:
    valve: ValveParams
    loop_min_C: float       # TT-207: temperatura do loop temperado saindo de E-201
    tower_C: float          # TT-203: água de resfriamento de torre na entrada de E-201


def equipment_condition(t: float, scn: Scenario) -> EquipmentCondition:
    """Estado físico dos equipamentos no instante t.

    Duas coisas mudam ao longo da campanha, por caminhos independentes:

    * `gain_trim` — CONSTANTE durante todo o horizonte, mas diferente de 1 no
      cenário de incidente: é o trim que está fisicamente montado dentro do
      corpo de FV-201 desde a parada de 29/07. Nenhum instrumento mede isso.
      Só o cruzamento ZT-201 × FT-201 × datasheet o denuncia.
    * `u_cf` — sobe ao longo da campanha: a água de torre aquece (onda de calor
      + enchimento da torre sujo, WO-3882 adiada) e E-201 entrega o loop
      temperado mais quente. Isso É medido, por TT-203 e TT-207, e é a pista
      que sustenta a hipótese falsa mais atraente.
    """
    if not scn.incidente:
        u_cf = UCF_PROJETO
        tower = CW_TOWER_DESIGN_C
    else:
        f = float(np.clip((t - T_UCF_INI) / (T_UCF_FIM - T_UCF_INI), 0.0, 1.0))
        diurno = np.sin(2.0 * np.pi * (t - 9.0) / 72.0)
        u_cf = UCF_PROJETO + f * (UCF_FIM - UCF_PROJETO) + UCF_AMPL_DIURNA * diurno
        tower = CW_TOWER_DESIGN_C + 5.0 * f + 1.8 * diurno
    valve = ValveParams(u_cf=float(u_cf), a_max=A_MAX_PROJETO, gain_trim=scn.trim)
    return EquipmentCondition(valve=valve,
                              loop_min_C=float(x2_to_C(u_cf)),
                              tower_C=float(tower))


def process_disturbance(t: float, state: np.ndarray, scn: Scenario,
                        ruido: tuple[float, float]) -> tuple[float, float]:
    """Perturbações de processo (d1, d2).

    d1 — variação de composição da alimentação (ruído lento de tancagem).
    d2 — desvio de temperatura da alimentação. No cenário de incidente, o
         controle de temperatura de E-202 perde o controle a partir de
         t = 336 (2026-08-12 20:00) e a alimentação sobe ~5,5 K.
    """
    d1 = 0.0012 * ruido[0]
    d2 = 0.0020 * ruido[1]
    if scn.incidente and t >= T_UPSET_INI:
        if t < T_UPSET_INI + UPSET_RAMPA:
            d2 += UPSET_D2 * (t - T_UPSET_INI) / UPSET_RAMPA
        elif t < T_UPSET_FIM:
            d2 += UPSET_D2
        elif t < T_UPSET_FIM + 2 * UPSET_RAMPA:
            d2 += UPSET_D2 * (1.0 - (t - T_UPSET_FIM) / (2 * UPSET_RAMPA))
    return float(d1), float(d2)


def operator_action(t: float, medidas: dict, memoria: dict, scn: Scenario) -> list[str]:
    """Intervenções humanas. Devolve a lista de ações executadas neste passo.

    As duas ações do caso são localmente razoáveis e documentadas no
    procedimento; nenhuma delas é um erro grosseiro. É exatamente isso que as
    torna difíceis de enxergar depois.
    """
    if not scn.incidente:
        return []
    acoes = []

    # 1) Alarme ZAH-201 repetitivo desde a troca de campanha -> supressão a
    #    pedido do turno (POP-U200-014 §7.3 permite supressão temporária).
    if t >= T_ZAH_SUPRIMIDO and not memoria.get("zah_suprimido", False):
        memoria["zah_suprimido"] = True
        acoes.append("SUPRESSAO_ALARME_ZAH201")

    # 2) Com a temperatura acima do SP e subindo, a operação baixa o SP
    #    tentando "puxar" a PV. A válvula já está saturada: não há efeito.
    if t >= T_SP_TENTATIVA and not memoria.get("sp_baixado", False):
        memoria["sp_baixado"] = True
        memoria["sp_operador"] = SP_TENTATIVA
        acoes.append(f"SP_REDUZIDO_{SP_TENTATIVA:.3f}")

    if t >= T_SP_RETORNO and not memoria.get("sp_restaurado", False):
        memoria["sp_restaurado"] = True
        memoria["sp_operador"] = SP_UNIDADE
        acoes.append(f"SP_RESTAURADO_{SP_UNIDADE:.3f}")

    # Estado anormal declarado quando a PV cruza o alarme alto.
    if medidas.get("PV", 0.0) > X2_TAH and not memoria.get("estado_anormal", False):
        memoria["estado_anormal"] = True
        acoes.append("UNIDADE_DECLARADA_ANORMAL")
    return acoes


# %% [markdown]
# ## Interface de controlador e harness de simulação
#
# `BaseController` é a única porta pela qual um controlador toca a malha. O
# PID entra por ela hoje; qualquer estratégia futura entra pela mesma porta,
# com **exatamente** a mesma planta, o mesmo cenário, as mesmas perturbações e
# o mesmo ruído (§30).
#
# O que o controlador recebe em `context` é o que existe no DCS — nada mais.
# `gain_trim` **não** está lá: a perda de capacidade de FV-201 não é medida
# por nenhum instrumento da unidade. Ela só é reconstruível cruzando os
# documentos com o historian, que é precisamente o problema do benchmark.

# %%
class BaseController:
    """Contrato mínimo de um controlador da malha TIC-201.

    `update` recebe o que o DCS enxerga e devolve a abertura comandada de
    FV-201, em fração de curso (0..1).
    """

    nome = "BaseController"

    def reset(self, operating_context: dict | None = None) -> None:
        pass

    def update(self, observation: dict, context: dict, dt: float) -> float:
        raise NotImplementedError


class PIDController(BaseController):
    """Adaptador: embrulha o `ControladorPID` do modelo-base na interface.

    Ganho negativo: a MV é a abertura da válvula de RESFRIAMENTO, portanto
    PV acima do SP (erro negativo) tem de ABRIR a válvula.
    """

    def __init__(self, Kp: float, Ti: float, Td: float, nome: str = "PID TIC-201"):
        self.pid = ControladorPID(Kp=Kp, Ti=Ti, Td=Td, q_min=0.0, q_max=1.0,
                                  antiwindup=True, nome=nome)
        self.nome = nome

    def reset(self, operating_context: dict | None = None) -> None:
        bias = (operating_context or {}).get("q_bias", 0.0)
        self.pid.reset(q_bias=float(bias))

    def update(self, observation: dict, context: dict, dt: float) -> float:
        _, q_cmd, _ = self.pid.update(observation["SP"], observation["PV"], dt)
        return float(q_cmd)

    def __repr__(self):
        return repr(self.pid)


# %%
def _ruido_lento(rng, n, tau_passos):
    """Ruído branco passado por um filtro de 1ª ordem: deriva de tancagem."""
    branco = rng.standard_normal(n)
    saida = np.zeros(n)
    alpha = 1.0 / max(tau_passos, 1.0)
    for k in range(1, n):
        saida[k] = saida[k - 1] + alpha * (branco[k] - saida[k - 1])
    return saida / max(saida.std(), 1e-9)


def run_case(controller: BaseController, scn: Scenario) -> dict:
    """Roda o caso industrial completo com o controlador dado.

    A planta, o cenário, as perturbações e o ruído são função apenas de `scn`.
    Trocar `controller` é a ÚNICA diferença admissível entre execuções
    comparáveis.
    """
    dt, n = scn.dt, int(round(scn.t_final / scn.dt))
    rng = np.random.default_rng(scn.seed)
    # Ruído pré-gerado: garante a MESMA realização em todos os experimentos,
    # independentemente de quantas vezes cada ramo do cenário sorteia números.
    n_sens = rng.standard_normal(n + 1)
    n_at205 = rng.standard_normal(n + 1)
    n_ft201 = rng.standard_normal(n + 1)
    n_tt203 = rng.standard_normal(n + 1)
    n_d1 = _ruido_lento(rng, n + 1, 400)
    n_d2 = _ruido_lento(rng, n + 1, 250)

    camp0 = production_campaign(0.0, scn)
    equip0 = equipment_condition(0.0, scn)
    params0 = replace(CSTRParams(), H=camp0.H)
    u0, x1_0 = steady_state_input(camp0.sp, params0)
    valve0 = CoolingValve(equip0.valve)
    q0 = valve0.opening_for_input(u0, camp0.sp)

    plant = Process_CSTR(params=params0, x0=(x1_0, camp0.sp))
    sensor = Sensor(PV0=camp0.sp, tau=scn.tau_sensor, noise_std=0.0)
    atuador = Atuador(q0=q0, q_min=0.0, q_max=1.0, tau=scn.tau_valve)
    controller.reset({"q_bias": q0, "SP": camp0.sp, "campanha": camp0.po})

    memoria: dict = {}
    log = {k: np.zeros(n + 1) for k in
           ("t", "SP", "PV", "x1", "x2", "u", "q_cmd", "q", "d1", "d2",
            "H", "u_cf", "trim", "demanda_curso", "at205", "ft201", "tt203",
            "tt207", "tt202", "tt204", "erro")}
    log["estado"] = np.empty(n + 1, dtype=object)
    log["modo"] = np.empty(n + 1, dtype=object)
    log["po"] = np.empty(n + 1, dtype=object)
    eventos: list[tuple[float, str]] = []

    def registrar(k, t, sp, pv, q_cmd, q, u, d, camp, equip, oc, dem):
        log["t"][k], log["SP"][k], log["PV"][k] = t, sp, pv
        log["x1"][k], log["x2"][k] = plant.x[0], plant.x[1]
        log["u"][k], log["q_cmd"][k], log["q"][k] = u, q_cmd, q
        log["d1"][k], log["d2"][k] = d[0], d[1]
        log["H"][k], log["u_cf"][k] = camp.H, equip.valve.u_cf
        log["trim"][k], log["demanda_curso"][k] = equip.valve.gain_trim, dem
        log["erro"][k] = sp - pv
        log["at205"][k] = plant.x[0] + scn.noise_at205 * n_at205[k]
        log["ft201"][k] = FC_DESIGN_M3H * equip.valve.gain_trim * q + 0.25 * n_ft201[k]
        log["tt203"][k] = equip.tower_C + 0.20 * n_tt203[k]
        log["tt207"][k] = equip.loop_min_C + 0.20 * n_tt203[k]
        log["tt202"][k] = float(x2_to_C(u))
        log["tt204"][k] = float(x2_to_C(d[1]))
        log["estado"][k], log["modo"][k], log["po"][k] = oc.estado, oc.modo, camp.po

    t = 0.0
    camp, equip = camp0, equip0
    oc = operating_condition(t, scn, memoria)
    registrar(0, t, camp0.sp, camp0.sp, q0, q0, u0, (0.0, 0.0), camp0, equip0, oc, q0)

    sis_trip = False
    for k in range(1, n + 1):
        t = (k - 1) * dt
        camp = production_campaign(t, scn)
        equip = equipment_condition(t, scn)
        oc = operating_condition(t, scn, memoria)
        valve = CoolingValve(equip.valve)

        # 1) Medição
        pv = sensor.update(plant.y, dt, rng=_RngShim(scn.noise_x2 * n_sens[k]))

        # 2) Controlador — só enxerga o que existe no DCS
        obs = {"SP": oc.sp, "PV": pv, "ZT201": atuador.q,
               "FT201": log["ft201"][k - 1], "TT203": log["tt203"][k - 1],
               "TT207": log["tt207"][k - 1], "AT205": log["at205"][k - 1],
               "TT204": log["tt204"][k - 1]}
        ctx = {"campanha": camp.po, "grade": camp.grade,
               "x_min": camp.x_min, "x_max": camp.x_max,
               "envelope": X2_ENVELOPE, "TAH": X2_TAH, "TAHH": X2_TAHH,
               "travel_zah": TRAVEL_ZAH, "fc_design": FC_DESIGN_M3H,
               "modo": oc.modo, "estado": oc.estado,
               "zah_suprimido": oc.zah_suprimido}
        q_cmd = float(np.clip(controller.update(obs, ctx, dt), 0.0, 1.0))

        # 3) Atuador (saturação física em 0..100% de curso)
        q = atuador.update(q_cmd, dt)

        # 4) Válvula -> entrada da planta
        u = valve.to_plant_input(q, plant.x[1])

        # 5) Planta
        d = process_disturbance(t, plant.x, scn, (n_d1[k], n_d2[k]))
        plant.params = replace(plant.params, H=camp.H)

        # Demanda de curso: quanto de FV-201 seria preciso AGORA para zerar
        # x2'. Acima de 1.0 a válvula é insuficiente e a temperatura sobe —
        # este é o indicador de margem que nenhum instrumento da unidade mede.
        u_balanco = ((1.0 + plant.params.beta) * plant.x[1]
                     - plant.params.H * reaction_rate(plant.x[0], plant.x[1], plant.params)
                     - d[1]) / plant.params.beta
        dem = valve.demanded_travel(u_balanco, plant.x[1])

        plant.step(u, dt, d)

        # 6) Ação de operador
        for acao in operator_action(t + dt, {"PV": pv, "q": q}, memoria, scn):
            eventos.append((t + dt, acao))

        if plant.x[1] > X2_TAHH:
            sis_trip = True

        oc = operating_condition(t + dt, scn, memoria)
        registrar(k, t + dt, oc.sp, pv, q_cmd, q, u, d, camp, equip, oc, dem)

    log["eventos"] = eventos
    log["scenario"] = scn
    log["controller"] = getattr(controller, "nome", type(controller).__name__)
    log["sis_trip"] = sis_trip
    if sis_trip:
        print(f"  ⚠ {scn.nome}/{log['controller']}: PV cruzou TAHH-201 "
              f"({X2_TAHH} → {x2_to_C(X2_TAHH):.1f} °C). O SIS não está modelado; "
              f"este cenário passa a exigir modelo de intertravamento.")
    return log


class _RngShim:
    """Injeta uma amostra de ruído já sorteada no `Sensor` do modelo-base.

    O `Sensor` pede `rng.normal(0, std)`. Pré-gerar a sequência é o que
    garante que BASELINE, INCIDENTE e CONTRAFACTUAL vejam exatamente o mesmo
    ruído nos mesmos instantes (§30), independentemente do caminho tomado.
    """
    __slots__ = ("_v",)

    def __init__(self, valor: float):
        self._v = valor

    def normal(self, loc=0.0, scale=1.0):
        return self._v


# %% [markdown]
# ## Sintonia do TIC-201
#
# O PID **não** é um espantalho. Ele é sintonizado por IMC sobre o modelo
# identificado em malha aberta na própria MV da unidade (curso de FV-201),
# com $\lambda = \tau$ — escolha conservadora e usual para reator exotérmico.
#
# | | valor | origem |
# |---|---|---|
# | $K$ | −5,43 x₂/curso | degrau de ±1% e ±2% de curso em torno do ponto de operação |
# | $\tau$ | 1,40 t.u. (28 min) | tempo de 63,2% |
# | $\theta$ | 0,10 t.u. (2 min) | sensor + curso da válvula |
# | $K_p = \tau/[K(\lambda\tau+\theta)]$ | **−0,17** | IMC, $\lambda = \tau$ |
# | $T_i = \tau$ | **1,40** | IMC |
# | $T_d = \theta/2$ | **0,05** | compensação parcial do atraso |
#
# Ganho **negativo** porque a MV é a abertura da válvula de resfriamento.

# %%
def identificar_processo(scn: Scenario = CEN_BASELINE, dq: float = 0.02) -> dict:
    """Degrau em malha aberta na MV real. Devolve K e tau do modelo de 1ª ordem."""
    camp = production_campaign(0.0, scn)
    p = replace(CSTRParams(), H=camp.H)
    u0, x1_0 = steady_state_input(camp.sp, p)
    valve = CoolingValve(equipment_condition(0.0, scn).valve)
    q0 = valve.opening_for_input(u0, camp.sp)

    Ks, taus = [], []
    for passo in (+dq, -dq):
        pl = Process_CSTR(params=p, x0=(x1_0, camp.sp))
        dtl, tf = 0.005, 30.0
        ts, xs = [], []
        for k in range(int(tf / dtl) + 1):
            q = q0 + (passo if k * dtl >= 1.0 else 0.0)
            pl.step(valve.to_plant_input(q, pl.x[1]), dtl)
            ts.append(k * dtl); xs.append(pl.x[1])
        ts, xs = np.array(ts), np.array(xs)
        dy = xs[-1] - camp.sp
        Ks.append(dy / passo)
        taus.append(ts[int(np.argmax((xs - camp.sp) / dy >= 0.632))] - 1.0)
    return {"K": float(np.mean(Ks)), "tau": float(np.mean(taus)), "q0": float(q0)}


def sintonia_imc(ident: dict, theta: float, lam: float = 1.0) -> dict:
    """IMC para 1ª ordem com atraso: Kp = tau / (K (lam*tau + theta))."""
    K, tau = ident["K"], ident["tau"]
    return {"Kp": tau / (K * (lam * tau + theta)), "Ti": tau, "Td": theta / 2.0}


IDENT = identificar_processo()
THETA = CEN_BASELINE.tau_sensor + CEN_BASELINE.tau_valve
TUNE = sintonia_imc(IDENT, THETA, lam=1.0)
KP_TIC201 = round(TUNE["Kp"], 3)
TI_TIC201 = round(TUNE["Ti"], 2)
TD_TIC201 = round(TUNE["Td"], 3)

print(f"identificação: K={IDENT['K']:+.3f} x2/curso   τ={IDENT['tau']:.3f} t.u. "
      f"({IDENT['tau']*TAU_MIN:.0f} min)   θ={THETA:.3f}   q0={100*IDENT['q0']:.2f}%")
print(f"sintonia IMC (λ=τ):  Kp={KP_TIC201:+.3f}   Ti={TI_TIC201:.2f}   Td={TD_TIC201:.3f}")
print(f"                     → 1 K de erro move a válvula {abs(KP_TIC201)*100/DT_K:.2f} pontos de curso")


def novo_pid() -> PIDController:
    """Instância nova do TIC-201 com a sintonia oficial da unidade."""
    return PIDController(Kp=KP_TIC201, Ti=TI_TIC201, Td=TD_TIC201, nome="PID TIC-201")


# %% [markdown]
# ## Métricas (§20)
#
# A função de desempenho do caso **não pode ser só o erro**. Se fosse, o
# incidente seria quase invisível: o PID mantém a PV perto do SP quase o tempo
# todo. As quatro famílias abaixo separam explicitamente *controlar a PV* de
# *operar a unidade*.

# %%
def _janela(res: dict, ini: float | None, fim: float | None):
    t = res["t"]
    m = np.ones_like(t, dtype=bool)
    if ini is not None: m &= t >= ini
    if fim is not None: m &= t <= fim
    return m


def metrics(res: dict, ini: float | None = None, fim: float | None = None) -> dict:
    """Índices de controle, processo, operação e segurança sobre uma janela."""
    m = _janela(res, ini, fim)
    t, sp, pv = res["t"][m], res["SP"][m], res["PV"][m]
    x1, x2, q = res["x1"][m], res["x2"][m], res["q"][m]
    dem = res["demanda_curso"][m]
    e = sp - pv
    dur = t[-1] - t[0]
    camp = production_campaign(float(t[len(t) // 2]), res["scenario"])
    em_spec = (x1 >= camp.x_min) & (x1 <= camp.x_max)
    horas = lambda mask: float(np.sum(mask) * (t[1] - t[0]) * TAU_MIN / 60.0)  # noqa: E731

    return {
        # --- controle -------------------------------------------------------
        "IAE": float(np.trapezoid(np.abs(e), t)),
        "ISE": float(np.trapezoid(e ** 2, t)),
        "ITAE": float(np.trapezoid(t * np.abs(e), t)),
        "erro_max": float(np.max(np.abs(e))),
        "erro_final": float(e[-1]),
        "erro_medio": float(np.mean(e)),
        # --- processo -------------------------------------------------------
        "conversao_media": float(np.mean(x1)),
        "conversao_max": float(np.max(x1)),
        "tempo_em_spec_pct": float(100.0 * np.mean(em_spec)),
        "producao_total": float(np.trapezoid(x1, t)),
        "producao_em_spec": float(np.trapezoid(x1 * em_spec, t)),
        "producao_perdida_pct": float(100.0 * (1.0 - np.trapezoid(x1 * em_spec, t)
                                               / max(np.trapezoid(x1, t), 1e-9))),
        "overshoot_x2": float(max(0.0, np.max(x2) - np.max(sp))),
        # --- operação -------------------------------------------------------
        "curso_medio_pct": float(100.0 * np.mean(q)),
        "curso_max_pct": float(100.0 * np.max(q)),
        "margem_curso_min_pct": float(100.0 * (1.0 - np.max(q))),
        "tempo_saturado_h": horas(q >= TRAVEL_SAT),
        "tempo_curso_alto_h": horas(q >= TRAVEL_ZAH),
        "demanda_curso_max_pct": float(100.0 * np.max(np.minimum(dem, 5.0))),
        "esforco_controle": float(np.sum(np.abs(np.diff(q)))),
        "tempo_anormal_h": horas(res["estado"][m] == "ANORMAL"),
        "intervencoes": int(sum(1 for tt, _ in res["eventos"]
                                if (ini is None or tt >= ini) and (fim is None or tt <= fim))),
        # --- segurança (exposição, não probabilidade) -----------------------
        "tempo_acima_TAH_h": horas(x2 > X2_TAH),
        "tempo_acima_envelope_h": horas(x2 > X2_ENVELOPE[1]),
        "temperatura_max_x2": float(np.max(x2)),
        "temperatura_max_C": float(x2_to_C(np.max(x2))),
        "margem_TAHH_min": float(X2_TAHH - np.max(x2)),
        "margem_TAHH_min_K": float((X2_TAHH - np.max(x2)) * DT_K),
        "duracao_h": float(dur * TAU_MIN / 60.0),
    }


# ponytail: pesos explícitos e editáveis; NÃO é um modelo de risco, é uma
# função de custo operacional declarada do pesquisador (§3, §20).
PESOS_CUSTO = {
    "erro": 1.0,          # × IAE normalizado
    "qualidade": 3.0,     # × fração de produção fora de especificação
    "margem": 2.0,        # × fração do tempo com curso acima de ZAH-201
    "saturacao": 4.0,     # × fração do tempo com a válvula saturada
    "exposicao": 5.0,     # × fração do tempo acima do TAH-201
}


def operational_cost(met: dict, pesos: dict | None = None) -> dict:
    """Custo operacional agregado. Separa o que o PID otimiza do que a unidade paga.

    Os pesos são uma DECISÃO do pesquisador e estão declarados em `PESOS_CUSTO`.
    Nenhum deles pretende ser probabilidade de evento.
    """
    p = pesos or PESOS_CUSTO
    h = max(met["duracao_h"], 1e-9)
    termos = {
        "erro": p["erro"] * met["IAE"] / max(met["duracao_h"], 1e-9),
        "qualidade": p["qualidade"] * met["producao_perdida_pct"] / 100.0,
        "margem": p["margem"] * met["tempo_curso_alto_h"] / h,
        "saturacao": p["saturacao"] * met["tempo_saturado_h"] / h,
        "exposicao": p["exposicao"] * met["tempo_acima_TAH_h"] / h,
    }
    termos["TOTAL"] = float(sum(termos.values()))
    return termos


# %% [markdown]
# ## Os três experimentos obrigatórios (§19)
#
# | | planta | controlador | cenário |
# |---|---|---|---|
# | **A — BASELINE** | íntegra | PID TIC-201 | sem incidente |
# | **B — PID + PROBLEMA** | mesma | **mesmo PID** | com incidente |
# | **C — CONTROLADOR ALTERNATIVO** | mesma | via `BaseController` | mesmo incidente |
#
# O Experimento C **não** implementa o controlador inteligente (§4). Ele
# demonstra que a infraestrutura é agnóstica: rodando o PID pela porta genérica
# obtém-se uma trajetória **bit a bit idêntica** à do Experimento B. É essa
# identidade que garante que qualquer diferença futura seja atribuível ao
# controlador, e a nada mais.

# %%
class ProposedController(BaseController):
    """Ponto de entrada do controlador a ser desenvolvido. NÃO implementado (§4).

    Contrato:
        observation — o que o DCS mede: SP, PV, ZT-201, FT-201, TT-203, TT-207,
                      TT-204, AT-205.
        context     — campanha em vigor, especificação, envelope e limites de
                      alarme. NÃO contém o estado interno da válvula.
        retorno     — abertura comandada de FV-201, fração de curso em [0, 1].

    Tudo o que for necessário além disso (datasheet de FV-201, histórico de
    ordens de manutenção, HAZOP, relatórios de turno) está no
    `investigation_package/` e é justamente o objeto do benchmark.
    """

    nome = "ProposedController (não implementado)"

    def update(self, observation, context, dt):
        raise NotImplementedError(
            "Experimento C é infraestrutura. Implemente aqui a estratégia "
            "proposta e rode run_case(ProposedController(), CEN_INCIDENTE)."
        )


print("Experimento A — BASELINE (planta íntegra, campanha RA-180, sem incidente)")
EXP_A = run_case(novo_pid(), CEN_BASELINE)
print("Experimento B — PID + PROBLEMA INDUSTRIAL")
EXP_B = run_case(novo_pid(), CEN_INCIDENTE)
print("Experimento C — mesmo incidente pela interface BaseController")
EXP_C = run_case(novo_pid(), CEN_INCIDENTE)
print("Contrafactual B' — mesmo incidente, trim de projeto (uso interno)")
EXP_BC = run_case(novo_pid(), CEN_CONTRAFACTUAL)

for _k in ("x2", "q", "PV", "SP", "u"):
    assert np.array_equal(EXP_B[_k], EXP_C[_k]), f"B e C divergem em {_k}"
print("\n✓ B ≡ C bit a bit: a planta, o cenário, as perturbações e o ruído são "
      "idênticos; só o controlador é substituível (§30).")


# %%
def tabela_comparativa(exps: dict[str, dict], ini=None, fim=None) -> dict[str, dict]:
    mets = {nome: metrics(r, ini, fim) for nome, r in exps.items()}
    custos = {nome: operational_cost(m) for nome, m in mets.items()}
    linhas = [
        ("CONTROLE", None, None),
        ("  IAE", "IAE", "{:.3f}"),
        ("  ISE", "ISE", "{:.3f}"),
        ("  ITAE", "ITAE", "{:.1f}"),
        ("  |erro| máx", "erro_max", "{:.4f}"),
        ("  erro médio", "erro_medio", "{:+.5f}"),
        ("PROCESSO", None, None),
        ("  conversão média", "conversao_media", "{:.4f}"),
        ("  tempo em spec [%]", "tempo_em_spec_pct", "{:.1f}"),
        ("  produção perdida [%]", "producao_perdida_pct", "{:.1f}"),
        ("OPERAÇÃO", None, None),
        ("  curso médio FV-201 [%]", "curso_medio_pct", "{:.1f}"),
        ("  curso máx FV-201 [%]", "curso_max_pct", "{:.1f}"),
        ("  demanda de curso máx [%]", "demanda_curso_max_pct", "{:.0f}"),
        ("  margem de curso mín [%]", "margem_curso_min_pct", "{:.1f}"),
        ("  tempo saturado [h]", "tempo_saturado_h", "{:.1f}"),
        ("  tempo curso > ZAH [h]", "tempo_curso_alto_h", "{:.1f}"),
        ("  esforço de controle", "esforco_controle", "{:.2f}"),
        ("  intervenções", "intervencoes", "{:.0f}"),
        ("SEGURANÇA (exposição)", None, None),
        ("  tempo acima do envelope [h]", "tempo_acima_envelope_h", "{:.1f}"),
        ("  tempo acima do TAH-201 [h]", "tempo_acima_TAH_h", "{:.1f}"),
        ("  temperatura máxima [°C]", "temperatura_max_C", "{:.1f}"),
        ("  margem até TAHH-201 [K]", "margem_TAHH_min_K", "{:.1f}"),
        ("CUSTO OPERACIONAL", None, None),
    ]
    largura = max(len(l[0]) for l in linhas) + 2
    cab = " " * largura + "".join(f"{n:>16s}" for n in exps)
    print(cab); print("-" * len(cab))
    for rot, chave, fmt in linhas:
        if chave is None:
            print(rot); continue
        print(f"{rot:<{largura}s}" + "".join(f"{fmt.format(mets[n][chave]):>16s}" for n in exps))
    for termo in ("erro", "qualidade", "margem", "saturacao", "exposicao", "TOTAL"):
        rot = f"  {termo}"
        print(f"{rot:<{largura}s}" + "".join(f"{custos[n][termo]:>16.3f}" for n in exps))
    return {"metricas": mets, "custos": custos}


print("\n" + "=" * 78)
print("COMPARAÇÃO — horizonte completo (5,8 dias)")
print("=" * 78)
RESUMO = tabela_comparativa({"A BASELINE": EXP_A, "B PID+PROBLEMA": EXP_B, "C (mesma porta)": EXP_C})

print("\n" + "=" * 78)
print(f"COMPARAÇÃO — janela do upset (t ∈ [{T_UPSET_INI:.0f}, {T_FINAL:.0f}])")
print("=" * 78)
RESUMO_UPSET = tabela_comparativa({"A BASELINE": EXP_A, "B PID+PROBLEMA": EXP_B},
                                  ini=T_UPSET_INI, fim=T_FINAL)


# %% [markdown]
# ## Gráficos
#
# O gráfico decisivo do caso é o último: **erro de controle e margem de
# operação no mesmo eixo de tempo.** O erro fica achatado em torno de zero
# durante quase cinco dias enquanto a margem some. É a figura que separa
# "controlar a PV" de "operar a unidade".

# %%
def _marcar_eventos(ax, res, so_upset=False):
    for tt, nome in res["eventos"]:
        if so_upset and tt < T_UPSET_INI:
            continue
        ax.axvline(tt, color="0.5", lw=0.8, ls=":", zorder=0)


def plot_panorama(res, titulo, arquivo):
    t = res["t"]
    fig, ax = plt.subplots(4, 1, figsize=(13, 11), sharex=True)

    ax[0].plot(t, x2_to_C(res["SP"]), "--", lw=1.2, color="k", label="SP TIC-201")
    ax[0].plot(t, x2_to_C(res["PV"]), lw=1.0, color="C0", label="PV (TT-201)")
    ax[0].axhspan(*[float(x2_to_C(v)) for v in X2_ENVELOPE], color="C2", alpha=.08,
                  label="envelope operacional")
    ax[0].axhline(float(x2_to_C(X2_TAH)), color="C1", lw=1.1, ls="-.", label="TAH-201")
    ax[0].axhline(float(x2_to_C(X2_TAHH)), color="C3", lw=1.2, label="TAHH-201 (SIS)")
    ax[0].set_ylabel("Temperatura R-201 [°C]"); ax[0].set_title(titulo)
    ax[0].legend(ncol=5, fontsize=8, loc="upper left"); ax[0].grid(alpha=.3)

    ax[1].plot(t, 100 * res["q"], lw=1.2, color="C0", label="ZT-201 (curso real)")
    ax[1].plot(t, 100 * np.minimum(res["demanda_curso"], 2.0), lw=1.0, color="C3",
               ls="--", label="curso EXIGIDO (não medido)")
    ax[1].axhline(100 * TRAVEL_ZAH, color="C1", ls="-.", lw=1.1, label="ZAH-201 (80%)")
    ax[1].axhline(100.0, color="k", lw=1.0)
    ax[1].fill_between(t, 100 * res["q"], 100, where=res["q"] >= TRAVEL_SAT,
                       color="C3", alpha=.15)
    ax[1].set_ylabel("Curso FV-201 [%]"); ax[1].set_ylim(0, 205)
    ax[1].legend(ncol=4, fontsize=8, loc="upper left"); ax[1].grid(alpha=.3)

    camp_min = np.array([production_campaign(tt, res["scenario"]).x_min for tt in t])
    camp_max = np.array([production_campaign(tt, res["scenario"]).x_max for tt in t])
    ax[2].plot(t, res["x1"], lw=1.1, color="C0", label="conversão real")
    ax[2].plot(t, res["at205"], lw=.6, color="C7", alpha=.6, label="AT-205")
    ax[2].fill_between(t, camp_min, camp_max, color="C2", alpha=.12, label="especificação")
    ax[2].set_ylabel("Conversão X"); ax[2].legend(ncol=3, fontsize=8, loc="upper left")
    ax[2].grid(alpha=.3)

    ax[3].plot(t, res["tt207"], lw=1.1, color="C4", label="TT-207 (loop temperado / E-201)")
    ax[3].plot(t, res["tt203"], lw=1.0, color="C5", label="TT-203 (água de torre)")
    ax[3].plot(t, res["tt204"], lw=1.0, color="C6", label="TT-204 (alimentação)")
    ax[3].axhline(CW_TOWER_TAH_C, color="C1", ls="-.", lw=1.0, label="TAH-203")
    ax[3].set_ylabel("Utilidades [°C]"); ax[3].set_xlabel("t adimensional  (1 t.u. = 20 min)")
    ax[3].legend(ncol=4, fontsize=8, loc="upper left"); ax[3].grid(alpha=.3)

    sec = ax[0].secondary_xaxis("top", functions=(lambda v: v, lambda v: v))
    marcas = np.arange(0, T_FINAL + 1, 72)
    sec.set_xticks(marcas)
    sec.set_xticklabels([f"{t_to_stamp(v):%d/%m %Hh}" for v in marcas], fontsize=8)

    for a in ax:
        _marcar_eventos(a, res)
    fig.tight_layout(); fig.savefig(_figpath(arquivo), dpi=130)
    return fig


plot_panorama(EXP_B, "Experimento B — U-200 / R-201 · campanha RB-220 · agosto/2026",
              "10_incidente_panorama.png")
plot_panorama(EXP_A, "Experimento A — BASELINE · unidade íntegra · campanha RA-180",
              "11_baseline_panorama.png")


# %%
# --- A figura que resume o caso ---------------------------------------------
fig, ax = plt.subplots(2, 1, figsize=(13, 6.5), sharex=True)
ax[0].plot(EXP_A["t"], EXP_A["SP"] - EXP_A["PV"], lw=.9, color="C2", label="A — baseline")
ax[0].plot(EXP_B["t"], EXP_B["SP"] - EXP_B["PV"], lw=.9, color="C3", label="B — com incidente")
ax[0].axhline(0, color="k", lw=.8)
ax[0].set_ylabel("Erro de controle\nSP − PV  [adim.]")
ax[0].set_title("O PID faz o seu trabalho. A unidade perde a margem mesmo assim.")
ax[0].legend(fontsize=9); ax[0].grid(alpha=.3)
ax[1].plot(EXP_A["t"], 100 * (1 - EXP_A["q"]), lw=1.3, color="C2", label="A — baseline")
ax[1].plot(EXP_B["t"], 100 * (1 - EXP_B["q"]), lw=1.3, color="C3", label="B — com incidente")
ax[1].axhline(100 * (1 - TRAVEL_ZAH), color="C1", ls="-.", lw=1.1, label="limite ZAH-201")
ax[1].axhline(0, color="k", lw=.8)
ax[1].fill_between(EXP_B["t"], 0, 100 * (1 - EXP_B["q"]),
                   where=EXP_B["q"] >= TRAVEL_SAT, color="C3", alpha=.2)
ax[1].set_ylabel("Margem de resfriamento\n100% − curso FV-201")
ax[1].set_xlabel("t adimensional  (1 t.u. = 20 min)")
ax[1].legend(fontsize=9); ax[1].grid(alpha=.3)
ax[1].annotate("troca de campanha", xy=(T_TRANS_FIM, 30), fontsize=8,
               xytext=(T_TRANS_FIM + 12, 52), arrowprops=dict(arrowstyle="->", lw=.8))
ax[1].annotate("ZAH-201 suprimido", xy=(T_ZAH_SUPRIMIDO, 19), fontsize=8,
               xytext=(T_ZAH_SUPRIMIDO - 95, 40), arrowprops=dict(arrowstyle="->", lw=.8))
ax[1].annotate("upset de alimentação\n(+3,0 K)", xy=(T_UPSET_INI, 6), fontsize=8,
               xytext=(T_UPSET_INI - 120, 22), arrowprops=dict(arrowstyle="->", lw=.8))
fig.tight_layout(); fig.savefig(_figpath("12_erro_vs_margem.png"), dpi=130)


# %%
# --- Decomposição causal do curso de FV-201 ---------------------------------
def _curso_regime(H, u_cf, trim, d2=0.0, sp=SP_UNIDADE):
    p = replace(CSTRParams(), H=H)
    u = ((1 + p.beta) * sp - H * (lambda a: a / (1 + a))(
        p.Da * np.exp(sp / (1 + sp / p.gamma))) - d2) / p.beta
    return CoolingValve(ValveParams(u_cf=u_cf, a_max=A_MAX_PROJETO,
                                    gain_trim=trim)).demanded_travel(u, sp)


_etapas = [
    ("Projeto\n(RA-180, trim Cv 40)", _curso_regime(CAMPANHA_A.H, UCF_PROJETO, 1.0)),
    ("+ trim substituto\n(WO-3874)", _curso_regime(CAMPANHA_A.H, UCF_PROJETO, TRIM_SUBSTITUTO)),
    ("+ campanha RB-220\n(PO-2026-0418)", _curso_regime(CAMPANHA_B.H, UCF_PROJETO, TRIM_SUBSTITUTO)),
    ("+ circuito aquecido\n(TT-207 +7 K)", _curso_regime(CAMPANHA_B.H, UCF_FIM, TRIM_SUBSTITUTO)),
    ("+ upset alimentação\n(+3,0 K)", _curso_regime(CAMPANHA_B.H, UCF_FIM, TRIM_SUBSTITUTO, UPSET_D2)),
]
DECOMPOSICAO = [(n, 100 * v) for n, v in _etapas]

fig, ax = plt.subplots(figsize=(11, 4.6))
vals = [v for _, v in DECOMPOSICAO]
cores = ["C0"] + ["C4", "C9", "C5", "C3"]
ax.bar(range(len(vals)), vals, color=cores, alpha=.85)
for i, v in enumerate(vals):
    delta = f"\n({v - vals[i-1]:+.1f} pts)" if i else ""
    ax.text(i, min(v, 175) + 4, f"{v:.0f}%{delta}", ha="center", fontsize=9)
ax.axhline(100, color="k", lw=1.2)
ax.axhline(100 * TRAVEL_ZAH, color="C1", ls="-.", lw=1.1)
ax.text(len(vals) - .4, 102, "saturação", fontsize=8, ha="right")
ax.text(len(vals) - .4, 100 * TRAVEL_ZAH + 2, "ZAH-201", fontsize=8, ha="right", color="C1")
ax.set_xticks(range(len(vals)))
ax.set_xticklabels([n for n, _ in DECOMPOSICAO], fontsize=8.5)
ax.set_ylabel("Curso exigido de FV-201 [%]"); ax.set_ylim(0, 195)
ax.set_title("Nenhuma causa isolada satura a válvula. As quatro juntas, sim.")
ax.grid(axis="y", alpha=.3)
fig.tight_layout(); fig.savefig(_figpath("13_decomposicao_causal.png"), dpi=130)

print("Decomposição do curso exigido de FV-201 (regime, SP = 4,705):")
for n, v in DECOMPOSICAO:
    print(f"  {n.replace(chr(10), ' '):38s} {v:6.1f}%")


# %% [markdown]
# ## Exportação dos dados (§7, §21)
#
# Dois historians, deliberadamente separados:
#
# * `data/historian.csv` — **só tags de instrumento**. É o que existe no PIMS
#   da planta e é o que entra no `investigation_package/`.
# * `internal/historian_truth.csv` — estados verdadeiros, `d1`, `d2`, `H`,
#   `u_cf` e `gain_trim`. **Uso exclusivo do pesquisador.** Se `gain_trim`
#   estivesse no pacote de investigação, não haveria investigação nenhuma.

# %%
def _dir(nome: str) -> str:
    for base in (".", "..", "case_study"):
        p = os.path.join(base, nome)
        if os.path.isdir(p):
            return p
    os.makedirs(nome, exist_ok=True)
    return nome


def _escrever_csv(caminho: str, cabecalho: list[str], linhas) -> str:
    with open(caminho, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(cabecalho)
        w.writerows(linhas)
    return caminho


def exportar_historian(res: dict, nome="historian.csv") -> str:
    """Historian de planta: apenas o que os instrumentos medem."""
    passo = int(round(res["scenario"].dt_log / res["scenario"].dt))
    idx = range(0, len(res["t"]), passo)
    cab = ["timestamp", "TIC201_SP_C", "TT201_PV_C", "TIC201_OUT_pct", "ZT201_pct",
           "FT201_m3h", "TT202_C", "TT203_C", "TT204_C", "TT207_C",
           "AT205_X", "FT204_m3h", "TIC201_MODE", "UNIT_STATE", "PO"]
    linhas = []
    for k in idx:
        linhas.append([
            f"{t_to_stamp(res['t'][k]):%Y-%m-%d %H:%M:%S}",
            f"{x2_to_C(res['SP'][k]):.2f}", f"{x2_to_C(res['PV'][k]):.2f}",
            f"{100 * res['q_cmd'][k]:.2f}", f"{100 * res['q'][k]:.2f}",
            f"{res['ft201'][k]:.2f}", f"{res['tt202'][k]:.2f}",
            f"{res['tt203'][k]:.2f}", f"{res['tt204'][k]:.2f}", f"{res['tt207'][k]:.2f}",
            f"{res['at205'][k]:.4f}", f"{9.0 + 0.03 * np.sin(res['t'][k]):.2f}",
            res["modo"][k], res["estado"][k], res["po"][k]])
    return _escrever_csv(os.path.join(_dir("data"), nome), cab, linhas)


def exportar_historian_verdade(res: dict) -> str:
    """Estados verdadeiros e parâmetros ocultos. NÃO vai para a investigação."""
    passo = int(round(res["scenario"].dt_log / res["scenario"].dt))
    cab = ["timestamp", "t_adim", "x1_true", "x2_true", "u_jacket", "d1", "d2",
           "H", "u_cf", "gain_trim", "curso_real", "curso_exigido", "SP", "PV_medido"]
    linhas = [[f"{t_to_stamp(res['t'][k]):%Y-%m-%d %H:%M:%S}", f"{res['t'][k]:.3f}",
               f"{res['x1'][k]:.6f}", f"{res['x2'][k]:.6f}", f"{res['u'][k]:.6f}",
               f"{res['d1'][k]:.6f}", f"{res['d2'][k]:.6f}", f"{res['H'][k]:.4f}",
               f"{res['u_cf'][k]:.4f}", f"{res['trim'][k]:.3f}",
               f"{res['q'][k]:.6f}", f"{min(res['demanda_curso'][k], 9.0):.6f}",
               f"{res['SP'][k]:.4f}", f"{res['PV'][k]:.6f}"]
              for k in range(0, len(res["t"]), passo)]
    return _escrever_csv(os.path.join(_dir("internal"), "historian_truth.csv"), cab, linhas)


def exportar_alarmes(res: dict) -> str:
    """Transições de alarme. Um alarme é um EVENTO, não uma conclusão."""
    passo = int(round(res["scenario"].dt_log / res["scenario"].dt))
    idx = list(range(0, len(res["t"]), passo))
    defs = [
        ("TAH-201", "Temperatura alta R-201", "ALTA",
         lambda k, h=0.0: res["x2"][k] > X2_TAH - h * 0.05,
         lambda k: x2_to_C(res["x2"][k]), x2_to_C(X2_TAH), "°C"),
        ("TAL-201", "Temperatura baixa R-201", "BAIXA",
         lambda k, h=0.0: res["x2"][k] < X2_TAL + h * 0.05,
         lambda k: x2_to_C(res["x2"][k]), x2_to_C(X2_TAL), "°C"),
        ("ZAH-201", "Curso alto FV-201", "BAIXA",
         lambda k, h=0.0: res["q"][k] > TRAVEL_ZAH - h * 0.03,
         lambda k: 100 * res["q"][k], 100 * TRAVEL_ZAH, "%"),
        ("ZAHH-201", "FV-201 saturada aberta", "ALTA",
         lambda k, h=0.0: res["q"][k] >= TRAVEL_SAT - h * 0.02,
         lambda k: 100 * res["q"][k], 100 * TRAVEL_SAT, "%"),
        ("TAH-203", "Água de torre quente", "BAIXA",
         lambda k, h=0.0: res["tt203"][k] > CW_TOWER_TAH_C - h * 0.6,
         lambda k: res["tt203"][k], CW_TOWER_TAH_C, "°C"),
        ("QAH-205", "Conversão acima da especificação", "MEDIA",
         lambda k, h=0.0: res["at205"][k] > production_campaign(
             res["t"][k], res["scenario"]).x_max - h * 0.006,
         lambda k: res["at205"][k], float("nan"), "-"),
    ]
    # Histerese + tempo mínimo de permanência (EEMUA 191). Sem isso o log vira
    # chattering e os alarmes que importam ficam soterrados. Um DCS real faz isso.
    # `h=1` aplica a banda morta, usada apenas para NORMALIZAR um alarme ativo.
    T_MIN_PERMANENCIA = 2.0     # t.u. = 40 min
    linhas, ativo = [], {d[0]: False for d in defs}
    t_ult = {d[0]: -1e9 for d in defs}
    supr_reg = False
    for k in idx:
        t_agora = float(res["t"][k])
        ts = f"{t_to_stamp(t_agora):%Y-%m-%d %H:%M:%S}"
        if (not supr_reg) and any(nome == "SUPRESSAO_ALARME_ZAH201"
                                  for tt, nome in res["eventos"] if tt <= t_agora):
            supr_reg = True
            linhas.append([ts, "ZAH-201", "Curso alto FV-201", "BAIXA", "SUPRIMIDO",
                           f"{100 * res['q'][k]:.1f}", f"{100 * TRAVEL_ZAH:.1f}", "%"])
        for tag, desc, prio, cond, val, lim, un in defs:
            if tag == "ZAH-201" and supr_reg:
                continue
            c = bool(cond(k, 1.0)) if ativo[tag] else bool(cond(k, 0.0))
            if c != ativo[tag] and (t_agora - t_ult[tag]) >= T_MIN_PERMANENCIA:
                ativo[tag] = c
                t_ult[tag] = t_agora
                limtxt = "" if lim != lim else f"{lim:.1f}"
                linhas.append([ts, tag, desc, prio, "ATIVO" if c else "NORMALIZADO",
                               f"{val(k):.2f}", limtxt, un])
    cab = ["timestamp", "tag", "descricao", "prioridade", "estado", "valor", "limite", "unidade"]
    return _escrever_csv(os.path.join(_dir("data"), "alarms.csv"), cab, linhas)


def exportar_qualidade(res: dict, periodo: float = 12.0) -> str:
    """Amostras de laboratório (LIMS). 1 amostra a cada 4 h.

    Cor Gardner e viscosidade são as propriedades pelas quais a especificação
    de conversão existe: acima do envelope o produto escurece e sobe de massa
    molar. O laboratório não mede x2 — mede o produto.
    """
    rng = np.random.default_rng(res["scenario"].seed + 7)
    passo = int(round(periodo / res["scenario"].dt))
    cab = ["sample_id", "timestamp", "PO", "lote", "conversao_lab", "spec_min",
           "spec_max", "cor_gardner", "gardner_max", "viscosidade_cP",
           "visc_min", "visc_max", "resultado"]
    linhas = []
    for n, k in enumerate(range(passo // 2, len(res["t"]), passo), start=1):
        camp = production_campaign(res["t"][k], res["scenario"])
        x2, x1 = res["x2"][k], res["x1"][k]
        conv = x1 + rng.normal(0, 0.0025)
        gardner = 3.0 + 14.0 * max(0.0, x2 - 4.80) + rng.normal(0, 0.12)
        visc = 1800.0 + 9000.0 * (x1 - 0.75) + rng.normal(0, 18.0)
        ok = (camp.x_min <= conv <= camp.x_max) and gardner <= 4.0 and 1700 <= visc <= 2100
        linhas.append([f"LIMS-{n:04d}", f"{t_to_stamp(res['t'][k]):%Y-%m-%d %H:%M}",
                       camp.po, camp.lote, f"{conv:.4f}", f"{camp.x_min:.3f}",
                       f"{camp.x_max:.3f}", f"{gardner:.2f}", "4.00", f"{visc:.0f}",
                       "1700", "2100", "APROVADO" if ok else "REPROVADO"])
    return _escrever_csv(os.path.join(_dir("data"), "quality.csv"), cab, linhas)


EVENTOS_CASO = [
    ("2026-07-14 09:20", "EV001", "MAINTENANCE", "WO-3871 concluída — recalibração do analisador AT-205", "CMMS"),
    ("2026-07-29 07:05", "EV002", "SHUTDOWN", "Parada programada PP-26-03 iniciada — U-200", "OPERACAO"),
    ("2026-07-29 15:40", "EV003", "MAINTENANCE", "WO-3874 concluída — revisão geral de FV-201", "CMMS"),
    ("2026-07-30 06:00", "EV004", "STARTUP", "U-200 retomada em RA-180 após PP-26-03", "OPERACAO"),
    ("2026-08-03 10:15", "EV005", "MAINTENANCE", "WO-3882 aberta — enchimento da torre TR-901 com incrustação", "CMMS"),
    ("2026-08-08 06:00", "EV006", "CAMPAIGN", "PO-2026-0417 (RA-180) em produção — início do registro", "PLANEJAMENTO"),
]


def exportar_event_log(res: dict) -> str:
    """Eventos observados. Nenhuma linha contém conclusão ou diagnóstico."""
    tipos = {
        "SUPRESSAO_ALARME_ZAH201": ("ALARM_MGMT",
                                    "Alarme ZAH-201 suprimido no console a pedido do turno"),
        "UNIDADE_DECLARADA_ANORMAL": ("OPERATING_STATE",
                                      "Unidade declarada em condição anormal pelo turno"),
        "SP_REDUZIDO_4.600": ("OPERATOR_ACTION",
                              "SP de TIC-201 reduzido de 229,2 °C para 227,1 °C"),
        "SP_RESTAURADO_4.705": ("OPERATOR_ACTION",
                                "SP de TIC-201 restaurado para 229,2 °C"),
    }
    linhas = [list(e) for e in EVENTOS_CASO]
    n = len(linhas)
    marcos = [
        (T_TRANS_INI, "CAMPAIGN", "Fim de PO-2026-0417 — início da transição de grade"),
        (T_TRANS_FIM, "CAMPAIGN", "PO-2026-0418 (RB-220) em produção"),
        (T_UPSET_INI, "PROCESS_EVENT",
         "TT-204 em elevação — controle de temperatura de E-202 fora de faixa (U-100)"),
        (T_UPSET_FIM, "PROCESS_EVENT", "TT-204 retornando à faixa normal"),
    ]
    brutos = [(tt, *tipos.get(nm, ("OPERATOR_ACTION", nm))) for tt, nm in res["eventos"]]
    brutos += [(tt, tp, ds) for tt, tp, ds in marcos]
    for tt, tp, ds in sorted(brutos):
        n += 1
        fonte = "DCS" if tp in ("ALARM_MGMT", "OPERATOR_ACTION") else \
                ("PLANEJAMENTO" if tp == "CAMPAIGN" else "OPERACAO")
        linhas.append([f"{t_to_stamp(tt):%Y-%m-%d %H:%M}", f"EV{n:03d}", tp, ds, fonte])
    cab = ["timestamp", "event_id", "event_type", "description", "source"]
    return _escrever_csv(os.path.join(_dir("data"), "event_log.csv"), cab, linhas)


ARQUIVOS = [exportar_historian(EXP_B), exportar_alarmes(EXP_B),
            exportar_qualidade(EXP_B), exportar_event_log(EXP_B),
            exportar_historian(EXP_A, "historian_baseline.csv"),
            exportar_historian_verdade(EXP_B)]
print("Arquivos gerados:")
for a in ARQUIVOS:
    print(f"  {a:42s} {os.path.getsize(a) / 1024:8.1f} kB")


# %% [markdown]
# ## Testes de consistência (§28)
#
# Rodam a cada execução. Se algum falhar, o benchmark não é válido e a
# execução para.

# %%
def testes_consistencia() -> list[tuple[str, str]]:
    ok = []

    def checar(grupo, nome, cond, detalhe=""):
        assert cond, f"FALHOU [{grupo}] {nome}: {detalhe}"
        ok.append((grupo, nome))

    # ---- MODELO -------------------------------------------------------------
    check_published_equilibria()
    ok.append(("MODELO", "equilíbrios publicados reproduzidos"))
    for nome, r in (("A", EXP_A), ("B", EXP_B), ("B'", EXP_BC)):
        checar("MODELO", f"sem NaN/inf em {nome}",
               np.all(np.isfinite(r["x1"])) and np.all(np.isfinite(r["x2"])))
        checar("MODELO", f"estados plausíveis em {nome}",
               bool(np.all((r["x1"] > 0) & (r["x1"] < 1)) and np.all((r["x2"] > 0) & (r["x2"] < 12))),
               f"x1∈[{r['x1'].min():.3f},{r['x1'].max():.3f}] x2∈[{r['x2'].min():.3f},{r['x2'].max():.3f}]")
        checar("MODELO", f"reator não extinguiu em {nome}", bool(r["x2"].min() > 3.0),
               f"x2_min={r['x2'].min():.3f}")

    # ---- CONTROLE -----------------------------------------------------------
    mA = metrics(EXP_A)
    checar("CONTROLE", "PID controla no cenário nominal", mA["IAE"] / mA["duracao_h"] < 0.05,
           f"IAE/h={mA['IAE'] / mA['duracao_h']:.4f}")
    checar("CONTROLE", "erro médio nominal desprezível", abs(mA["erro_medio"]) < 0.01,
           f"{mA['erro_medio']:+.5f}")
    checar("CONTROLE", "MV respeita a saturação física",
           bool(np.all(EXP_B["q"] >= -1e-12) and np.all(EXP_B["q"] <= 1 + 1e-12)))
    checar("CONTROLE", "atuador filtra o comando (dinâmica de válvula)",
           float(np.max(np.abs(EXP_B["q"] - EXP_B["q_cmd"]))) > 1e-4)
    checar("CONTROLE", "sensor introduz atraso e ruído",
           float(np.std(EXP_B["PV"] - EXP_B["x2"])) > 1e-4)
    checar("CONTROLE", "baseline reprodutível bit a bit",
           bool(np.array_equal(run_case(novo_pid(), CEN_BASELINE)["x2"], EXP_A["x2"])))
    checar("CONTROLE", "B ≡ C (troca de controlador é a única variável)",
           bool(np.array_equal(EXP_B["x2"], EXP_C["x2"])))

    # ---- INCIDENTE ----------------------------------------------------------
    mB, mBC = metrics(EXP_B), metrics(EXP_BC)
    pre = metrics(EXP_B, 0.0, T_UPSET_INI)
    checar("INCIDENTE", "o evento ocorre: FV-201 satura",
           mB["tempo_saturado_h"] > 10.0, f"{mB['tempo_saturado_h']:.1f} h")
    checar("INCIDENTE", "a margem é consumida ANTES do upset",
           pre["curso_max_pct"] > 90.0 and pre["tempo_acima_TAH_h"] == 0.0,
           f"curso_max={pre['curso_max_pct']:.1f}% TAH={pre['tempo_acima_TAH_h']:.1f} h")
    checar("INCIDENTE", "o PID parece OK antes do upset",
           pre["tempo_em_spec_pct"] > 99.0 and pre["erro_max"] < 0.15,
           f"spec={pre['tempo_em_spec_pct']:.1f}% |e|max={pre['erro_max']:.3f}")
    checar("INCIDENTE", "qualidade é afetada",
           mB["producao_perdida_pct"] > 10.0, f"{mB['producao_perdida_pct']:.1f}%")
    checar("INCIDENTE", "exposição a região crítica aumenta",
           mB["tempo_acima_TAH_h"] > 5.0 and mA["tempo_acima_TAH_h"] == 0.0)
    checar("INCIDENTE", "SIS não é acionado (modelo de trip dispensável)",
           not EXP_B["sis_trip"], f"x2_max={EXP_B['x2'].max():.3f} vs TAHH={X2_TAHH}")
    checar("INCIDENTE", "detectável nos dados: ZT-201 alto com FT-201 baixo",
           abs(EXP_B["ft201"][-1] / (FC_DESIGN_M3H * EXP_B["q"][-1]) - TRIM_SUBSTITUTO) < 0.05,
           "razão FT-201/curso não denuncia a perda de capacidade")
    checar("INCIDENTE", "o trim é a dobradiça causal (contrafactual)",
           mBC["tempo_acima_TAH_h"] == 0.0 and mBC["tempo_saturado_h"] < 0.25 * mB["tempo_saturado_h"],
           f"B': {mBC['tempo_saturado_h']:.1f} h sat, {mBC['tempo_acima_TAH_h']:.1f} h TAH")
    checar("INCIDENTE", "nenhuma causa isolada satura a válvula",
           all(v < 100.0 for _, v in DECOMPOSICAO[:-1]) and DECOMPOSICAO[-1][1] > 100.0)

    # ---- BENCHMARK ----------------------------------------------------------
    cA, cB = operational_cost(mA)["TOTAL"], operational_cost(mB)["TOTAL"]
    checar("BENCHMARK", "custo operacional separa A de B", cB > 10 * cA, f"{cA:.3f} vs {cB:.3f}")
    checar("BENCHMARK", "IAE sozinho subestima o problema",
           (mB["IAE"] / mA["IAE"]) < (cB / cA),
           "o erro cresce menos que o custo operacional — é esse o ponto do caso")
    return ok


_ok = testes_consistencia()
print(f"✓ {len(_ok)} testes de consistência passaram\n")
_grupo = None
for g, n in _ok:
    if g != _grupo:
        print(f"  [{g}]"); _grupo = g
    print(f"    ✓ {n}")

_mA, _mB = metrics(EXP_A), metrics(EXP_B)
print(f"\nrazão IAE (B/A)              : {_mB['IAE'] / _mA['IAE']:6.1f}×")
print(f"razão custo operacional (B/A): {operational_cost(_mB)['TOTAL'] / operational_cost(_mA)['TOTAL']:6.1f}×")
print("   → o erro de controle cresce muito menos que o custo de operar a unidade.")
