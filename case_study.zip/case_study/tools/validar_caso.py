"""Teste da pergunta §29: o caso é resolúvel SÓ com o pacote de investigação?

Este script não pode importar `u200_case` nem ler nada de `internal/`. Ele lê
exclusivamente `investigation_package/` e refaz a investigação como um
engenheiro de processos faria, cruzando os silos. Se ele deixar de fechar, o
benchmark quebrou.

    python tools/validar_caso.py
"""
from __future__ import annotations

import csv
import os
from collections import defaultdict

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG = os.path.join(RAIZ, "investigation_package")

# Números lidos dos DOCUMENTOS do pacote (não do simulador):
VAZAO_100_PCT = 45.0      # U-200-DS-FV201 § 2: Cv 40 → 45 m³/h a 100 % de curso
CV_PROJETO = 40           # U-200-DS-FV201 § 3: conjunto NV4000-40-STD
MARGEM_DB41 = 25.0        # U-200-DB-001 § 4: reserva mínima de curso
CURSO_MC4 = 47.7          # U-200-MC-014 § 4: curso previsto no caso mais severo
PERTURB_PROJETO_K = 3.0   # U-200-MC-014 § 6: perturbação de referência
GATILHO = "2026-08-12 22:00"


def main() -> int:
    with open(os.path.join(PKG, "data", "historian.csv"), encoding="utf-8") as fh:
        h = list(csv.DictReader(fh))
    pre = [l for l in h if l["timestamp"] < GATILHO]
    achados = []

    # 1 — a malha estava controlando? (descarta H1: sintonia)
    err = [abs(float(l["TIC201_SP_C"]) - float(l["TT201_PV_C"])) for l in pre]
    err_medio = sum(err) / len(err)
    assert err_medio < 1.0, f"erro médio {err_medio:.2f} °C — o caso deixou de ser sutil"
    achados.append(f"|SP−PV| médio antes do gatilho = {err_medio:.2f} °C → não é sintonia")

    # 2 — a válvula entrega a vazão do datasheet? (a evidência decisiva)
    raz = [float(l["FT201_m3h"]) / (VAZAO_100_PCT * float(l["ZT201_pct"]) / 100)
           for l in h if float(l["ZT201_pct"]) > 40]
    r = sum(raz) / len(raz)
    cv_real = CV_PROJETO * r
    assert r < 0.75, f"razão {r:.3f} — a perda de capacidade não é detectável nos dados"
    assert abs(cv_real - 22.0) < 1.0, f"Cv implícito {cv_real:.1f} não bate com a tabela NV-4000-TD"
    achados.append(f"FT-201/esperado = {r:.3f} → Cv implícito {cv_real:.1f} "
                   f"→ NV-4000-TD: conjunto NV4000-22-AC")

    # 3 — quando começou? (separa a causa raiz dos contribuintes)
    curso0 = float(h[0]["ZT201_pct"])
    assert h[0]["PO"] == "PO-2026-0417", "o registro deveria começar na campanha anterior"
    assert curso0 > 50.0, "o desvio deveria ser visível já na campanha anterior"
    achados.append(f"curso já em {curso0:.1f} % na 1ª amostra, ainda em {h[0]['PO']} "
                   f"→ anterior à troca de campanha")

    # 4 — a margem de projeto foi violada?
    curso_max_pre = max(float(l["ZT201_pct"]) for l in pre)
    margem = 100 - curso_max_pre
    assert margem < MARGEM_DB41, "a margem DB-4.1 não chegou a ser violada"
    achados.append(f"margem mínima antes do gatilho = {margem:.1f} % "
                   f"(DB-4.1 exige {MARGEM_DB41:.0f} %; MC-4 previa {100-CURSO_MC4:.1f} %)")

    # 5 — o gatilho era uma perturbação de projeto?
    t204 = [float(l["TT204_C"]) for l in h]
    base = sum(t204[:200]) / 200
    delta = max(t204) - base
    assert delta <= PERTURB_PROJETO_K * 1.3, \
        f"gatilho de {delta:.1f} K excede a perturbação de projeto — o caso perde a graça"
    achados.append(f"gatilho = +{delta:.1f} K em TT-204, dentro dos "
                   f"{PERTURB_PROJETO_K:.0f} K verificados em MC-014 § 6")

    # 6 — os alarmes contam a história na ordem certa?
    with open(os.path.join(PKG, "data", "alarms.csv"), encoding="utf-8") as fh:
        al = list(csv.DictReader(fh))
    zah = next(a for a in al if a["tag"] == "ZAH-201" and a["estado"] == "ATIVO")
    sup = next(a for a in al if a["tag"] == "ZAH-201" and a["estado"] == "SUPRIMIDO")
    zahh = next(a for a in al if a["tag"] == "ZAHH-201" and a["estado"] == "ATIVO")
    tah = next(a for a in al if a["tag"] == "TAH-201" and a["estado"] == "ATIVO")
    assert zah["timestamp"] < sup["timestamp"] < zahh["timestamp"] < tah["timestamp"]
    achados.append(f"ZAH-201 ativo {zah['timestamp'][5:16]} → suprimido "
                   f"{sup['timestamp'][5:16]} → ZAHH-201 {zahh['timestamp'][5:16]} "
                   f"→ TAH-201 {tah['timestamp'][5:16]}")

    # 7 — o produto estava aprovado enquanto a margem sumia?
    with open(os.path.join(PKG, "data", "quality.csv"), encoding="utf-8") as fh:
        q = list(csv.DictReader(fh))
    q_pre = [a for a in q if a["timestamp"] < GATILHO]
    aprov = sum(1 for a in q_pre if a["resultado"] == "APROVADO")
    assert aprov == len(q_pre), "o produto deveria estar 100 % aprovado antes do gatilho"
    achados.append(f"{aprov}/{len(q_pre)} amostras aprovadas antes do gatilho "
                   f"→ a degradação não era visível pela qualidade")

    # 8 — o pacote não vazou o ground truth
    for raiz, _, arqs in os.walk(PKG):
        for a in arqs:
            assert not any(p in a for p in ("ground_truth", "historian_truth",
                                            "information_matrix")), f"vazamento: {a}"
    achados.append("nenhum arquivo de ground truth no pacote")

    print("Investigação reconstruída SOMENTE com o investigation_package/:\n")
    for i, a in enumerate(achados, 1):
        print(f"  {i}. {a}")
    print("\n  ⇒ FV-201 opera com ~55 % da capacidade de projeto desde a parada de 29/07.")
    print("     Silos necessários: PIMS · Engenharia · Fabricante · Manutenção · Operação")
    print(f"\n✓ {len(achados)} verificações passaram — o caso é resolúvel sem o ground truth.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
